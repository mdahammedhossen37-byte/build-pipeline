package com.dudhia.manager.core

import java.math.BigDecimal
import java.math.RoundingMode

object OrderRules {
    val STATUSES = listOf("NEW", "CONFIRMED", "SHIPPED", "DELIVERED", "CANCELLED")
    /** Allowed next statuses. DELIVERED and CANCELLED are final in this version. */
    fun next(status: String): List<String> = when (status) {
        "NEW" -> listOf("CONFIRMED", "CANCELLED")
        "CONFIRMED" -> listOf("SHIPPED", "DELIVERED", "CANCELLED")
        "SHIPPED" -> listOf("DELIVERED", "CANCELLED")
        else -> emptyList()
    }
    fun canMove(from: String, to: String) = to in next(from)
}

val PAYMENT_METHODS = listOf("CASH", "BKASH", "NAGAD", "ROCKET", "BANK", "OTHER")

/** unit price (paisa) x quantity (milli-units) / 1000, rounded half-up. No floats. */
fun lineTotalPaisa(unitPaisa: Long, qtyMilli: Long): Long =
    BigDecimal.valueOf(unitPaisa).multiply(BigDecimal.valueOf(qtyMilli))
        .divide(BigDecimal.valueOf(1000), 0, RoundingMode.HALF_UP).longValueExact()

fun startOfTodayMillis(): Long {
    val c = java.util.Calendar.getInstance()
    c.set(java.util.Calendar.HOUR_OF_DAY, 0); c.set(java.util.Calendar.MINUTE, 0)
    c.set(java.util.Calendar.SECOND, 0); c.set(java.util.Calendar.MILLISECOND, 0)
    return c.timeInMillis
}
