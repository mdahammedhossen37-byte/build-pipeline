package com.dudhia.manager.features.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.dudhia.manager.core.OrderRules
import com.dudhia.manager.database.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class AppViewModel(private val db: AppDatabase) : ViewModel() {
    val languageBn: StateFlow<Boolean> = db.settings().observe("language")
        .map { it != "en" }
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val onboarded: StateFlow<Boolean?> = db.settings().observe("onboarded")
        .map { it == "1" }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val customerCount = db.customers().observeCount().stateIn(viewModelScope, SharingStarted.Lazily, 0)
    val customers = db.customers().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val products = db.products().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val orders = db.orders().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val orderItemsAll = db.orders().observeAllItems().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val expenses = db.expenses().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private suspend fun audit(action: String, detail: String?) =
        db.audit().insert(AuditLogEntity(timestamp = System.currentTimeMillis(), actor = "USER", action = action, detail = detail))

    fun setLanguage(bn: Boolean) = viewModelScope.launch {
        db.settings().put(AppSettingEntity("language", if (bn) "bn" else "en"))
        audit("SET_LANGUAGE", if (bn) "bn" else "en")
    }
    fun finishOnboarding() = viewModelScope.launch { db.settings().put(AppSettingEntity("onboarded", "1")) }

    suspend fun findByPhone(phone: String): List<CustomerEntity> = db.customers().findByPhone(phone)

    fun saveCustomer(c: CustomerEntity) = viewModelScope.launch {
        if (c.id == 0L) { db.customers().insert(c); audit("CREATE_CUSTOMER", c.phone) }
        else { db.customers().update(c); audit("UPDATE_CUSTOMER", "id=${c.id}") }
    }

    /** onDone(null) = success, otherwise an error code: "sku" (duplicate SKU) or "error". */
    fun saveProduct(p: ProductEntity, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            if (p.id == 0L) { db.products().insert(p); audit("CREATE_PRODUCT", p.sku) }
            else { db.products().update(p); audit("UPDATE_PRODUCT", p.sku) }
            onDone(null)
        } catch (e: android.database.sqlite.SQLiteConstraintException) {
            onDone("sku")
        } catch (e: Exception) {
            onDone("error")
        }
    }

    // ---------------- Orders ----------------
    suspend fun orderItems(orderId: Long): List<OrderItemEntity> = db.orders().items(orderId)

    /** Order + items are saved together in one transaction. New orders are NOT revenue and do not touch stock. */
    fun createOrder(order: OrderEntity, items: List<OrderItemEntity>, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            db.withTransaction {
                val id = db.orders().insert(order)
                db.orders().insertItems(items.map { it.copy(orderId = id) })
                audit("CREATE_ORDER", "id=$id total=${order.totalPaisa}")
            }
            onDone(null)
        } catch (e: Exception) {
            onDone("error")
        }
    }

    /**
     * Status change. DELIVERED deducts stock (once, guarded by stockDeducted) and records stock movements,
     * all in one transaction: if any product lacks stock, nothing changes.
     * Error codes: null = ok, "invalid", "stock:<product name>", "error".
     */
    fun changeStatus(orderId: Long, newStatus: String, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            val err: String? = db.withTransaction {
                val o = db.orders().get(orderId) ?: return@withTransaction "error"
                if (!OrderRules.canMove(o.status, newStatus)) return@withTransaction "invalid"
                val now = System.currentTimeMillis()
                if (newStatus == "DELIVERED") {
                    if (o.stockDeducted) return@withTransaction "invalid"
                    val items = db.orders().items(o.id)
                    val need = items.groupBy { it.productId }.mapValues { e -> e.value.sumOf { x -> x.quantityMilli } }
                    for ((pid, qty) in need) {
                        val p = db.products().get(pid)
                        if (p == null || p.stockMilli < qty) {
                            val name = items.firstOrNull { it.productId == pid }?.productName ?: "?"
                            return@withTransaction "stock:$name"
                        }
                    }
                    for ((pid, qty) in need) {
                        val p = db.products().get(pid)!!
                        db.products().update(p.copy(stockMilli = p.stockMilli - qty, updatedAt = now))
                        db.stock().insert(StockMovementEntity(productId = pid, deltaMilli = -qty,
                            reason = "ORDER_DELIVERED", refType = "ORDER", refId = o.id, createdAt = now))
                    }
                    db.orders().update(o.copy(status = newStatus, stockDeducted = true, deliveredAt = now, updatedAt = now))
                } else {
                    db.orders().update(o.copy(status = newStatus, updatedAt = now))
                }
                audit("ORDER_STATUS", "id=${o.id} ${o.status}->$newStatus")
                null
            }
            onDone(err)
        } catch (e: Exception) {
            onDone("error")
        }
    }

    fun markPaid(orderId: Long) = viewModelScope.launch {
        db.withTransaction {
            val o = db.orders().get(orderId) ?: return@withTransaction
            if (o.paymentStatus != "PAID" && o.status != "CANCELLED") {
                db.orders().update(o.copy(paymentStatus = "PAID", updatedAt = System.currentTimeMillis()))
                audit("ORDER_PAID", "id=$orderId")
            }
        }
    }

    // ---------------- Finance ----------------
    fun addExpense(e: ExpenseEntity) = viewModelScope.launch {
        db.expenses().insert(e)
        audit("CREATE_EXPENSE", "${e.category} ${e.amountPaisa}")
    }

    /** Expenses are voided (kept with deletedAt), never hard-deleted. */
    fun voidExpense(id: Long) = viewModelScope.launch {
        db.expenses().markVoided(id, System.currentTimeMillis())
        audit("VOID_EXPENSE", "id=$id")
    }
}
