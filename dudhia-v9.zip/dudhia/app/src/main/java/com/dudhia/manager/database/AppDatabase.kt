package com.dudhia.manager.database

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        CustomerEntity::class, ProductEntity::class, AppSettingEntity::class, AuditLogEntity::class,
        OrderEntity::class, OrderItemEntity::class, StockMovementEntity::class, ExpenseEntity::class
    ],
    version = 3, exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun customers(): CustomerDao
    abstract fun products(): ProductDao
    abstract fun settings(): SettingDao
    abstract fun audit(): AuditDao
    abstract fun orders(): OrderDao
    abstract fun stock(): StockDao
    abstract fun expenses(): ExpenseDao

    companion object {
        /** Adds orders, order_items, stock_movements. Existing data is untouched. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `orders` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `customerId` INTEGER NOT NULL, `orderDate` INTEGER NOT NULL, `status` TEXT NOT NULL, `subtotalPaisa` INTEGER NOT NULL, `discountPaisa` INTEGER NOT NULL, `deliveryChargePaisa` INTEGER NOT NULL, `totalPaisa` INTEGER NOT NULL, `paymentMethod` TEXT NOT NULL, `paymentStatus` TEXT NOT NULL, `notes` TEXT, `stockDeducted` INTEGER NOT NULL, `deliveredAt` INTEGER, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, `deletedAt` INTEGER)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_orders_customerId` ON `orders` (`customerId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_orders_status` ON `orders` (`status`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `order_items` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `orderId` INTEGER NOT NULL, `productId` INTEGER NOT NULL, `productName` TEXT NOT NULL, `quantityMilli` INTEGER NOT NULL, `unitPricePaisa` INTEGER NOT NULL, `unitCostPaisa` INTEGER NOT NULL, `lineTotalPaisa` INTEGER NOT NULL, FOREIGN KEY(`orderId`) REFERENCES `orders`(`id`) ON UPDATE NO ACTION ON DELETE NO ACTION)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_order_items_orderId` ON `order_items` (`orderId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_order_items_productId` ON `order_items` (`productId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `stock_movements` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `productId` INTEGER NOT NULL, `deltaMilli` INTEGER NOT NULL, `reason` TEXT NOT NULL, `refType` TEXT, `refId` INTEGER, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_stock_movements_productId` ON `stock_movements` (`productId`)")
            }
        }
        /** Adds expenses. Existing data is untouched. */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `expenses` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `expenseDate` INTEGER NOT NULL, `category` TEXT NOT NULL, `amountPaisa` INTEGER NOT NULL, `paymentMethod` TEXT NOT NULL, `description` TEXT, `createdAt` INTEGER NOT NULL, `deletedAt` INTEGER)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_expenses_expenseDate` ON `expenses` (`expenseDate`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_expenses_category` ON `expenses` (`category`)")
            }
        }
        // No destructive fallback: schema changes always ship real migrations.
        fun build(ctx: Context) = Room.databaseBuilder(ctx, AppDatabase::class.java, "dudhia.db")
            .addMigrations(MIGRATION_1_2, MIGRATION_2_3).build()
    }
}
