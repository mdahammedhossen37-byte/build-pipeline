package com.dudhia.manager.core

class Strings(val bn: Boolean) {
    private fun t(b: String, e: String) = if (bn) b else e
    val dashboard = t("ড্যাশবোর্ড", "Dashboard")
    val crm = t("কাস্টমার", "CRM")
    val orders = t("অর্ডার", "Orders")
    val inventory = t("ইনভেন্টরি", "Inventory")
    val more = t("আরও", "More")
    val settings = t("সেটিংস", "Settings")
    val language = t("ভাষা", "Language")
    val bengali = "বাংলা"; val english = "English"
    val customers = t("মোট কাস্টমার", "Total customers")
    val products = t("মোট পণ্য", "Total products")
    val lowStock = t("কম স্টক", "Low stock")
    val comingSoon = t("এই মডিউল পরবর্তী ধাপে আসবে", "This module is not implemented yet")
    val noProducts = t("কোনো পণ্য নেই", "No products yet")
    val welcomeTitle = t("দুধিয়া এআই বিজনেস ম্যানেজার", "Dudhia AI Business Manager")
    val welcomeBody = t(
        "আপনার ব্যবসার সব তথ্য এই ফোনেই থাকে, ইন্টারনেট ছাড়াই কাজ করে।",
        "Your business data stays on this phone and works without internet.")
    val start = t("শুরু করুন", "Get started")

    val save = t("সেভ", "Save"); val cancel = t("বাতিল", "Cancel")
    val search = t("নাম বা ফোন দিয়ে খুঁজুন", "Search name or phone")
    val name = t("নাম", "Name"); val phone = t("ফোন", "Phone")
    val altPhone = t("বিকল্প ফোন", "Alternative phone")
    val address = t("ঠিকানা", "Address"); val area = t("এলাকা", "Area")
    val district = t("জেলা", "District"); val notes = t("নোট", "Notes")
    val newCustomer = t("নতুন কাস্টমার", "New customer")
    val editCustomer = t("কাস্টমার এডিট", "Edit customer")
    val noCustomers = t("কোনো কাস্টমার নেই। নিচের + চাপ দিয়ে যোগ করুন।", "No customers yet. Tap + to add one.")
    val dupTitle = t("এই ফোন নম্বর আগে থেকেই আছে", "This phone number already exists")
    val openExisting = t("আগেরটি খুলুন", "Open existing")
    val saveAnyway = t("তবুও নতুন সেভ", "Save as new anyway")
    val required = t("নাম ও ফোন দিতে হবে", "Name and phone are required")
    val requiredProduct = t("পণ্যের নাম দিতে হবে", "Product name is required")
    val invalidNumber = t("সংখ্যা ঠিকভাবে লিখুন", "Enter numbers correctly")

    val newProduct = t("নতুন পণ্য", "New product")
    val editProduct = t("পণ্য এডিট", "Edit product")
    val nameBn = t("পণ্যের নাম (বাংলা)", "Product name (Bengali)")
    val nameEn = t("পণ্যের নাম (ইংরেজি)", "Product name (English)")
    val sku = t("SKU (খালি রাখলে নিজে তৈরি হবে)", "SKU (auto if empty)")
    val unitTitle = t("একক", "Unit")
    val price = t("বিক্রয় মূল্য (৳)", "Selling price (৳)")
    val cost = t("ক্রয় মূল্য (৳)", "Purchase cost (৳)")
    val stock = t("বর্তমান স্টক", "Current stock")
    val minStock = t("ন্যূনতম স্টক", "Minimum stock")
    val skuExists = t("এই SKU আগে থেকেই আছে", "This SKU already exists")
    val saveFailed = t("সেভ করা যায়নি", "Could not save")

    fun unitLabel(code: String) = when (code) {
        "PIECE" -> t("পিস", "Piece"); "GRAM" -> t("গ্রাম", "Gram"); "KG" -> t("কেজি", "Kg")
        "ML" -> t("মিলি", "ml"); "LITER" -> t("লিটার", "Liter"); "PACK" -> t("প্যাক", "Pack")
        "BOX" -> t("বক্স", "Box"); else -> code
    }

    val newOrder = t("নতুন অর্ডার", "New order")
    val pickCustomer = t("কাস্টমার বাছাই করুন", "Choose customer")
    val customerLabel = t("কাস্টমার", "Customer")
    val product = t("পণ্য", "Product")
    val quantity = t("পরিমাণ", "Quantity")
    val addLine = t("+ আরেকটি পণ্য", "+ Add another product")
    val remove = t("সরান", "Remove")
    val discount = t("ছাড় (৳)", "Discount (৳)")
    val deliveryCharge = t("ডেলিভারি চার্জ (৳)", "Delivery charge (৳)")
    val payment = t("পেমেন্ট মাধ্যম", "Payment method")
    val total = t("মোট", "Total")
    val subtotal = t("সাবটোটাল", "Subtotal")
    val fixLines = t("প্রতিটি লাইনে পণ্য ও সঠিক পরিমাণ দিন", "Choose a product and valid quantity on every line")
    val setPriceFirst = t("আগে ইনভেন্টরিতে পণ্যের বিক্রয় মূল্য বসান", "Set the product selling price in Inventory first")
    val discountTooBig = t("ছাড় সাবটোটালের বেশি হতে পারে না", "Discount cannot exceed the subtotal")
    val needCustomerFirst = t("অর্ডারের আগে একজন কাস্টমার যোগ করুন", "Add a customer before creating an order")
    val noOrders = t("কোনো অর্ডার নেই। নিচের + চাপ দিয়ে যোগ করুন।", "No orders yet. Tap + to add one.")
    val all = t("সব", "All")
    val paid = t("পরিশোধিত", "Paid"); val unpaid = t("বাকি", "Unpaid")
    val markPaid = t("পরিশোধ হয়েছে চিহ্নিত করুন", "Mark as paid")
    val confirmTitle = t("নিশ্চিত করুন", "Please confirm")
    val confirmDeliver = t("ডেলিভারি নিশ্চিত করলে স্টক কমে যাবে এবং এটি বিক্রি হিসেবে ধরা হবে।", "Delivering will reduce stock and count this order as a sale.")
    val confirmCancel = t("অর্ডারটি বাতিল করবেন?", "Cancel this order?")
    val invalidMove = t("এই অবস্থায় এটি করা যাবে না", "Not allowed in the current status")
    val noStock = t("পর্যাপ্ত স্টক নেই: ", "Not enough stock: ")
    val close = t("বন্ধ", "Close"); val yes = t("হ্যাঁ", "Yes")
    val todaySales = t("আজকের বিক্রি (ডেলিভারি হওয়া)", "Today's sales (delivered)")
    val pendingOrders = t("চলমান অর্ডার", "Open orders")
    val deliveredOrders = t("ডেলিভারি হয়েছে", "Delivered")
    val cancelledOrders = t("বাতিল", "Cancelled")

    fun statusLabel(c: String) = when (c) {
        "NEW" -> t("নতুন", "New"); "CONFIRMED" -> t("নিশ্চিত", "Confirmed"); "SHIPPED" -> t("শিপড", "Shipped")
        "DELIVERED" -> t("ডেলিভারি হয়েছে", "Delivered"); "CANCELLED" -> t("বাতিল", "Cancelled"); else -> c
    }
    fun actionLabel(c: String) = when (c) {
        "CONFIRMED" -> t("নিশ্চিত করুন", "Confirm"); "SHIPPED" -> t("শিপ করুন", "Mark shipped")
        "DELIVERED" -> t("ডেলিভারি হয়েছে", "Mark delivered"); "CANCELLED" -> t("বাতিল করুন", "Cancel order"); else -> c
    }
    fun paymentLabel(c: String) = when (c) {
        "CASH" -> t("ক্যাশ", "Cash"); "BKASH" -> t("বিকাশ", "bKash"); "NAGAD" -> t("নগদ", "Nagad")
        "ROCKET" -> t("রকেট", "Rocket"); "BANK" -> t("ব্যাংক", "Bank"); else -> t("অন্যান্য", "Other")
    }

    val finance = t("ফাইন্যান্স", "Finance")
    val moreFinance = t("ফাইন্যান্স (খরচ ও মুনাফা)", "Finance (expenses & profit)")
    val periodToday = t("আজ", "Today"); val periodWeek = t("৭ দিন", "7 days")
    val periodMonth = t("এই মাস", "This month"); val periodAll = t("সব", "All")
    val productSales = t("পণ্য বিক্রি (ছাড়ের পরে)", "Product sales (after discount)")
    val deliveryCollected = t("ডেলিভারি চার্জ আদায়", "Delivery charge collected")
    val revenue = t("মোট আয়", "Total revenue")
    val cogs = t("পণ্যের ক্রয় খরচ", "Cost of goods sold")
    val grossProfit = t("মোট মুনাফা", "Gross profit")
    val expensesTotal = t("খরচ", "Expenses")
    val netProfit = t("নিট মুনাফা", "Net profit")
    val basisNote = t("হিসাবের ভিত্তি: ডেলিভারি হওয়া অর্ডার। নতুন বা বাতিল অর্ডার ধরা হয় না। পণ্য কেনার খরচ আলাদা খরচ হিসেবে নেই, কারণ ক্রয় মূল্য আগেই পণ্যের খরচে ধরা হয়েছে।",
        "Basis: delivered orders only. New or cancelled orders are not counted. Product purchases are not entered as expenses because cost of goods is already counted.")
    val missingCost = t("সতর্কতা: কিছু বিক্রিত পণ্যের ক্রয় মূল্য ০ আছে, তাই মুনাফা বেশি দেখাতে পারে। ইনভেন্টরিতে ক্রয় মূল্য বসান।",
        "Warning: some sold products have cost 0, so profit may look too high. Set purchase costs in Inventory.")
    val newExpense = t("নতুন খরচ", "New expense")
    val category = t("খরচের ধরন", "Category")
    val amount = t("পরিমাণ (৳)", "Amount (৳)")
    val description = t("বিবরণ", "Description")
    val noExpenses = t("এই সময়ে কোনো খরচ নেই। নিচের + চাপ দিয়ে যোগ করুন।", "No expenses in this period. Tap + to add one.")
    val expenseList = t("খরচের তালিকা", "Expenses")
    val voidTitle = t("খরচটি বাতিল করবেন?", "Void this expense?")
    val voidYes = t("বাতিল করুন", "Void")
    val amountRequired = t("সঠিক পরিমাণ দিন (০-এর বেশি)", "Enter a valid amount (more than 0)")
    val todayExpenses = t("আজকের খরচ", "Today's expenses")
    val todayNet = t("আজকের নিট মুনাফা", "Today's net profit")

    fun categoryLabel(c: String) = when (c) {
        "FACEBOOK_ADS" -> t("ফেসবুক বিজ্ঞাপন", "Facebook Ads"); "INSTAGRAM_ADS" -> t("ইনস্টাগ্রাম বিজ্ঞাপন", "Instagram Ads")
        "GOOGLE_ADS" -> t("গুগল বিজ্ঞাপন", "Google Ads"); "TIKTOK_ADS" -> t("টিকটক বিজ্ঞাপন", "TikTok Ads")
        "COURIER" -> t("কুরিয়ার চার্জ", "Courier charges"); "PACKAGING" -> t("প্যাকেজিং", "Packaging")
        "TRANSPORT" -> t("পরিবহন", "Transport"); "GATEWAY_FEE" -> t("পেমেন্ট/মোবাইল ব্যাংকিং ফি", "Payment / mobile banking fee")
        "SALARY" -> t("বেতন", "Salary"); "INTERNET" -> t("ইন্টারনেট", "Internet"); "ELECTRICITY" -> t("বিদ্যুৎ", "Electricity")
        "TRAVEL" -> t("যাতায়াত", "Travel"); "STORAGE" -> t("গুদাম/স্টোরেজ", "Storage")
        "SOFTWARE" -> t("সফটওয়্যার সাবস্ক্রিপশন", "Software subscriptions"); "DAMAGE" -> t("পণ্য নষ্ট", "Product damage")
        else -> t("অন্যান্য খরচ", "Other expenses")
    }
}
