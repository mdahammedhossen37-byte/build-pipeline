package com.dudhia.manager.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.dudhia.manager.core.*
import com.dudhia.manager.database.*
import com.dudhia.manager.ui.theme.DudhiaColors

private data class Line(val productId: Long?, val qty: String)
internal data class Opt<T>(val value: T, val title: String, val sub: String? = null)

/** Dropdown where each option has a title and an optional second line (e.g. customer name, then phone). */
@Composable
internal fun <T> Picker(label: String, options: List<Opt<T>>, selected: T?, onSelect: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val cur = options.firstOrNull { it.value == selected }
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
                if (cur == null) {
                    Text("—")
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(cur.title)
                        if (cur.sub != null) Text(cur.sub, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { o ->
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(o.title)
                                if (o.sub != null) Text(o.sub, style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        },
                        onClick = { onSelect(o.value); open = false })
                }
            }
        }
    }
}

@Composable
private fun OrderFormDialog(
    s: Strings, customers: List<CustomerEntity>, products: List<ProductEntity>, serverError: String?,
    onDismiss: () -> Unit, onSubmit: (OrderEntity, List<OrderItemEntity>) -> Unit
) {
    var customerId by remember { mutableStateOf<Long?>(null) }
    val lines = remember { mutableStateListOf(Line(null, "")) }
    var discount by remember { mutableStateOf("") }
    var delivery by remember { mutableStateOf("") }
    var payment by remember { mutableStateOf("CASH") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val byId = remember(products) { products.associateBy { it.id } }

    val subtotal: Long = lines.sumOf { l ->
        val p = l.productId?.let { byId[it] }
        val q = Qty.parseMilli(l.qty)
        if (p != null && q != null && q > 0) lineTotalPaisa(p.pricePaisa, q) else 0L
    }
    val discP = Money.parse(discount)?.paisa ?: 0L
    val delP = Money.parse(delivery)?.paisa ?: 0L

    FormScaffold(
        title = s.newOrder, confirmText = s.save, cancelText = s.cancel, onDismiss = onDismiss,
        onConfirm = {
            val cid = customerId
            val disc = if (discount.isBlank()) Money.ZERO else Money.parse(discount)
            val del = if (delivery.isBlank()) Money.ZERO else Money.parse(delivery)
            if (cid == null) {
                error = s.pickCustomer
            } else if (disc == null || del == null || disc.paisa < 0 || del.paisa < 0) {
                error = s.invalidNumber
            } else {
                val items = mutableListOf<OrderItemEntity>()
                var bad: String? = null
                for (l in lines) {
                    val p = l.productId?.let { byId[it] }
                    val q = Qty.parseMilli(l.qty)
                    if (p == null || q == null || q <= 0) { bad = s.fixLines; break }
                    if (p.pricePaisa <= 0) { bad = s.setPriceFirst; break }
                    items.add(OrderItemEntity(
                        orderId = 0, productId = p.id, productName = p.nameBn.ifBlank { p.nameEn },
                        quantityMilli = q, unitPricePaisa = p.pricePaisa, unitCostPaisa = p.costPaisa,
                        lineTotalPaisa = lineTotalPaisa(p.pricePaisa, q)))
                }
                val sub = items.sumOf { it.lineTotalPaisa }
                if (bad != null) {
                    error = bad
                } else if (disc.paisa > sub) {
                    error = s.discountTooBig
                } else {
                    error = null
                    val now = System.currentTimeMillis()
                    onSubmit(OrderEntity(
                        customerId = cid, orderDate = now, status = "NEW", subtotalPaisa = sub,
                        discountPaisa = disc.paisa, deliveryChargePaisa = del.paisa,
                        totalPaisa = sub - disc.paisa + del.paisa, paymentMethod = payment,
                        paymentStatus = "UNPAID", notes = notes.trim().ifBlank { null },
                        createdAt = now, updatedAt = now), items)
                }
            }
        }
    ) {
        Picker(s.customerLabel, customers.map { Opt(it.id, it.name, it.phone) }, customerId) { customerId = it }
        lines.forEachIndexed { i, line ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Picker(s.product,
                        products.map { Opt(it.id, if (s.bn) it.nameBn else it.nameEn,
                            "${s.unitLabel(it.unit)} · ${Money(it.pricePaisa).format()}") },
                        line.productId) { lines[i] = line.copy(productId = it) }
                    OutlinedTextField(
                        value = line.qty, onValueChange = { lines[i] = line.copy(qty = it) },
                        label = { Text(s.quantity) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth())
                    if (lines.size > 1) TextButton(onClick = { lines.removeAt(i) }) { Text(s.remove) }
                }
            }
        }
        TextButton(onClick = { lines.add(Line(null, "")) }) { Text(s.addLine) }
        Field(s.discount, discount, { discount = it }, KeyboardType.Decimal)
        Field(s.deliveryCharge, delivery, { delivery = it }, KeyboardType.Decimal)
        Picker(s.payment, PAYMENT_METHODS.map { Opt(it, s.paymentLabel(it)) }, payment) { payment = it }
        Field(s.notes, notes, { notes = it }, single = false)
        Text("${s.subtotal}: ${Money(subtotal).format()}")
        Text("${s.total}: ${Money(subtotal - discP + delP).format()}", style = MaterialTheme.typography.titleMedium)
        val shown = error ?: if (serverError != null) s.saveFailed else null
        shown?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
fun OrdersScreen(
    s: Strings,
    orders: List<OrderEntity>,
    customers: List<CustomerEntity>,
    products: List<ProductEntity>,
    loadItems: suspend (Long) -> List<OrderItemEntity>,
    onCreate: (OrderEntity, List<OrderItemEntity>, (String?) -> Unit) -> Unit,
    onStatus: (Long, String, (String?) -> Unit) -> Unit,
    onPaid: (Long) -> Unit
) {
    var filter by remember { mutableStateOf<String?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var formError by remember { mutableStateOf<String?>(null) }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var confirm by remember { mutableStateOf<String?>(null) }
    var actionError by remember { mutableStateOf<String?>(null) }
    val byCustomer = remember(customers) { customers.associateBy { it.id } }
    val shown = remember(orders, filter) { if (filter == null) orders else orders.filter { it.status == filter } }

    fun errText(e: String): String = when {
        e == "invalid" -> s.invalidMove
        e.startsWith("stock:") -> s.noStock + e.removePrefix("stock:")
        else -> s.saveFailed
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text(s.orders, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = filter == null, onClick = { filter = null }, label = { Text(s.all) })
                OrderRules.STATUSES.forEach { st ->
                    FilterChip(selected = filter == st, onClick = { filter = st }, label = { Text(s.statusLabel(st)) })
                }
            }
            Spacer(Modifier.height(8.dp))
            if (orders.isEmpty()) Text(s.noOrders, color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                items(shown, key = { it.id }) { o ->
                    val c = byCustomer[o.customerId]
                    Card(Modifier.fillMaxWidth().clickable { selectedId = o.id; actionError = null }) {
                        Column(Modifier.padding(12.dp)) {
                            Text(c?.name ?: "?", style = MaterialTheme.typography.titleMedium)
                            if (c != null) Text(c.phone, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("#${o.id} · ${Money(o.totalPaisa).format()}", style = MaterialTheme.typography.titleSmall)
                            val col = when (o.status) {
                                "DELIVERED" -> DudhiaColors.Success; "CANCELLED" -> DudhiaColors.Error
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                            Text("${s.statusLabel(o.status)} · ${if (o.paymentStatus == "PAID") s.paid else s.unpaid}", color = col)
                        }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { formError = null; showForm = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = s.newOrder) }

        if (showForm) {
            if (customers.isEmpty()) {
                AlertDialog(onDismissRequest = { showForm = false }, text = { Text(s.needCustomerFirst) },
                    confirmButton = { TextButton(onClick = { showForm = false }) { Text(s.close) } })
            } else {
                OrderFormDialog(s, customers, products, formError, onDismiss = { showForm = false },
                    onSubmit = { o, its -> onCreate(o, its) { err -> if (err == null) showForm = false else formError = err } })
            }
        }
    }

    val sel = selectedId?.let { id -> orders.firstOrNull { it.id == id } }
    if (sel != null) {
        var its by remember(sel.id) { mutableStateOf<List<OrderItemEntity>>(emptyList()) }
        LaunchedEffect(sel.id) { its = loadItems(sel.id) }
        val cust = byCustomer[sel.customerId]
        AlertDialog(
            onDismissRequest = { selectedId = null; actionError = null },
            title = { Text("#${sel.id} · ${s.statusLabel(sel.status)}") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(cust?.name ?: "?", style = MaterialTheme.typography.titleMedium)
                    cust?.let { Text(it.phone, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    its.forEach { Text("${it.productName} × ${Qty.format(it.quantityMilli)} = ${Money(it.lineTotalPaisa).format()}") }
                    Text("${s.subtotal}: ${Money(sel.subtotalPaisa).format()}")
                    if (sel.discountPaisa > 0) Text("${s.discount}: -${Money(sel.discountPaisa).format()}")
                    if (sel.deliveryChargePaisa > 0) Text("${s.deliveryCharge}: ${Money(sel.deliveryChargePaisa).format()}")
                    Text("${s.total}: ${Money(sel.totalPaisa).format()}", style = MaterialTheme.typography.titleMedium)
                    Text("${s.paymentLabel(sel.paymentMethod)} · ${if (sel.paymentStatus == "PAID") s.paid else s.unpaid}")
                    sel.notes?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    if (sel.paymentStatus != "PAID" && sel.status != "CANCELLED") {
                        OutlinedButton(onClick = { onPaid(sel.id) }, modifier = Modifier.fillMaxWidth()) { Text(s.markPaid) }
                    }
                    OrderRules.next(sel.status).forEach { st ->
                        Button(
                            onClick = {
                                if (st == "DELIVERED" || st == "CANCELLED") confirm = st
                                else onStatus(sel.id, st) { err -> actionError = err?.let { e -> errText(e) } }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(s.actionLabel(st)) }
                    }
                    actionError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = { TextButton(onClick = { selectedId = null; actionError = null }) { Text(s.close) } }
        )
        confirm?.let { st ->
            AlertDialog(
                onDismissRequest = { confirm = null },
                title = { Text(s.confirmTitle) },
                text = { Text(if (st == "DELIVERED") s.confirmDeliver else s.confirmCancel) },
                confirmButton = {
                    TextButton(onClick = {
                        confirm = null
                        onStatus(sel.id, st) { err -> actionError = err?.let { e -> errText(e) } }
                    }) { Text(s.yes) }
                },
                dismissButton = { TextButton(onClick = { confirm = null }) { Text(s.cancel) } }
            )
        }
    }
}
