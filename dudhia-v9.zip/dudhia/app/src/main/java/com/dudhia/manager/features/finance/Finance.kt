package com.dudhia.manager.features.finance

import com.dudhia.manager.core.lineTotalPaisa
import com.dudhia.manager.database.*

data class PnL(
    val productSales: Long,        // product subtotal minus discounts, delivered orders only
    val deliveryCollected: Long,   // delivery charge collected from customers (revenue)
    val revenue: Long,
    val cogs: Long,                // cost of goods sold, from the cost saved on each order line
    val grossProfit: Long,
    val expenses: Long,            // operating expenses (ads, courier, packaging...), voided ones excluded
    val netProfit: Long,
    val deliveredCount: Int,
    val missingCostLines: Int      // sold lines with cost 0: profit may be overstated
)

object Finance {
    /** Delivery-based (accrual-style) basis: only DELIVERED orders count, in the period by delivery time. */
    fun compute(orders: List<OrderEntity>, items: List<OrderItemEntity>, expenses: List<ExpenseEntity>, from: Long, to: Long): PnL {
        val delivered = orders.filter { o ->
            o.deletedAt == null && o.status == "DELIVERED" &&
                (o.deliveredAt ?: -1L) >= from && (o.deliveredAt ?: -1L) < to
        }
        val ids = delivered.map { it.id }.toSet()
        val sales = delivered.sumOf { it.subtotalPaisa - it.discountPaisa }
        val delivery = delivered.sumOf { it.deliveryChargePaisa }
        val its = items.filter { it.orderId in ids }
        val cogs = its.sumOf { lineTotalPaisa(it.unitCostPaisa, it.quantityMilli) }
        val missing = its.count { it.unitCostPaisa == 0L }
        val exp = expenses.filter { it.deletedAt == null && it.expenseDate >= from && it.expenseDate < to }
            .sumOf { it.amountPaisa }
        val revenue = sales + delivery
        val gross = revenue - cogs
        return PnL(sales, delivery, revenue, cogs, gross, exp, gross - exp, delivered.size, missing)
    }
}
