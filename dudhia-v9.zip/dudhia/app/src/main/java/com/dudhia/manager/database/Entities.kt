package com.dudhia.manager.database

import androidx.room.*

@Entity(tableName = "customers", indices = [Index("phone")])
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val altPhone: String? = null,
    val address: String? = null,
    val area: String? = null,
    val district: String? = null,
    val notes: String? = null,
    val type: String = "REGULAR",
    val status: String = "ACTIVE",
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null
)

@Entity(tableName = "products", indices = [Index("sku", unique = true)])
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nameBn: String,
    val nameEn: String,
    val sku: String,
    val category: String? = null,
    val unit: String,                 // PIECE, GRAM, KG, ML, LITER, PACK, BOX
    val costPaisa: Long = 0,
    val pricePaisa: Long = 0,
    val stockMilli: Long = 0,         // quantity x1000, avoids floats
    val minStockMilli: Long = 0,
    val status: String = "ACTIVE",
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null
)

@Entity(tableName = "app_settings")
data class AppSettingEntity(@PrimaryKey val key: String, val value: String)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val actor: String,        // USER, AI, AUTOMATION, SYSTEM
    val action: String,
    val detail: String? = null
)

@Entity(tableName = "orders", indices = [Index("customerId"), Index("status")])
data class OrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val orderDate: Long,
    val status: String,               // NEW, CONFIRMED, SHIPPED, DELIVERED, CANCELLED
    val subtotalPaisa: Long,
    val discountPaisa: Long,
    val deliveryChargePaisa: Long,
    val totalPaisa: Long,
    val paymentMethod: String,
    val paymentStatus: String,        // UNPAID, PAID
    val notes: String? = null,
    val stockDeducted: Boolean = false,
    val deliveredAt: Long? = null,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null
)

@Entity(
    tableName = "order_items",
    foreignKeys = [ForeignKey(entity = OrderEntity::class, parentColumns = ["id"], childColumns = ["orderId"])],
    indices = [Index("orderId"), Index("productId")]
)
data class OrderItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderId: Long,
    val productId: Long,
    val productName: String,
    val quantityMilli: Long,
    val unitPricePaisa: Long,
    val unitCostPaisa: Long,
    val lineTotalPaisa: Long
)

@Entity(tableName = "stock_movements", indices = [Index("productId")])
data class StockMovementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val deltaMilli: Long,
    val reason: String,
    val refType: String? = null,
    val refId: Long? = null,
    val createdAt: Long
)

@Entity(tableName = "expenses", indices = [Index("expenseDate"), Index("category")])
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val expenseDate: Long,
    val category: String,
    val amountPaisa: Long,
    val paymentMethod: String,
    val description: String? = null,
    val createdAt: Long,
    val deletedAt: Long? = null       // set when an expense is voided; records are never hard-deleted
)
