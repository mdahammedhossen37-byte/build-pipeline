package com.dudhia.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.compose.*
import com.dudhia.manager.core.Strings
import com.dudhia.manager.core.periodRange
import com.dudhia.manager.features.finance.Finance
import com.dudhia.manager.features.settings.AppViewModel
import com.dudhia.manager.ui.screens.*
import com.dudhia.manager.ui.theme.DudhiaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = (application as DudhiaApp).db
        setContent {
            val vm: AppViewModel = viewModel(factory = viewModelFactory { initializer { AppViewModel(db) } })
            DudhiaTheme { AppRoot(vm) }
        }
    }
}

private data class Tab(val route: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppRoot(vm: AppViewModel) {
    val bn by vm.languageBn.collectAsStateWithLifecycle()
    val onboarded by vm.onboarded.collectAsStateWithLifecycle()
    val customers by vm.customerCount.collectAsStateWithLifecycle()
    val products by vm.products.collectAsStateWithLifecycle()
    val customerList by vm.customers.collectAsStateWithLifecycle()
    val orders by vm.orders.collectAsStateWithLifecycle()
    val allItems by vm.orderItemsAll.collectAsStateWithLifecycle()
    val expenses by vm.expenses.collectAsStateWithLifecycle()
    val s = remember(bn) { Strings(bn) }

    when (onboarded) {
        null -> return
        false -> { Surface { Onboarding(s) { vm.finishOnboarding() } }; return }
        else -> {}
    }
    val nav = rememberNavController()
    val tabs = listOf(
        Tab("dashboard", Icons.Default.Home), Tab("crm", Icons.Default.People),
        Tab("orders", Icons.Default.ShoppingCart), Tab("inventory", Icons.Default.Inventory2),
        Tab("more", Icons.Default.Menu)
    )
    fun label(r: String) = when (r) {
        "dashboard" -> s.dashboard; "crm" -> s.crm; "orders" -> s.orders
        "inventory" -> s.inventory; else -> s.more
    }
    val current = nav.currentBackStackEntryAsState().value?.destination?.route
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEach { t ->
                NavigationBarItem(
                    selected = current == t.route || (t.route == "more" && (current == "finance" || current == "settings")), label = { Text(label(t.route)) },
                    icon = { Icon(t.icon, null) },
                    onClick = { nav.navigate(t.route) { popUpTo("dashboard"); launchSingleTop = true; restoreState = true } }
                )
            }
        }
    }) { pad ->
        NavHost(nav, startDestination = "dashboard", modifier = Modifier.padding(pad)) {
            composable("dashboard") {
                val today = periodRange("TODAY")
                val pnl = Finance.compute(orders, allItems, expenses, today.first, today.second)
                DashboardScreen(
                    s, customers, products.size,
                    products.count { it.minStockMilli > 0 && it.stockMilli <= it.minStockMilli },
                    pnl.revenue, pnl.expenses, pnl.netProfit,
                    orders.count { it.status == "NEW" || it.status == "CONFIRMED" || it.status == "SHIPPED" },
                    orders.count { it.status == "DELIVERED" },
                    orders.count { it.status == "CANCELLED" })
            }
            composable("crm") { CrmScreen(s, customerList, { vm.findByPhone(it) }, { vm.saveCustomer(it) }) }
            composable("orders") {
                OrdersScreen(s, orders, customerList, products, { vm.orderItems(it) },
                    { o, its, done -> vm.createOrder(o, its, done) },
                    { id, st, done -> vm.changeStatus(id, st, done) },
                    { vm.markPaid(it) })
            }
            composable("inventory") { InventoryScreen(s, products) { p, done -> vm.saveProduct(p, done) } }
            composable("more") { MoreScreen(s, { nav.navigate("finance") }, { nav.navigate("settings") }) }
            composable("settings") { SettingsScreen(s) { vm.setLanguage(it) } }
            composable("finance") {
                FinanceScreen(s, orders, allItems, expenses, { vm.addExpense(it) }, { vm.voidExpense(it) })
            }
        }
    }
}
