package com.dudhia.manager.core

import java.util.Calendar

val EXPENSE_CATEGORIES = listOf(
    "FACEBOOK_ADS", "INSTAGRAM_ADS", "GOOGLE_ADS", "TIKTOK_ADS", "COURIER", "PACKAGING",
    "TRANSPORT", "GATEWAY_FEE", "SALARY", "INTERNET", "ELECTRICITY", "TRAVEL", "STORAGE",
    "SOFTWARE", "DAMAGE", "OTHER"
)

/** [from, to) in epoch millis for TODAY, WEEK (last 7 days incl. today), MONTH (this month) or ALL. */
fun periodRange(code: String): Pair<Long, Long> {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    return when (code) {
        "TODAY" -> { val a = c.timeInMillis; c.add(Calendar.DAY_OF_YEAR, 1); a to c.timeInMillis }
        "WEEK" -> { c.add(Calendar.DAY_OF_YEAR, -6); val a = c.timeInMillis; c.add(Calendar.DAY_OF_YEAR, 7); a to c.timeInMillis }
        "MONTH" -> { c.set(Calendar.DAY_OF_MONTH, 1); val a = c.timeInMillis; c.add(Calendar.MONTH, 1); a to c.timeInMillis }
        else -> 0L to Long.MAX_VALUE
    }
}
