package com.dudhia.manager.core

import org.junit.Assert.*
import org.junit.Test

class OrderRulesTest {
    @Test fun lineTotals() {
        assertEquals(75000L, lineTotalPaisa(30000, 2500))
        assertEquals(5001L, lineTotalPaisa(10001, 500))
        assertEquals(60000L, lineTotalPaisa(30000, 2000))
    }
    @Test fun statusFlow() {
        assertTrue(OrderRules.canMove("NEW", "CONFIRMED"))
        assertTrue(OrderRules.canMove("CONFIRMED", "DELIVERED"))
        assertFalse(OrderRules.canMove("DELIVERED", "CANCELLED"))
        assertFalse(OrderRules.canMove("CANCELLED", "NEW"))
        assertFalse(OrderRules.canMove("NEW", "DELIVERED"))
    }
}
