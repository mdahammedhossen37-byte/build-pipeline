package com.dudhia.manager.features.finance

import com.dudhia.manager.database.*
import org.junit.Assert.*
import org.junit.Test

class FinanceTest {
    private fun order(id: Long, deliveredAt: Long?, status: String = "DELIVERED") = OrderEntity(
        id = id, customerId = 1, orderDate = 0, status = status, subtotalPaisa = 30000, discountPaisa = 0,
        deliveryChargePaisa = 10000, totalPaisa = 40000, paymentMethod = "CASH", paymentStatus = "PAID",
        deliveredAt = deliveredAt, createdAt = 0, updatedAt = 0)
    private fun item(orderId: Long, cost: Long) = OrderItemEntity(
        orderId = orderId, productId = 1, productName = "x", quantityMilli = 1000,
        unitPricePaisa = 30000, unitCostPaisa = cost, lineTotalPaisa = 30000)
    private fun exp(amount: Long, at: Long, deleted: Long? = null) = ExpenseEntity(
        expenseDate = at, category = "COURIER", amountPaisa = amount, paymentMethod = "CASH",
        createdAt = 0, deletedAt = deleted)

    @Test fun deliveredOrderProfit() {
        val r = Finance.compute(listOf(order(1, 100)), listOf(item(1, 15000)), listOf(exp(5000, 100)), 0, 1000)
        assertEquals(30000L, r.productSales)
        assertEquals(10000L, r.deliveryCollected)
        assertEquals(40000L, r.revenue)
        assertEquals(15000L, r.cogs)
        assertEquals(25000L, r.grossProfit)
        assertEquals(5000L, r.expenses)
        assertEquals(20000L, r.netProfit)
        assertEquals(0, r.missingCostLines)
    }
    @Test fun newCancelledAndVoidedAreIgnored() {
        val orders = listOf(order(1, null, "NEW"), order(2, null, "CANCELLED"))
        val r = Finance.compute(orders, listOf(item(1, 1), item(2, 1)), listOf(exp(5000, 100, deleted = 5)), 0, 1000)
        assertEquals(0L, r.revenue)
        assertEquals(0L, r.expenses)
        assertEquals(0, r.deliveredCount)
    }
    @Test fun outsidePeriodIsIgnoredAndMissingCostFlagged() {
        val r = Finance.compute(listOf(order(1, 5000)), listOf(item(1, 0)), emptyList(), 0, 1000)
        assertEquals(0L, r.revenue)
        val r2 = Finance.compute(listOf(order(1, 500)), listOf(item(1, 0)), emptyList(), 0, 1000)
        assertEquals(1, r2.missingCostLines)
    }
}
