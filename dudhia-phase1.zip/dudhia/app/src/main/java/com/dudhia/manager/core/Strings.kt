package com.dudhia.manager.core

/** Minimal bilingual labels for Phase 1. Will move to Android string resources when screens multiply. */
class Strings(val bn: Boolean) {
    private fun t(b: String, e: String) = if (bn) b else e
    val dashboard = t("ড্যাশবোর্ড", "Dashboard")
    val crm = t("কাস্টমার", "CRM")
    val orders = t("অর্ডার", "Orders")
    val inventory = t("ইনভেন্টরি", "Inventory")
    val more = t("আরও", "More")
    val settings = t("সেটিংস", "Settings")
    val language = t("ভাষা", "Language")
    val bengali = "বাংলা"; val english = "English"
    val customers = t("মোট কাস্টমার", "Total customers")
    val products = t("মোট পণ্য", "Total products")
    val comingSoon = t("এই মডিউল পরবর্তী ধাপে আসবে", "This module is not implemented yet")
    val noProducts = t("কোনো পণ্য নেই", "No products yet")
    val welcomeTitle = t("দুধিয়া এআই বিজনেস ম্যানেজার", "Dudhia AI Business Manager")
    val welcomeBody = t(
        "আপনার ব্যবসার সব তথ্য এই ফোনেই থাকে, ইন্টারনেট ছাড়াই কাজ করে।",
        "Your business data stays on this phone and works without internet.")
    val start = t("শুরু করুন", "Get started")
}
