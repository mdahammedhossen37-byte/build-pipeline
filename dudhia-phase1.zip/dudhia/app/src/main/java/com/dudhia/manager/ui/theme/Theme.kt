package com.dudhia.manager.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object DudhiaColors {
    val Cream = Color(0xFFF5EBDD); val LightCream = Color(0xFFFFF9EF)
    val Gold = Color(0xFFC6A15B); val DeepGold = Color(0xFFA77B32)
    val Text = Color(0xFF403629); val TextSecondary = Color(0xFF817565)
    val Success = Color(0xFF26845B); val Warning = Color(0xFFD69A36); val Error = Color(0xFFC54B4B)
}

private val Light = lightColorScheme(
    primary = DudhiaColors.DeepGold, onPrimary = Color.White,
    secondary = DudhiaColors.Gold, background = DudhiaColors.Cream, onBackground = DudhiaColors.Text,
    surface = DudhiaColors.LightCream, onSurface = DudhiaColors.Text,
    onSurfaceVariant = DudhiaColors.TextSecondary, error = DudhiaColors.Error
)
private val Dark = darkColorScheme(
    primary = DudhiaColors.Gold, onPrimary = Color(0xFF2A2218),
    background = Color(0xFF1E1A14), surface = Color(0xFF2A251D),
    onBackground = DudhiaColors.Cream, onSurface = DudhiaColors.Cream, error = DudhiaColors.Error
)
private val Shapes = Shapes(
    small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(24.dp)
)

@Composable
fun DudhiaTheme(dark: Boolean = false, content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = if (dark) Dark else Light, shapes = Shapes, content = content)
