package com.dudhia.manager.features.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dudhia.manager.database.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class AppViewModel(private val db: AppDatabase) : ViewModel() {
    val languageBn: StateFlow<Boolean> = db.settings().observe("language")
        .map { it != "en" }                       // default Bengali
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val onboarded: StateFlow<Boolean?> = db.settings().observe("onboarded")
        .map { it == "1" }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val customerCount = db.customers().observeCount().stateIn(viewModelScope, SharingStarted.Lazily, 0)
    val products = db.products().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun setLanguage(bn: Boolean) = viewModelScope.launch {
        db.settings().put(AppSettingEntity("language", if (bn) "bn" else "en"))
        db.audit().insert(AuditLogEntity(timestamp = System.currentTimeMillis(), actor = "USER",
            action = "SET_LANGUAGE", detail = if (bn) "bn" else "en"))
    }
    fun finishOnboarding() = viewModelScope.launch { db.settings().put(AppSettingEntity("onboarded", "1")) }
}
