package com.dudhia.manager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.dudhia.manager.core.*
import com.dudhia.manager.database.ProductEntity

@Composable
fun Onboarding(s: Strings, onStart: () -> Unit) = Column(
    Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
    horizontalAlignment = Alignment.CenterHorizontally
) {
    Text(s.welcomeTitle, style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(12.dp))
    Text(s.welcomeBody, style = MaterialTheme.typography.bodyLarge)
    Spacer(Modifier.height(24.dp))
    Button(onClick = onStart) { Text(s.start) }
}

@Composable
private fun StatCard(label: String, value: String, mod: Modifier = Modifier) =
    Card(mod, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.headlineSmall)
        }
    }

@Composable
fun DashboardScreen(s: Strings, customers: Int, products: Int) = Column(
    Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
) {
    Text(s.dashboard, style = MaterialTheme.typography.titleLarge)
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCard(s.customers, customers.toString(), Modifier.weight(1f))
        StatCard(s.products, products.toString(), Modifier.weight(1f))
    }
    // Sales/profit tiles arrive with Orders and Finance modules; no fake numbers are shown.
}

@Composable
fun InventoryScreen(s: Strings, products: List<ProductEntity>) = Column(Modifier.fillMaxSize().padding(16.dp)) {
    Text(s.inventory, style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    if (products.isEmpty()) Text(s.noProducts) else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(products, key = { it.id }) { p ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(if (s.bn) p.nameBn else p.nameEn, style = MaterialTheme.typography.titleMedium)
                    Text("${p.sku} · ${p.unit} · ${Money(p.pricePaisa).format()}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun PlaceholderScreen(title: String, s: Strings) = Column(
    Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
    horizontalAlignment = Alignment.CenterHorizontally
) {
    Text(title, style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    Text(s.comingSoon, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun SettingsScreen(s: Strings, onLanguage: (Boolean) -> Unit) = Column(Modifier.fillMaxSize().padding(16.dp)) {
    Text(s.settings, style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(16.dp))
    Text(s.language, style = MaterialTheme.typography.titleMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = s.bn, onClick = { onLanguage(true) }, label = { Text(s.bengali) })
        FilterChip(selected = !s.bn, onClick = { onLanguage(false) }, label = { Text(s.english) })
    }
}
