package com.dudhia.manager.backup

import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import com.dudhia.manager.database.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Backup = a copy of the SQLite database file, saved wherever the user picks (Storage Access Framework). */
object BackupManager {
    const val DB_NAME = "dudhia.db"
    /** Keep in sync with @Database(version = ...) in AppDatabase. */
    const val CURRENT_DB_VERSION = 8

    data class BackupInfo(
        val sizeBytes: Long, val userVersion: Int,
        val customers: Int, val products: Int, val orders: Int, val tempPath: String
    )

    private fun checkpoint(db: AppDatabase) {
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { it.moveToFirst() }
    }

    suspend fun export(ctx: Context, db: AppDatabase, uri: Uri): Result<Long> = withContext(Dispatchers.IO) {
        runCatching {
            checkpoint(db)   // flush pending writes into the main file before copying
            val file = ctx.getDatabasePath(DB_NAME)
            val out = ctx.contentResolver.openOutputStream(uri, "wt") ?: error("cannot open output")
            out.use { o -> file.inputStream().use { i -> i.copyTo(o) } }
            file.length()
        }
    }

    /** Copies the chosen file to a temp location and checks it is a valid Dudhia database. Nothing is replaced yet. */
    suspend fun inspect(ctx: Context, uri: Uri): Result<BackupInfo> = withContext(Dispatchers.IO) {
        runCatching {
            val tmp = File(ctx.cacheDir, "restore_candidate.db")
            tmp.delete(); File(tmp.path + "-wal").delete(); File(tmp.path + "-shm").delete()
            val input = ctx.contentResolver.openInputStream(uri) ?: error("cannot open input")
            input.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            val head = ByteArray(15)
            tmp.inputStream().use { it.read(head) }
            require(String(head, Charsets.US_ASCII) == "SQLite format 3") { "not a database" }
            val sdb = SQLiteDatabase.openDatabase(tmp.path, null, SQLiteDatabase.OPEN_READONLY)
            try {
                val v = sdb.version
                require(v in 1..CURRENT_DB_VERSION) { "unsupported version $v" }
                fun count(table: String): Int = try {
                    sdb.rawQuery("SELECT COUNT(*) FROM $table", null).use { c -> c.moveToFirst(); c.getInt(0) }
                } catch (e: Exception) { -1 }
                val cust = count("customers")
                val prod = count("products")
                require(cust >= 0 && prod >= 0) { "missing tables" }
                BackupInfo(tmp.length(), v, cust, prod, maxOf(count("orders"), 0), tmp.path)
            } finally {
                sdb.close()
            }
        }
    }

    /** Keeps a safety copy of the current data (files/before_restore.db), then replaces the database. Restart the app after. */
    suspend fun restore(ctx: Context, db: AppDatabase, info: BackupInfo): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val live = ctx.getDatabasePath(DB_NAME)
            val src = File(info.tempPath)
            require(src.exists()) { "candidate missing" }
            checkpoint(db)
            val safety = File(ctx.filesDir, "before_restore.db")
            live.copyTo(safety, overwrite = true)
            db.close()
            try {
                File(live.path + "-wal").delete(); File(live.path + "-shm").delete(); File(live.path + "-journal").delete()
                File(src.path + "-wal").delete(); File(src.path + "-shm").delete()
                src.copyTo(live, overwrite = true)
            } catch (e: Exception) {
                safety.copyTo(live, overwrite = true)   // roll back
                throw e
            }
            Unit
        }
    }

    fun restartApp(ctx: Context) {
        val intent = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            ctx.startActivity(intent)
        }
        Runtime.getRuntime().exit(0)
    }
}
