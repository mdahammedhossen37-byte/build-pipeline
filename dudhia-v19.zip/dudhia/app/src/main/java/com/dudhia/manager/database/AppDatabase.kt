package com.dudhia.manager.database

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        CustomerEntity::class, ProductEntity::class, AppSettingEntity::class, AuditLogEntity::class,
        OrderEntity::class, OrderItemEntity::class, StockMovementEntity::class, ExpenseEntity::class,
        SupplierEntity::class, PurchaseEntity::class, CampaignEntity::class, TaskEntity::class,
        ReturnEntity::class, ReturnItemEntity::class
    ],
    version = 8, exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun customers(): CustomerDao
    abstract fun products(): ProductDao
    abstract fun settings(): SettingDao
    abstract fun audit(): AuditDao
    abstract fun orders(): OrderDao
    abstract fun stock(): StockDao
    abstract fun expenses(): ExpenseDao
    abstract fun suppliers(): SupplierDao
    abstract fun purchases(): PurchaseDao
    abstract fun campaigns(): CampaignDao
    abstract fun tasks(): TaskDao
    abstract fun returns(): ReturnDao

    companion object {
        /** Adds orders, order_items, stock_movements. Existing data is untouched. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `orders` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `customerId` INTEGER NOT NULL, `orderDate` INTEGER NOT NULL, `status` TEXT NOT NULL, `subtotalPaisa` INTEGER NOT NULL, `discountPaisa` INTEGER NOT NULL, `deliveryChargePaisa` INTEGER NOT NULL, `totalPaisa` INTEGER NOT NULL, `paymentMethod` TEXT NOT NULL, `paymentStatus` TEXT NOT NULL, `notes` TEXT, `stockDeducted` INTEGER NOT NULL, `deliveredAt` INTEGER, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, `deletedAt` INTEGER)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_orders_customerId` ON `orders` (`customerId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_orders_status` ON `orders` (`status`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `order_items` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `orderId` INTEGER NOT NULL, `productId` INTEGER NOT NULL, `productName` TEXT NOT NULL, `quantityMilli` INTEGER NOT NULL, `unitPricePaisa` INTEGER NOT NULL, `unitCostPaisa` INTEGER NOT NULL, `lineTotalPaisa` INTEGER NOT NULL, FOREIGN KEY(`orderId`) REFERENCES `orders`(`id`) ON UPDATE NO ACTION ON DELETE NO ACTION)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_order_items_orderId` ON `order_items` (`orderId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_order_items_productId` ON `order_items` (`productId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `stock_movements` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `productId` INTEGER NOT NULL, `deltaMilli` INTEGER NOT NULL, `reason` TEXT NOT NULL, `refType` TEXT, `refId` INTEGER, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_stock_movements_productId` ON `stock_movements` (`productId`)")
            }
        }
        /** Adds expenses. Existing data is untouched. */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `expenses` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `expenseDate` INTEGER NOT NULL, `category` TEXT NOT NULL, `amountPaisa` INTEGER NOT NULL, `paymentMethod` TEXT NOT NULL, `description` TEXT, `createdAt` INTEGER NOT NULL, `deletedAt` INTEGER)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_expenses_expenseDate` ON `expenses` (`expenseDate`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_expenses_category` ON `expenses` (`category`)")
            }
        }
        /** Adds suppliers and purchases. Existing data is untouched. */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `suppliers` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `phone` TEXT, `notes` TEXT, `createdAt` INTEGER NOT NULL, `deletedAt` INTEGER)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `purchases` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `supplierId` INTEGER, `productId` INTEGER NOT NULL, `productName` TEXT NOT NULL, `purchaseDate` INTEGER NOT NULL, `quantityMilli` INTEGER NOT NULL, `unitCostPaisa` INTEGER NOT NULL, `extraCostPaisa` INTEGER NOT NULL, `totalPaisa` INTEGER NOT NULL, `paidPaisa` INTEGER NOT NULL, `paymentMethod` TEXT NOT NULL, `landedUnitCostPaisa` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_purchases_supplierId` ON `purchases` (`supplierId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_purchases_productId` ON `purchases` (`productId`)")
            }
        }
        /** Adds campaigns and two optional marketing columns on orders. Existing data is untouched. */
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `campaigns` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `platform` TEXT NOT NULL, `startDate` INTEGER NOT NULL, `endDate` INTEGER, `budgetPaisa` INTEGER NOT NULL, `spendPaisa` INTEGER NOT NULL, `impressions` INTEGER NOT NULL, `reach` INTEGER NOT NULL, `clicks` INTEGER NOT NULL, `messages` INTEGER NOT NULL, `leads` INTEGER NOT NULL, `notes` TEXT, `expenseId` INTEGER, `createdAt` INTEGER NOT NULL, `archivedAt` INTEGER)")
                db.execSQL("ALTER TABLE `orders` ADD COLUMN `marketingSource` TEXT")
                db.execSQL("ALTER TABLE `orders` ADD COLUMN `campaignId` INTEGER")
            }
        }
        /** Adds tasks. Existing data is untouched. */
        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `tasks` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT NOT NULL, `description` TEXT, `dueAt` INTEGER, `priority` TEXT NOT NULL, `category` TEXT NOT NULL, `relatedType` TEXT, `relatedId` INTEGER, `status` TEXT NOT NULL, `remindMinutesBefore` INTEGER, `createdAt` INTEGER NOT NULL, `doneAt` INTEGER)")
            }
        }
        /** Adds returns and return_items. Existing data is untouched. */
        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `returns` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `orderId` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `reason` TEXT, `refundPaisa` INTEGER NOT NULL, `refundMethod` TEXT NOT NULL, `note` TEXT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_returns_orderId` ON `returns` (`orderId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `return_items` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `returnId` INTEGER NOT NULL, `orderItemId` INTEGER NOT NULL, `productId` INTEGER NOT NULL, `productName` TEXT NOT NULL, `quantityMilli` INTEGER NOT NULL, `itemCondition` TEXT NOT NULL, `unitCostPaisa` INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_return_items_returnId` ON `return_items` (`returnId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_return_items_orderItemId` ON `return_items` (`orderItemId`)")
            }
        }
        /** Adds optional tags and follow-up date on customers. Existing data is untouched. */
        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `customers` ADD COLUMN `tags` TEXT")
                db.execSQL("ALTER TABLE `customers` ADD COLUMN `followUpAt` INTEGER")
            }
        }
        // No destructive fallback: schema changes always ship real migrations.
        fun build(ctx: Context) = Room.databaseBuilder(ctx, AppDatabase::class.java, "dudhia.db")
            .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8).build()
    }
}
