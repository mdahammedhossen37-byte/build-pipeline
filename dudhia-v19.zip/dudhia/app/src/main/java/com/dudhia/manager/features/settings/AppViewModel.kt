package com.dudhia.manager.features.settings

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.dudhia.manager.security.PinHasher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.dudhia.manager.core.Costing
import com.dudhia.manager.core.lineTotalPaisa
import com.dudhia.manager.core.OrderRules
import com.dudhia.manager.features.marketing.Marketing
import com.dudhia.manager.features.tasks.ReminderScheduler
import com.dudhia.manager.database.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class AppViewModel(private val db: AppDatabase, private val appContext: Context) : ViewModel() {
    val languageBn: StateFlow<Boolean> = db.settings().observe("language")
        .map { it != "en" }
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val onboarded: StateFlow<Boolean?> = db.settings().observe("onboarded")
        .map { it == "1" }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val customerCount = db.customers().observeCount().stateIn(viewModelScope, SharingStarted.Lazily, 0)
    val customers = db.customers().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allCustomers = db.customers().observeEvery().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val archivedCustomers = db.customers().observeArchived().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val archivedProducts = db.products().observeArchived().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    private val _vip = MutableStateFlow(1_000_000L)
    private val _days = MutableStateFlow(30)
    val vipAmountPaisa: StateFlow<Long> = _vip
    val inactiveDays: StateFlow<Int> = _days
    init {
        viewModelScope.launch {
            db.settings().get("vip_amount_paisa")?.toLongOrNull()?.let { _vip.value = it }
            db.settings().get("inactive_days")?.toIntOrNull()?.let { _days.value = it }
        }
    }
    val products = db.products().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val orders = db.orders().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val orderItemsAll = db.orders().observeAllItems().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val expenses = db.expenses().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val suppliers = db.suppliers().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val purchases = db.purchases().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val campaigns = db.campaigns().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val tasks = db.tasks().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val movements = db.stock().observeRecent().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val returns = db.returns().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val returnItems = db.returns().observeAllItems().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // ---------------- Security / backup state ----------------
    val pinEnabled: StateFlow<Boolean?> = db.settings().observe("pin_enabled")
        .map { it == "1" }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val bioEnabled: StateFlow<Boolean> = db.settings().observe("bio_enabled")
        .map { it == "1" }.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val lastBackup: StateFlow<Long?> = db.settings().observe("last_backup")
        .map { it?.toLongOrNull() }.stateIn(viewModelScope, SharingStarted.Lazily, null)
    private val _unlocked = MutableStateFlow(false)
    val unlocked: StateFlow<Boolean> = _unlocked
    private var failCount = 0
    var lockedUntil: Long = 0L
        private set

    private suspend fun audit(action: String, detail: String?) =
        db.audit().insert(AuditLogEntity(timestamp = System.currentTimeMillis(), actor = "USER", action = action, detail = detail))

    fun setLanguage(bn: Boolean) = viewModelScope.launch {
        db.settings().put(AppSettingEntity("language", if (bn) "bn" else "en"))
        audit("SET_LANGUAGE", if (bn) "bn" else "en")
    }
    fun finishOnboarding() = viewModelScope.launch { db.settings().put(AppSettingEntity("onboarded", "1")) }

    suspend fun findByPhone(phone: String): List<CustomerEntity> = db.customers().findByPhone(phone)

    fun saveCustomer(c: CustomerEntity) = viewModelScope.launch {
        if (c.id == 0L) { db.customers().insert(c); audit("CREATE_CUSTOMER", c.phone) }
        else { db.customers().update(c); audit("UPDATE_CUSTOMER", "id=${c.id}") }
    }

    /** onDone(null) = success, otherwise an error code: "sku" (duplicate SKU) or "error". */
    fun saveProduct(p: ProductEntity, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            if (p.id == 0L) { db.products().insert(p); audit("CREATE_PRODUCT", p.sku) }
            else {
                db.withTransaction {
                    val old = db.products().get(p.id)
                    db.products().update(p)
                    // a stock number changed by hand in the product form is recorded as a correction
                    if (old != null && old.stockMilli != p.stockMilli) {
                        db.stock().insert(StockMovementEntity(
                            productId = p.id, deltaMilli = p.stockMilli - old.stockMilli, reason = "CORRECTION",
                            refType = "PRODUCT_EDIT", refId = p.id, createdAt = System.currentTimeMillis()))
                    }
                }
                audit("UPDATE_PRODUCT", p.sku)
            }
            onDone(null)
        } catch (e: android.database.sqlite.SQLiteConstraintException) {
            onDone("sku")
        } catch (e: Exception) {
            onDone("error")
        }
    }

    // ---------------- Orders ----------------
    suspend fun orderItems(orderId: Long): List<OrderItemEntity> = db.orders().items(orderId)

    /** Order + items are saved together in one transaction. New orders are NOT revenue and do not touch stock. */
    fun createOrder(order: OrderEntity, items: List<OrderItemEntity>, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            db.withTransaction {
                val id = db.orders().insert(order)
                db.orders().insertItems(items.map { it.copy(orderId = id) })
                audit("CREATE_ORDER", "id=$id total=${order.totalPaisa}")
            }
            onDone(null)
        } catch (e: Exception) {
            onDone("error")
        }
    }

    /**
     * Status change. DELIVERED deducts stock (once, guarded by stockDeducted) and records stock movements,
     * all in one transaction: if any product lacks stock, nothing changes.
     * Error codes: null = ok, "invalid", "stock:<product name>", "error".
     */
    fun changeStatus(orderId: Long, newStatus: String, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            val err: String? = db.withTransaction {
                val o = db.orders().get(orderId) ?: return@withTransaction "error"
                if (!OrderRules.canMove(o.status, newStatus)) return@withTransaction "invalid"
                val now = System.currentTimeMillis()
                if (newStatus == "DELIVERED") {
                    if (o.stockDeducted) return@withTransaction "invalid"
                    val items = db.orders().items(o.id)
                    val need = items.groupBy { it.productId }.mapValues { e -> e.value.sumOf { x -> x.quantityMilli } }
                    for ((pid, qty) in need) {
                        val p = db.products().get(pid)
                        if (p == null || p.stockMilli < qty) {
                            val name = items.firstOrNull { it.productId == pid }?.productName ?: "?"
                            return@withTransaction "stock:$name"
                        }
                    }
                    for ((pid, qty) in need) {
                        val p = db.products().get(pid)!!
                        db.products().update(p.copy(stockMilli = p.stockMilli - qty, updatedAt = now))
                        db.stock().insert(StockMovementEntity(productId = pid, deltaMilli = -qty,
                            reason = "ORDER_DELIVERED", refType = "ORDER", refId = o.id, createdAt = now))
                    }
                    db.orders().update(o.copy(status = newStatus, stockDeducted = true, deliveredAt = now, updatedAt = now))
                } else {
                    db.orders().update(o.copy(status = newStatus, updatedAt = now))
                }
                audit("ORDER_STATUS", "id=${o.id} ${o.status}->$newStatus")
                null
            }
            onDone(err)
        } catch (e: Exception) {
            onDone("error")
        }
    }

    fun markPaid(orderId: Long) = viewModelScope.launch {
        db.withTransaction {
            val o = db.orders().get(orderId) ?: return@withTransaction
            if (o.paymentStatus != "PAID" && o.status != "CANCELLED") {
                db.orders().update(o.copy(paymentStatus = "PAID", updatedAt = System.currentTimeMillis()))
                audit("ORDER_PAID", "id=$orderId")
            }
        }
    }

    // ---------------- Finance ----------------
    fun addExpense(e: ExpenseEntity) = viewModelScope.launch {
        db.expenses().insert(e)
        audit("CREATE_EXPENSE", "${e.category} ${e.amountPaisa}")
    }

    /** Expenses are voided (kept with deletedAt), never hard-deleted. */
    fun voidExpense(id: Long) = viewModelScope.launch {
        db.expenses().markVoided(id, System.currentTimeMillis())
        audit("VOID_EXPENSE", "id=$id")
    }

    // ---------------- PIN lock ----------------
    fun relock() { _unlocked.value = false }
    fun unlock() { _unlocked.value = true }   // after a successful fingerprint check

    private suspend fun pinMatches(pin: String): Boolean {
        val salt = db.settings().get("pin_salt")
        val hash = db.settings().get("pin_hash")
        if (salt == null || hash == null) return false
        return withContext(Dispatchers.Default) { PinHasher.verify(pin, salt, hash) }
    }

    suspend fun verifyPin(pin: String): Boolean {
        if (System.currentTimeMillis() < lockedUntil) return false
        val ok = pinMatches(pin)
        if (ok) {
            failCount = 0
            _unlocked.value = true
        } else {
            failCount++
            if (failCount >= 5) { lockedUntil = System.currentTimeMillis() + 30_000; failCount = 0 }
        }
        return ok
    }

    fun setPin(pin: String) = viewModelScope.launch {
        val salt = PinHasher.newSalt()
        val hash = withContext(Dispatchers.Default) { PinHasher.hash(pin, salt) }
        db.settings().put(AppSettingEntity("pin_salt", salt))
        db.settings().put(AppSettingEntity("pin_hash", hash))
        db.settings().put(AppSettingEntity("pin_enabled", "1"))
        _unlocked.value = true
        audit("PIN_ENABLED", null)
    }

    suspend fun disablePin(current: String): Boolean {
        if (!pinMatches(current)) return false
        db.settings().put(AppSettingEntity("pin_enabled", "0"))
        db.settings().put(AppSettingEntity("bio_enabled", "0"))
        audit("PIN_DISABLED", null)
        return true
    }

    fun setBiometric(on: Boolean) = viewModelScope.launch {
        db.settings().put(AppSettingEntity("bio_enabled", if (on) "1" else "0"))
    }

    fun recordBackup(time: Long, sizeBytes: Long) = viewModelScope.launch {
        db.settings().put(AppSettingEntity("last_backup", time.toString()))
        audit("BACKUP", "size=$sizeBytes")
    }

    // ---------------- Suppliers & purchases ----------------
    fun addSupplier(name: String, phone: String?) = viewModelScope.launch {
        db.suppliers().insert(SupplierEntity(name = name, phone = phone, createdAt = System.currentTimeMillis()))
        audit("CREATE_SUPPLIER", name)
    }

    /**
     * Stock-in. In ONE transaction: save the purchase, add the stock, set the product cost to the
     * weighted average (landed cost incl. transport), and record a stock movement.
     * Old orders keep the cost they were sold at. Error codes: null = ok, "invalid", "error".
     */
    fun createPurchase(p: PurchaseEntity, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            val err: String? = db.withTransaction {
                val prod = db.products().get(p.productId) ?: return@withTransaction "error"
                if (p.quantityMilli <= 0 || p.unitCostPaisa <= 0 || p.paidPaisa < 0 || p.paidPaisa > p.totalPaisa) {
                    return@withTransaction "invalid"
                }
                val now = System.currentTimeMillis()
                val newCost = Costing.weightedAvgCost(prod.stockMilli, prod.costPaisa, p.quantityMilli, p.landedUnitCostPaisa)
                db.products().update(prod.copy(stockMilli = prod.stockMilli + p.quantityMilli, costPaisa = newCost, updatedAt = now))
                val id = db.purchases().insert(p)
                db.stock().insert(StockMovementEntity(productId = prod.id, deltaMilli = p.quantityMilli,
                    reason = "PURCHASE", refType = "PURCHASE", refId = id, createdAt = now))
                audit("CREATE_PURCHASE", "id=$id total=${p.totalPaisa}")
                null
            }
            onDone(err)
        } catch (e: Exception) {
            onDone("error")
        }
    }

    /** Pay (part of) what is still due on a purchase. */
    fun payPurchase(id: Long, amountPaisa: Long, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            val err: String? = db.withTransaction {
                val p = db.purchases().get(id) ?: return@withTransaction "error"
                val due = p.totalPaisa - p.paidPaisa
                if (amountPaisa <= 0 || amountPaisa > due) return@withTransaction "invalid"
                db.purchases().update(p.copy(paidPaisa = p.paidPaisa + amountPaisa))
                audit("PAY_PURCHASE", "id=$id amount=$amountPaisa")
                null
            }
            onDone(err)
        } catch (e: Exception) {
            onDone("error")
        }
    }

    // ---------------- Marketing ----------------
    fun saveCampaign(c: CampaignEntity, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            if (c.id == 0L) { db.campaigns().insert(c); audit("CREATE_CAMPAIGN", c.name) }
            else { db.campaigns().update(c); audit("UPDATE_CAMPAIGN", "id=${c.id}") }
            onDone(null)
        } catch (e: Exception) {
            onDone("error")
        }
    }

    /**
     * Adds the campaign spend to Expenses ONCE (real money lives only in expenses, so profit is never
     * double counted). One transaction; the campaign keeps the expense id and can never be added again.
     * Error codes: null = ok, "already", "invalid", "error".
     */
    fun addCampaignSpendToExpenses(id: Long, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            val err: String? = db.withTransaction {
                val c = db.campaigns().get(id) ?: return@withTransaction "error"
                if (c.expenseId != null) return@withTransaction "already"
                if (c.spendPaisa <= 0) return@withTransaction "invalid"
                val now = System.currentTimeMillis()
                val expId = db.expenses().insert(ExpenseEntity(
                    expenseDate = now, category = Marketing.expenseCategory(c.platform), amountPaisa = c.spendPaisa,
                    paymentMethod = "OTHER", description = "Campaign: " + c.name, createdAt = now))
                db.campaigns().update(c.copy(expenseId = expId))
                audit("CAMPAIGN_SPEND_TO_EXPENSE", "campaign=$id expense=$expId amount=${c.spendPaisa}")
                null
            }
            onDone(err)
        } catch (e: Exception) {
            onDone("error")
        }
    }

    // ---------------- Tasks & reminders ----------------
    fun saveTask(t: TaskEntity, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            val isNew = t.id == 0L
            val id = if (isNew) db.tasks().insert(t) else { db.tasks().update(t); t.id }
            audit(if (isNew) "CREATE_TASK" else "UPDATE_TASK", "id=$id")
            ReminderScheduler.schedule(appContext, t.copy(id = id))
            onDone(null)
        } catch (e: Exception) {
            onDone("error")
        }
    }

    /** status: DONE or CANCELLED (or OPEN to reopen). Reminders of non-open tasks are cancelled. */
    fun setTaskStatus(id: Long, status: String) = viewModelScope.launch {
        val t = db.tasks().get(id) ?: return@launch
        val updated = t.copy(status = status, doneAt = if (status == "DONE") System.currentTimeMillis() else null)
        db.tasks().update(updated)
        audit("TASK_$status", "id=$id")
        ReminderScheduler.schedule(appContext, updated)
    }

    // ---------------- Returns & refunds ----------------
    /**
     * Records a (partial or full) return of a DELIVERED order in ONE transaction: sellable goods go back to
     * stock, damaged goods never do, a stock movement is written per line, and the order becomes RETURNED
     * when every unit was returned. Quantities and refunds are re-checked against the database so nothing
     * can be returned or refunded twice. Error codes: null = ok, "invalid", "error".
     */
    fun createReturn(r: ReturnEntity, lines: List<ReturnItemEntity>, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            val err: String? = db.withTransaction {
                val order = db.orders().get(r.orderId) ?: return@withTransaction "error"
                if (order.status != "DELIVERED" || lines.isEmpty()) return@withTransaction "invalid"
                val orderItems = db.orders().items(order.id)
                val alreadyByItem = db.returns().itemsForOrder(order.id)
                    .groupBy { it.orderItemId }.mapValues { e -> e.value.sumOf { x -> x.quantityMilli } }
                val newByItem = lines.groupBy { it.orderItemId }.mapValues { e -> e.value.sumOf { x -> x.quantityMilli } }
                for ((itemId, qty) in newByItem) {
                    val oi = orderItems.firstOrNull { it.id == itemId } ?: return@withTransaction "invalid"
                    if (qty <= 0 || qty + (alreadyByItem[itemId] ?: 0L) > oi.quantityMilli) return@withTransaction "invalid"
                }
                val refunded = db.returns().refundedForOrder(order.id)
                if (r.refundPaisa < 0 || refunded + r.refundPaisa > order.totalPaisa) return@withTransaction "invalid"
                val now = System.currentTimeMillis()
                val returnId = db.returns().insert(r.copy(createdAt = now))
                db.returns().insertItems(lines.map { it.copy(returnId = returnId) })
                for (l in lines) {
                    val sellable = l.itemCondition == "SELLABLE"
                    if (sellable) {
                        val p = db.products().get(l.productId)
                        if (p != null) db.products().update(p.copy(stockMilli = p.stockMilli + l.quantityMilli, updatedAt = now))
                    }
                    db.stock().insert(StockMovementEntity(
                        productId = l.productId, deltaMilli = if (sellable) l.quantityMilli else 0L,
                        reason = if (sellable) "RETURN" else "DAMAGED_RETURN", refType = "RETURN", refId = returnId, createdAt = now))
                }
                val allBack = orderItems.all { oi -> (alreadyByItem[oi.id] ?: 0L) + (newByItem[oi.id] ?: 0L) >= oi.quantityMilli }
                if (allBack) db.orders().update(order.copy(status = "RETURNED", updatedAt = now))
                audit("CREATE_RETURN", "order=${order.id} return=$returnId refund=${r.refundPaisa}")
                null
            }
            onDone(err)
        } catch (e: Exception) {
            onDone("error")
        }
    }

    // ---------------- Order edit & duplicate ----------------
    /**
     * Edits an order that is still NEW or CONFIRMED (no stock was touched yet). Items and totals are replaced
     * in one transaction; status, payment status and history stay. Error codes: null = ok, "invalid", "error".
     */
    fun updateOrder(orderId: Long, form: OrderEntity, items: List<OrderItemEntity>, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            val err: String? = db.withTransaction {
                val o = db.orders().get(orderId) ?: return@withTransaction "error"
                if ((o.status != "NEW" && o.status != "CONFIRMED") || items.isEmpty()) return@withTransaction "invalid"
                db.orders().deleteItems(orderId)
                db.orders().insertItems(items.map { it.copy(id = 0, orderId = orderId) })
                db.orders().update(o.copy(
                    customerId = form.customerId, subtotalPaisa = form.subtotalPaisa, discountPaisa = form.discountPaisa,
                    deliveryChargePaisa = form.deliveryChargePaisa, totalPaisa = form.totalPaisa,
                    paymentMethod = form.paymentMethod, notes = form.notes, marketingSource = form.marketingSource,
                    campaignId = form.campaignId, updatedAt = System.currentTimeMillis()))
                audit("EDIT_ORDER", "id=$orderId total ${o.totalPaisa}->${form.totalPaisa}")
                null
            }
            onDone(err)
        } catch (e: Exception) {
            onDone("error")
        }
    }

    /** Creates a NEW order with the same customer and products, priced at today's product prices. */
    fun duplicateOrder(orderId: Long, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            val err: String? = db.withTransaction {
                val o = db.orders().get(orderId) ?: return@withTransaction "error"
                val old = db.orders().items(orderId)
                if (old.isEmpty()) return@withTransaction "invalid"
                val now = System.currentTimeMillis()
                val newItems = old.map { li ->
                    val p = db.products().get(li.productId)
                    val price = if (p != null && p.pricePaisa > 0) p.pricePaisa else li.unitPricePaisa
                    li.copy(id = 0, orderId = 0, unitPricePaisa = price, unitCostPaisa = p?.costPaisa ?: li.unitCostPaisa,
                        lineTotalPaisa = lineTotalPaisa(price, li.quantityMilli))
                }
                val subtotal = newItems.sumOf { it.lineTotalPaisa }
                val discount = minOf(o.discountPaisa, subtotal)
                val newId = db.orders().insert(o.copy(
                    id = 0, orderDate = now, status = "NEW", subtotalPaisa = subtotal, discountPaisa = discount,
                    totalPaisa = subtotal - discount + o.deliveryChargePaisa, paymentStatus = "UNPAID",
                    stockDeducted = false, deliveredAt = null, createdAt = now, updatedAt = now, deletedAt = null))
                db.orders().insertItems(newItems.map { it.copy(orderId = newId) })
                audit("DUPLICATE_ORDER", "from=$orderId new=$newId")
                null
            }
            onDone(err)
        } catch (e: Exception) {
            onDone("error")
        }
    }

    // ---------------- Archive (soft delete) & customer rules ----------------
    /** Archiving hides a record from lists and pickers. Orders, money and stock history are never touched. */
    fun archiveCustomer(id: Long) = viewModelScope.launch {
        db.customers().setDeleted(id, System.currentTimeMillis()); audit("ARCHIVE_CUSTOMER", "id=$id")
    }
    fun restoreCustomer(id: Long) = viewModelScope.launch {
        db.customers().setDeleted(id, null); audit("RESTORE_CUSTOMER", "id=$id")
    }
    fun archiveProduct(id: Long) = viewModelScope.launch {
        db.products().setDeleted(id, System.currentTimeMillis()); audit("ARCHIVE_PRODUCT", "id=$id")
    }
    fun restoreProduct(id: Long) = viewModelScope.launch {
        db.products().setDeleted(id, null); audit("RESTORE_PRODUCT", "id=$id")
    }
    /** Saves the customer label rules. onDone(true) only when the values were read back from the database. */
    fun saveLabelSettings(vipPaisa: Long, days: Int, onDone: (Boolean) -> Unit) = viewModelScope.launch {
        try {
            db.settings().put(AppSettingEntity("vip_amount_paisa", vipPaisa.toString()))
            db.settings().put(AppSettingEntity("inactive_days", days.toString()))
            val ok = db.settings().get("vip_amount_paisa") == vipPaisa.toString() &&
                db.settings().get("inactive_days") == days.toString()
            if (ok) {
                _vip.value = vipPaisa
                _days.value = days
                audit("SET_LABEL_RULES", "vip=$vipPaisa days=$days")
            }
            onDone(ok)
        } catch (e: Exception) {
            onDone(false)
        }
    }

    // ---------------- Stock adjustments ----------------
    /**
     * Changes stock with a reason (DAMAGED, EXPIRED, LOST, CORRECTION) in one transaction and records a
     * stock movement. Stock can never go below zero. Error codes: null = ok, "invalid", "error".
     */
    fun adjustStock(productId: Long, deltaMilli: Long, reason: String, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            val err: String? = db.withTransaction {
                if (reason !in setOf("DAMAGED", "EXPIRED", "LOST", "CORRECTION")) return@withTransaction "invalid"
                val p = db.products().get(productId) ?: return@withTransaction "error"
                if (deltaMilli == 0L || p.stockMilli + deltaMilli < 0) return@withTransaction "invalid"
                val now = System.currentTimeMillis()
                db.products().update(p.copy(stockMilli = p.stockMilli + deltaMilli, updatedAt = now))
                db.stock().insert(StockMovementEntity(
                    productId = productId, deltaMilli = deltaMilli, reason = reason, refType = "ADJUSTMENT", createdAt = now))
                audit("ADJUST_STOCK", "product=$productId delta=$deltaMilli reason=$reason")
                null
            }
            onDone(err)
        } catch (e: Exception) {
            onDone("error")
        }
    }
}
