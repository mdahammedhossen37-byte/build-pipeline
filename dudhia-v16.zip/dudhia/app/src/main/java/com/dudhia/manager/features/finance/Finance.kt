package com.dudhia.manager.features.finance

import com.dudhia.manager.core.lineTotalPaisa
import com.dudhia.manager.database.*

data class PnL(
    val productSales: Long,        // product subtotal minus discounts, delivered orders only
    val deliveryCollected: Long,   // delivery charge collected from customers (revenue)
    val revenue: Long,             // gross revenue = product sales + delivery collected
    val cogs: Long,                // cost of goods sold, MINUS the cost of sellable goods that came back
    val grossProfit: Long,         // net revenue - cogs
    val expenses: Long,            // operating expenses (ads, courier, packaging...), voided ones excluded
    val netProfit: Long,
    val deliveredCount: Int,
    val missingCostLines: Int,     // sold lines with cost 0: profit may be overstated
    val refunds: Long = 0,         // money refunded in the period
    val netRevenue: Long = 0       // revenue - refunds
)

object Finance {
    /**
     * Delivery-based (accrual-style) basis: orders delivered in the period count as sales (also orders that
     * were returned later, the return is booked separately). Refunds count in the period of the return.
     * Sellable returned goods reduce cost of goods sold; damaged goods keep their cost as a loss.
     */
    fun compute(
        orders: List<OrderEntity>, items: List<OrderItemEntity>, expenses: List<ExpenseEntity>, from: Long, to: Long,
        returns: List<ReturnEntity> = emptyList(), returnItems: List<ReturnItemEntity> = emptyList()
    ): PnL {
        val delivered = orders.filter { o ->
            o.deletedAt == null && (o.status == "DELIVERED" || o.status == "RETURNED") &&
                (o.deliveredAt ?: -1L) >= from && (o.deliveredAt ?: -1L) < to
        }
        val ids = delivered.map { it.id }.toSet()
        val sales = delivered.sumOf { it.subtotalPaisa - it.discountPaisa }
        val delivery = delivered.sumOf { it.deliveryChargePaisa }
        val its = items.filter { it.orderId in ids }
        val soldCost = its.sumOf { lineTotalPaisa(it.unitCostPaisa, it.quantityMilli) }
        val missing = its.count { it.unitCostPaisa == 0L }
        val exp = expenses.filter { it.deletedAt == null && it.expenseDate >= from && it.expenseDate < to }
            .sumOf { it.amountPaisa }

        val rs = returns.filter { it.createdAt >= from && it.createdAt < to }
        val refunds = rs.sumOf { it.refundPaisa }
        val rIds = rs.map { it.id }.toSet()
        val sellableBackCost = returnItems.filter { it.returnId in rIds && it.itemCondition == "SELLABLE" }
            .sumOf { lineTotalPaisa(it.unitCostPaisa, it.quantityMilli) }

        val revenue = sales + delivery
        val netRevenue = revenue - refunds
        val cogs = soldCost - sellableBackCost
        val gross = netRevenue - cogs
        return PnL(
            productSales = sales, deliveryCollected = delivery, revenue = revenue, cogs = cogs, grossProfit = gross,
            expenses = exp, netProfit = gross - exp, deliveredCount = delivered.size, missingCostLines = missing,
            refunds = refunds, netRevenue = netRevenue
        )
    }
}
