package com.dudhia.manager.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao interface CustomerDao {
    @Query("SELECT COUNT(*) FROM customers WHERE deletedAt IS NULL") fun observeCount(): Flow<Int>
    @Query("SELECT * FROM customers WHERE deletedAt IS NULL ORDER BY createdAt DESC") fun observeAll(): Flow<List<CustomerEntity>>
    @Query("SELECT * FROM customers WHERE phone = :phone AND deletedAt IS NULL") suspend fun findByPhone(phone: String): List<CustomerEntity>
    @Insert suspend fun insert(c: CustomerEntity): Long
    @Update suspend fun update(c: CustomerEntity)
}

@Dao interface ProductDao {
    @Query("SELECT * FROM products WHERE deletedAt IS NULL ORDER BY nameEn") fun observeAll(): Flow<List<ProductEntity>>
    @Query("SELECT COUNT(*) FROM products") suspend fun count(): Int
    @Insert suspend fun insertAll(items: List<ProductEntity>)
    @Query("SELECT * FROM products WHERE id = :id") suspend fun get(id: Long): ProductEntity?
    @Insert suspend fun insert(p: ProductEntity): Long
    @Update suspend fun update(p: ProductEntity)
}

@Dao interface SettingDao {
    @Query("SELECT value FROM app_settings WHERE `key` = :key") fun observe(key: String): Flow<String?>
    @Query("SELECT value FROM app_settings WHERE `key` = :key") suspend fun get(key: String): String?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(s: AppSettingEntity)
}

@Dao interface AuditDao { @Insert suspend fun insert(a: AuditLogEntity) }

@Dao interface OrderDao {
    @Query("SELECT * FROM orders WHERE deletedAt IS NULL ORDER BY orderDate DESC") fun observeAll(): Flow<List<OrderEntity>>
    @Query("SELECT * FROM orders WHERE id = :id") suspend fun get(id: Long): OrderEntity?
    @Query("SELECT * FROM order_items WHERE orderId = :orderId") suspend fun items(orderId: Long): List<OrderItemEntity>
    @Query("SELECT * FROM order_items") fun observeAllItems(): Flow<List<OrderItemEntity>>
    @Insert suspend fun insert(o: OrderEntity): Long
    @Insert suspend fun insertItems(items: List<OrderItemEntity>)
    @Query("DELETE FROM order_items WHERE orderId = :orderId") suspend fun deleteItems(orderId: Long)
    @Update suspend fun update(o: OrderEntity)
}

@Dao interface StockDao { @Insert suspend fun insert(m: StockMovementEntity) }

@Dao interface ExpenseDao {
    @Query("SELECT * FROM expenses WHERE deletedAt IS NULL ORDER BY expenseDate DESC") fun observeAll(): Flow<List<ExpenseEntity>>
    @Insert suspend fun insert(e: ExpenseEntity): Long
    @Query("UPDATE expenses SET deletedAt = :time WHERE id = :id") suspend fun markVoided(id: Long, time: Long)
}

@Dao interface SupplierDao {
    @Query("SELECT * FROM suppliers WHERE deletedAt IS NULL ORDER BY name") fun observeAll(): Flow<List<SupplierEntity>>
    @Insert suspend fun insert(s: SupplierEntity): Long
}

@Dao interface PurchaseDao {
    @Query("SELECT * FROM purchases ORDER BY purchaseDate DESC") fun observeAll(): Flow<List<PurchaseEntity>>
    @Query("SELECT * FROM purchases WHERE id = :id") suspend fun get(id: Long): PurchaseEntity?
    @Insert suspend fun insert(p: PurchaseEntity): Long
    @Update suspend fun update(p: PurchaseEntity)
}

@Dao interface CampaignDao {
    @Query("SELECT * FROM campaigns WHERE archivedAt IS NULL ORDER BY startDate DESC") fun observeAll(): Flow<List<CampaignEntity>>
    @Query("SELECT * FROM campaigns WHERE id = :id") suspend fun get(id: Long): CampaignEntity?
    @Insert suspend fun insert(c: CampaignEntity): Long
    @Update suspend fun update(c: CampaignEntity)
}

@Dao interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY CASE WHEN dueAt IS NULL THEN 1 ELSE 0 END, dueAt ASC") fun observeAll(): Flow<List<TaskEntity>>
    @Query("SELECT * FROM tasks WHERE id = :id") suspend fun get(id: Long): TaskEntity?
    @Insert suspend fun insert(t: TaskEntity): Long
    @Update suspend fun update(t: TaskEntity)
}

@Dao interface ReturnDao {
    @Query("SELECT * FROM returns ORDER BY createdAt DESC") fun observeAll(): Flow<List<ReturnEntity>>
    @Query("SELECT * FROM return_items") fun observeAllItems(): Flow<List<ReturnItemEntity>>
    @Query("SELECT ri.* FROM return_items ri INNER JOIN order_items oi ON oi.id = ri.orderItemId WHERE oi.orderId = :orderId")
    suspend fun itemsForOrder(orderId: Long): List<ReturnItemEntity>
    @Query("SELECT COALESCE(SUM(refundPaisa), 0) FROM returns WHERE orderId = :orderId") suspend fun refundedForOrder(orderId: Long): Long
    @Insert suspend fun insert(r: ReturnEntity): Long
    @Insert suspend fun insertItems(items: List<ReturnItemEntity>)
}
