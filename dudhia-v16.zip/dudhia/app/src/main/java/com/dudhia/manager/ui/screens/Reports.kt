package com.dudhia.manager.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.dudhia.manager.core.*
import com.dudhia.manager.database.*
import com.dudhia.manager.ui.theme.DudhiaColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun buildCsv(
    kind: String, customers: List<CustomerEntity>, products: List<ProductEntity>,
    orders: List<OrderEntity>, expenses: List<ExpenseEntity>
): String {
    val df = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
    val body = when (kind) {
        "customers" -> Csv.build(
            listOf("Name", "Phone", "Alt phone", "Address", "Area", "District", "Notes", "Created"),
            customers.map { listOf(it.name, it.phone, it.altPhone ?: "", it.address ?: "", it.area ?: "",
                it.district ?: "", it.notes ?: "", df.format(Date(it.createdAt))) })
        "products" -> Csv.build(
            listOf("SKU", "Name (Bengali)", "Name (English)", "Unit", "Selling price", "Purchase cost", "Stock", "Minimum stock"),
            products.map { listOf(it.sku, it.nameBn, it.nameEn, it.unit, Money(it.pricePaisa).plain(),
                Money(it.costPaisa).plain(), Qty.format(it.stockMilli), Qty.format(it.minStockMilli)) })
        "orders" -> {
            val byId = customers.associateBy { it.id }
            Csv.build(
                listOf("Order", "Date", "Customer", "Phone", "Status", "Payment", "Method", "Subtotal", "Discount", "Delivery", "Total", "Notes"),
                orders.map { o ->
                    val c = byId[o.customerId]
                    listOf(o.id.toString(), df.format(Date(o.orderDate)), c?.name ?: "", c?.phone ?: "", o.status,
                        o.paymentStatus, o.paymentMethod, Money(o.subtotalPaisa).plain(), Money(o.discountPaisa).plain(),
                        Money(o.deliveryChargePaisa).plain(), Money(o.totalPaisa).plain(), o.notes ?: "")
                })
        }
        else -> Csv.build(
            listOf("Date", "Category", "Amount", "Method", "Description"),
            expenses.map { listOf(df.format(Date(it.expenseDate)), it.category, Money(it.amountPaisa).plain(),
                it.paymentMethod, it.description ?: "") })
    }
    return "\uFEFF" + body   // BOM so Excel reads Bengali text correctly
}

@Composable
fun ReportsScreen(
    s: Strings, customers: List<CustomerEntity>, products: List<ProductEntity>,
    orders: List<OrderEntity>, expenses: List<ExpenseEntity>
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var kind by remember { mutableStateOf("customers") }
    var message by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) scope.launch {
            val csv = buildCsv(kind, customers, products, orders, expenses)
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val out = ctx.contentResolver.openOutputStream(uri, "wt") ?: error("cannot open output")
                    out.use { it.write(csv.toByteArray(Charsets.UTF_8)) }
                }.isSuccess
            }
            isError = !ok
            message = if (ok) s.exportDone else s.exportFailed
        }
    }
    fun export(k: String) {
        kind = k
        launcher.launch("dudhia-" + k + "-" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()) + ".csv")
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(s.moreReports, style = MaterialTheme.typography.titleLarge)
        Text(s.exportHint, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(modifier = Modifier.fillMaxWidth(), onClick = { export("customers") }) { Text(s.exportCustomers) }
        Button(modifier = Modifier.fillMaxWidth(), onClick = { export("products") }) { Text(s.exportProducts) }
        Button(modifier = Modifier.fillMaxWidth(), onClick = { export("orders") }) { Text(s.exportOrders) }
        Button(modifier = Modifier.fillMaxWidth(), onClick = { export("expenses") }) { Text(s.exportExpenses) }
        message?.let { Text(it, color = if (isError) DudhiaColors.Error else DudhiaColors.Success) }
    }
}
