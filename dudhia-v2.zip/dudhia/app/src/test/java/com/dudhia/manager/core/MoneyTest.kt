package com.dudhia.manager.core

import org.junit.Assert.*
import org.junit.Test

class MoneyTest {
    @Test fun parsesWholeAndFraction() {
        assertEquals(30000L, Money.parse("300")!!.paisa)
        assertEquals(30050L, Money.parse("300.5")!!.paisa)
        assertEquals(125075L, Money.parse("1,250.75")!!.paisa)
    }
    @Test fun rejectsBadInput() {
        assertNull(Money.parse("abc"))
        assertNull(Money.parse("1.234"))
    }
    @Test fun noFloatingPointDrift() {
        // 0.1 + 0.2 style check using paisa
        assertEquals(Money(30), Money.parse("0.10")!! + Money.parse("0.20")!!)
        assertEquals(Money(150000), Money(30000) * 5)
    }
    @Test fun formatsWithGrouping() {
        assertEquals("৳1,234.50", Money(123450).format())
        assertEquals("-৳5.00", Money(-500).format())
        assertEquals("৳0.07", Money(7).format())
    }
}
