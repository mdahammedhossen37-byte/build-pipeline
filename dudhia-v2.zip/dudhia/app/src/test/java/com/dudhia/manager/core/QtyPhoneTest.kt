package com.dudhia.manager.core

import org.junit.Assert.*
import org.junit.Test

class QtyPhoneTest {
    @Test fun qtyParse() {
        assertEquals(5000L, Qty.parseMilli("5"))
        assertEquals(2500L, Qty.parseMilli("2.5"))
        assertNull(Qty.parseMilli("1.2345"))
        assertNull(Qty.parseMilli("x"))
    }
    @Test fun qtyFormat() {
        assertEquals("5", Qty.format(5000))
        assertEquals("2.5", Qty.format(2500))
        assertEquals("0.25", Qty.format(250))
    }
    @Test fun phoneNormalize() {
        assertEquals("01712345678", Phone.normalize("০১৭১২-৩৪৫ ৬৭৮"))
        assertEquals("+8801712", Phone.normalize("+880 1712"))
    }
    @Test fun moneyPlain() { assertEquals("300.05", Money(30005).plain()) }
}
