package com.dudhia.manager.features.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dudhia.manager.database.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class AppViewModel(private val db: AppDatabase) : ViewModel() {
    val languageBn: StateFlow<Boolean> = db.settings().observe("language")
        .map { it != "en" }
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val onboarded: StateFlow<Boolean?> = db.settings().observe("onboarded")
        .map { it == "1" }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val customerCount = db.customers().observeCount().stateIn(viewModelScope, SharingStarted.Lazily, 0)
    val customers = db.customers().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val products = db.products().observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private suspend fun audit(action: String, detail: String?) =
        db.audit().insert(AuditLogEntity(timestamp = System.currentTimeMillis(), actor = "USER", action = action, detail = detail))

    fun setLanguage(bn: Boolean) = viewModelScope.launch {
        db.settings().put(AppSettingEntity("language", if (bn) "bn" else "en"))
        audit("SET_LANGUAGE", if (bn) "bn" else "en")
    }
    fun finishOnboarding() = viewModelScope.launch { db.settings().put(AppSettingEntity("onboarded", "1")) }

    suspend fun findByPhone(phone: String): List<CustomerEntity> = db.customers().findByPhone(phone)

    fun saveCustomer(c: CustomerEntity) = viewModelScope.launch {
        if (c.id == 0L) { db.customers().insert(c); audit("CREATE_CUSTOMER", c.phone) }
        else { db.customers().update(c); audit("UPDATE_CUSTOMER", "id=${c.id}") }
    }

    /** onDone(null) = success, otherwise an error code: "sku" (duplicate SKU) or "error". */
    fun saveProduct(p: ProductEntity, onDone: (String?) -> Unit) = viewModelScope.launch {
        try {
            if (p.id == 0L) { db.products().insert(p); audit("CREATE_PRODUCT", p.sku) }
            else { db.products().update(p); audit("UPDATE_PRODUCT", p.sku) }
            onDone(null)
        } catch (e: android.database.sqlite.SQLiteConstraintException) {
            onDone("sku")
        } catch (e: Exception) {
            onDone("error")
        }
    }
}
