package com.dudhia.manager

import android.app.Application
import com.dudhia.manager.database.*
import kotlinx.coroutines.*

class DudhiaApp : Application() {
    lateinit var db: AppDatabase
    override fun onCreate() {
        super.onCreate()
        db = AppDatabase.build(this)
        CoroutineScope(Dispatchers.IO).launch { seedProductsIfEmpty() }
    }
    /** Sample products with price/cost 0: the owner sets real values. Nothing is hardcoded as a business rule. */
    private suspend fun seedProductsIfEmpty() {
        if (db.products().count() > 0) return
        val now = System.currentTimeMillis()
        fun p(bn: String, en: String, sku: String, unit: String) =
            ProductEntity(nameBn = bn, nameEn = en, sku = sku, unit = unit, createdAt = now, updatedAt = now)
        db.products().insertAll(listOf(
            p("বগুড়া সরা দই (৬০০ গ্রাম)", "Bogura Sora Doi 600g", "DOI-600G", "PACK"),
            p("রসমালাই (৫০০ গ্রাম)", "Rasmalai 500g", "RM-500G", "PACK"),
            p("রসমালাই (১ কেজি)", "Rasmalai 1kg", "RM-1KG", "PACK"),
            p("যশোরের খেজুরের রস", "Jashore Date Palm Juice", "DPJ-L", "LITER"),
            p("পাটালি গুড়", "Patali Gur", "PGUR-KG", "KG"),
            p("ঝোলা গুড়", "Jhola Gur", "JGUR-KG", "KG")
        ))
        db.audit().insert(AuditLogEntity(timestamp = now, actor = "SYSTEM", action = "SEED_PRODUCTS", detail = "6 sample products"))
    }
}
