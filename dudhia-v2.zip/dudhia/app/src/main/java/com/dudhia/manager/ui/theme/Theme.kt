package com.dudhia.manager.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object DudhiaColors {
    val Cream = Color(0xFFF5EBDD); val LightCream = Color(0xFFFFF9EF)
    val Gold = Color(0xFFC6A15B); val DeepGold = Color(0xFFA77B32)
    val Text = Color(0xFF403629); val TextSecondary = Color(0xFF817565)
    val Success = Color(0xFF26845B); val Warning = Color(0xFFD69A36); val Error = Color(0xFFC54B4B)
    val GoldTint = Color(0xFFEBD9B4); val CardTint = Color(0xFFEFE3D0)
}

private val Light = lightColorScheme(
    primary = DudhiaColors.DeepGold, onPrimary = Color.White,
    primaryContainer = DudhiaColors.GoldTint, onPrimaryContainer = DudhiaColors.Text,
    secondary = DudhiaColors.Gold, onSecondary = Color.White,
    secondaryContainer = DudhiaColors.GoldTint, onSecondaryContainer = DudhiaColors.Text,
    background = DudhiaColors.Cream, onBackground = DudhiaColors.Text,
    surface = DudhiaColors.LightCream, onSurface = DudhiaColors.Text,
    surfaceVariant = DudhiaColors.CardTint, onSurfaceVariant = DudhiaColors.TextSecondary,
    surfaceContainerLowest = DudhiaColors.LightCream, surfaceContainerLow = DudhiaColors.LightCream,
    surfaceContainer = DudhiaColors.LightCream, surfaceContainerHigh = DudhiaColors.CardTint,
    surfaceContainerHighest = DudhiaColors.CardTint,
    outline = DudhiaColors.TextSecondary, outlineVariant = DudhiaColors.GoldTint,
    error = DudhiaColors.Error
)
private val Shapes = Shapes(
    small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(24.dp)
)

@Composable
fun DudhiaTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = Light, shapes = Shapes, content = content)
