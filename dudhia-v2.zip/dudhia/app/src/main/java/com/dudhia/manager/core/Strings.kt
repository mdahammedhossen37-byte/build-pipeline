package com.dudhia.manager.core

class Strings(val bn: Boolean) {
    private fun t(b: String, e: String) = if (bn) b else e
    val dashboard = t("ড্যাশবোর্ড", "Dashboard")
    val crm = t("কাস্টমার", "CRM")
    val orders = t("অর্ডার", "Orders")
    val inventory = t("ইনভেন্টরি", "Inventory")
    val more = t("আরও", "More")
    val settings = t("সেটিংস", "Settings")
    val language = t("ভাষা", "Language")
    val bengali = "বাংলা"; val english = "English"
    val customers = t("মোট কাস্টমার", "Total customers")
    val products = t("মোট পণ্য", "Total products")
    val lowStock = t("কম স্টক", "Low stock")
    val comingSoon = t("এই মডিউল পরবর্তী ধাপে আসবে", "This module is not implemented yet")
    val noProducts = t("কোনো পণ্য নেই", "No products yet")
    val welcomeTitle = t("দুধিয়া এআই বিজনেস ম্যানেজার", "Dudhia AI Business Manager")
    val welcomeBody = t(
        "আপনার ব্যবসার সব তথ্য এই ফোনেই থাকে, ইন্টারনেট ছাড়াই কাজ করে।",
        "Your business data stays on this phone and works without internet.")
    val start = t("শুরু করুন", "Get started")

    val save = t("সেভ", "Save"); val cancel = t("বাতিল", "Cancel")
    val search = t("নাম বা ফোন দিয়ে খুঁজুন", "Search name or phone")
    val name = t("নাম", "Name"); val phone = t("ফোন", "Phone")
    val altPhone = t("বিকল্প ফোন", "Alternative phone")
    val address = t("ঠিকানা", "Address"); val area = t("এলাকা", "Area")
    val district = t("জেলা", "District"); val notes = t("নোট", "Notes")
    val newCustomer = t("নতুন কাস্টমার", "New customer")
    val editCustomer = t("কাস্টমার এডিট", "Edit customer")
    val noCustomers = t("কোনো কাস্টমার নেই। নিচের + চাপ দিয়ে যোগ করুন।", "No customers yet. Tap + to add one.")
    val dupTitle = t("এই ফোন নম্বর আগে থেকেই আছে", "This phone number already exists")
    val openExisting = t("আগেরটি খুলুন", "Open existing")
    val saveAnyway = t("তবুও নতুন সেভ", "Save as new anyway")
    val required = t("নাম ও ফোন দিতে হবে", "Name and phone are required")
    val requiredProduct = t("পণ্যের নাম দিতে হবে", "Product name is required")
    val invalidNumber = t("সংখ্যা ঠিকভাবে লিখুন", "Enter numbers correctly")

    val newProduct = t("নতুন পণ্য", "New product")
    val editProduct = t("পণ্য এডিট", "Edit product")
    val nameBn = t("পণ্যের নাম (বাংলা)", "Product name (Bengali)")
    val nameEn = t("পণ্যের নাম (ইংরেজি)", "Product name (English)")
    val sku = t("SKU (খালি রাখলে নিজে তৈরি হবে)", "SKU (auto if empty)")
    val unitTitle = t("একক", "Unit")
    val price = t("বিক্রয় মূল্য (৳)", "Selling price (৳)")
    val cost = t("ক্রয় মূল্য (৳)", "Purchase cost (৳)")
    val stock = t("বর্তমান স্টক", "Current stock")
    val minStock = t("ন্যূনতম স্টক", "Minimum stock")
    val skuExists = t("এই SKU আগে থেকেই আছে", "This SKU already exists")
    val saveFailed = t("সেভ করা যায়নি", "Could not save")

    fun unitLabel(code: String) = when (code) {
        "PIECE" -> t("পিস", "Piece"); "GRAM" -> t("গ্রাম", "Gram"); "KG" -> t("কেজি", "Kg")
        "ML" -> t("মিলি", "ml"); "LITER" -> t("লিটার", "Liter"); "PACK" -> t("প্যাক", "Pack")
        "BOX" -> t("বক্স", "Box"); else -> code
    }
}
