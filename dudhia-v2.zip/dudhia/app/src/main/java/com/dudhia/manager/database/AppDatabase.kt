package com.dudhia.manager.database

import android.content.Context
import androidx.room.*

@Database(
    entities = [CustomerEntity::class, ProductEntity::class, AppSettingEntity::class, AuditLogEntity::class],
    version = 1, exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun customers(): CustomerDao
    abstract fun products(): ProductDao
    abstract fun settings(): SettingDao
    abstract fun audit(): AuditDao

    companion object {
        // No fallbackToDestructiveMigration: future schema changes must ship real Migrations.
        fun build(ctx: Context) = Room.databaseBuilder(ctx, AppDatabase::class.java, "dudhia.db").build()
    }
}
