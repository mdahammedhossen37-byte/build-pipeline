package com.dudhia.manager.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao interface CustomerDao {
    @Query("SELECT COUNT(*) FROM customers WHERE deletedAt IS NULL") fun observeCount(): Flow<Int>
    @Query("SELECT * FROM customers WHERE deletedAt IS NULL ORDER BY createdAt DESC") fun observeAll(): Flow<List<CustomerEntity>>
    @Query("SELECT * FROM customers WHERE phone = :phone AND deletedAt IS NULL") suspend fun findByPhone(phone: String): List<CustomerEntity>
    @Insert suspend fun insert(c: CustomerEntity): Long
    @Update suspend fun update(c: CustomerEntity)
}

@Dao interface ProductDao {
    @Query("SELECT * FROM products WHERE deletedAt IS NULL ORDER BY nameEn") fun observeAll(): Flow<List<ProductEntity>>
    @Query("SELECT COUNT(*) FROM products") suspend fun count(): Int
    @Insert suspend fun insertAll(items: List<ProductEntity>)
    @Insert suspend fun insert(p: ProductEntity): Long
    @Update suspend fun update(p: ProductEntity)
}

@Dao interface SettingDao {
    @Query("SELECT value FROM app_settings WHERE `key` = :key") fun observe(key: String): Flow<String?>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(s: AppSettingEntity)
}

@Dao interface AuditDao { @Insert suspend fun insert(a: AuditLogEntity) }
