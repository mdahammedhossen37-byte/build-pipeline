package com.dudhia.manager.database

import androidx.room.*

@Entity(tableName = "customers", indices = [Index("phone")])
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val altPhone: String? = null,
    val address: String? = null,
    val area: String? = null,
    val district: String? = null,
    val notes: String? = null,
    val type: String = "REGULAR",
    val status: String = "ACTIVE",
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null
)

@Entity(tableName = "products", indices = [Index("sku", unique = true)])
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nameBn: String,
    val nameEn: String,
    val sku: String,
    val category: String? = null,
    val unit: String,                 // PIECE, GRAM, KG, ML, LITER, PACK, BOX
    val costPaisa: Long = 0,
    val pricePaisa: Long = 0,
    val stockMilli: Long = 0,         // quantity x1000, avoids floats
    val minStockMilli: Long = 0,
    val status: String = "ACTIVE",
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null
)

@Entity(tableName = "app_settings")
data class AppSettingEntity(@PrimaryKey val key: String, val value: String)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val actor: String,        // USER, AI, AUTOMATION, SYSTEM
    val action: String,
    val detail: String? = null
)
