package com.dudhia.manager.core

import java.math.BigDecimal
import java.math.RoundingMode

/** Money stored as integer paisa (1 BDT = 100 paisa). Never uses Float/Double. */
@JvmInline
value class Money(val paisa: Long) : Comparable<Money> {
    operator fun plus(o: Money) = Money(Math.addExact(paisa, o.paisa))
    operator fun minus(o: Money) = Money(Math.subtractExact(paisa, o.paisa))
    operator fun times(qty: Int) = Money(Math.multiplyExact(paisa, qty.toLong()))
    override fun compareTo(other: Money) = paisa.compareTo(other.paisa)

    fun format(): String {
        val neg = paisa < 0
        val abs = Math.abs(paisa)
        val whole = (abs / 100).toString().reversed().chunked(3).joinToString(",").reversed()
        val frac = (abs % 100).toString().padStart(2, '0')
        return (if (neg) "-" else "") + "৳" + whole + "." + frac
    }

    companion object {
        val ZERO = Money(0)
        /** Parses "300", "300.5", "1,250.75". Returns null if invalid or negative-precision > 2 digits. */
        fun parse(text: String): Money? {
            val clean = text.trim().replace(",", "")
            val bd = clean.toBigDecimalOrNull() ?: return null
            if (bd.scale() > 2 && bd.stripTrailingZeros().scale() > 2) return null
            return Money(bd.setScale(2, RoundingMode.UNNECESSARY).movePointRight(2).longValueExact())
        }
    }
}
