package com.dudhia.manager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.dudhia.manager.core.*
import com.dudhia.manager.database.CustomerEntity
import com.dudhia.manager.database.ProductEntity

@Composable
private fun Field(label: String, value: String, onChange: (String) -> Unit,
                  kb: KeyboardType = KeyboardType.Text, single: Boolean = true) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = single,
        keyboardOptions = KeyboardOptions(keyboardType = kb), modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun CustomerFormDialog(s: Strings, initial: CustomerEntity?, onDismiss: () -> Unit, onSubmit: (CustomerEntity) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var alt by remember { mutableStateOf(initial?.altPhone ?: "") }
    var address by remember { mutableStateOf(initial?.address ?: "") }
    var area by remember { mutableStateOf(initial?.area ?: "") }
    var district by remember { mutableStateOf(initial?.district ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) s.newCustomer else s.editCustomer) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(s.name, name, { name = it })
                Field(s.phone, phone, { phone = it }, KeyboardType.Phone)
                Field(s.altPhone, alt, { alt = it }, KeyboardType.Phone)
                Field(s.address, address, { address = it })
                Field(s.area, area, { area = it })
                Field(s.district, district, { district = it })
                Field(s.notes, notes, { notes = it }, single = false)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val ph = Phone.normalize(phone)
                if (name.isBlank() || ph.isBlank()) {
                    error = s.required
                } else {
                    val now = System.currentTimeMillis()
                    val base = initial ?: CustomerEntity(name = "", phone = "", createdAt = now, updatedAt = now)
                    onSubmit(base.copy(
                        name = name.trim(), phone = ph,
                        altPhone = Phone.normalize(alt).ifBlank { null },
                        address = address.trim().ifBlank { null }, area = area.trim().ifBlank { null },
                        district = district.trim().ifBlank { null }, notes = notes.trim().ifBlank { null },
                        updatedAt = now))
                }
            }) { Text(s.save) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(s.cancel) } }
    )
}

@Composable
fun ProductFormDialog(s: Strings, initial: ProductEntity?, serverError: String?,
                      onDismiss: () -> Unit, onSubmit: (ProductEntity) -> Unit) {
    var nameBn by remember { mutableStateOf(initial?.nameBn ?: "") }
    var nameEn by remember { mutableStateOf(initial?.nameEn ?: "") }
    var sku by remember { mutableStateOf(initial?.sku ?: "") }
    var unit by remember { mutableStateOf(initial?.unit ?: "PIECE") }
    var price by remember { mutableStateOf(initial?.let { Money(it.pricePaisa).plain() } ?: "") }
    var cost by remember { mutableStateOf(initial?.let { Money(it.costPaisa).plain() } ?: "") }
    var stock by remember { mutableStateOf(initial?.let { Qty.format(it.stockMilli) } ?: "") }
    var minStock by remember { mutableStateOf(initial?.let { Qty.format(it.minStockMilli) } ?: "") }
    var menu by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) s.newProduct else s.editProduct) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(s.nameBn, nameBn, { nameBn = it })
                Field(s.nameEn, nameEn, { nameEn = it })
                Field(s.sku, sku, { sku = it })
                Text(s.unitTitle, style = MaterialTheme.typography.labelMedium)
                Box {
                    OutlinedButton(onClick = { menu = true }) { Text(s.unitLabel(unit)) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        UNITS.forEach { u ->
                            DropdownMenuItem(text = { Text(s.unitLabel(u)) }, onClick = { unit = u; menu = false })
                        }
                    }
                }
                Field(s.price, price, { price = it }, KeyboardType.Decimal)
                Field(s.cost, cost, { cost = it }, KeyboardType.Decimal)
                Field(s.stock, stock, { stock = it }, KeyboardType.Decimal)
                Field(s.minStock, minStock, { minStock = it }, KeyboardType.Decimal)
                val shown = error ?: when (serverError) {
                    null -> null
                    "sku" -> s.skuExists
                    else -> s.saveFailed
                }
                shown?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val p = if (price.isBlank()) Money.ZERO else Money.parse(price)
                val c = if (cost.isBlank()) Money.ZERO else Money.parse(cost)
                val st = if (stock.isBlank()) 0L else Qty.parseMilli(stock)
                val mn = if (minStock.isBlank()) 0L else Qty.parseMilli(minStock)
                if (nameBn.isBlank() && nameEn.isBlank()) {
                    error = s.requiredProduct
                } else if (p == null || c == null || st == null || mn == null ||
                    p.paisa < 0 || c.paisa < 0 || st < 0 || mn < 0) {
                    error = s.invalidNumber
                } else {
                    error = null
                    val now = System.currentTimeMillis()
                    val base = initial ?: ProductEntity(
                        nameBn = "", nameEn = "", sku = "", unit = unit, createdAt = now, updatedAt = now)
                    val finalSku = sku.trim().ifBlank { if (initial != null) initial.sku else "SKU-$now" }
                    onSubmit(base.copy(
                        nameBn = nameBn.trim().ifBlank { nameEn.trim() },
                        nameEn = nameEn.trim().ifBlank { nameBn.trim() },
                        sku = finalSku, unit = unit, costPaisa = c.paisa, pricePaisa = p.paisa,
                        stockMilli = st, minStockMilli = mn, updatedAt = now))
                }
            }) { Text(s.save) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(s.cancel) } }
    )
}
