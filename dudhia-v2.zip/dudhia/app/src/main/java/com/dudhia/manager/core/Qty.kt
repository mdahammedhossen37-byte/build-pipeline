package com.dudhia.manager.core

import java.math.BigDecimal
import java.math.RoundingMode

val UNITS = listOf("PIECE", "GRAM", "KG", "ML", "LITER", "PACK", "BOX")

fun Money.plain(): String = "${paisa / 100}.${(paisa % 100).toString().padStart(2, '0')}"

/** Quantities are stored as Long milli-units (x1000). No floats. */
object Qty {
    fun parseMilli(text: String): Long? {
        val bd = text.trim().replace(",", "").toBigDecimalOrNull() ?: return null
        if (bd.stripTrailingZeros().scale() > 3) return null
        return bd.setScale(3, RoundingMode.UNNECESSARY).movePointRight(3).longValueExact()
    }
    fun format(milli: Long): String {
        val whole = milli / 1000
        val frac = (Math.abs(milli) % 1000).toString().padStart(3, '0').trimEnd('0')
        return if (frac.isEmpty()) whole.toString() else "$whole.$frac"
    }
}

object Phone {
    /** Converts Bengali digits to ASCII, removes spaces/dashes, keeps a leading +. */
    fun normalize(raw: String): String {
        val sb = StringBuilder()
        for (ch in raw.trim()) {
            val d = if (ch in '০'..'৯') '0' + (ch - '০') else ch
            if (d in '0'..'9' || (d == '+' && sb.isEmpty())) sb.append(d)
        }
        return sb.toString()
    }
}
