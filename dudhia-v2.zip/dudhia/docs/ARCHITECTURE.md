# Dudhia AI Business Manager: architecture (Phase 1)
- Kotlin, Compose + Material 3, Room (SQLite) as the single source of truth, MVVM.
- Money = Long paisa. Quantities = Long milli-units. No Float/Double for finance.
- Soft delete via deletedAt. No destructive migrations. Audit log table from day one.
- AI/Automation/Import: later phases. All AI writes go through validated use-case functions + preview/confirm; never raw SQL.
