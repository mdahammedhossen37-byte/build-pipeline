package com.dudhia.manager.features.ai

import org.junit.Assert.*
import org.junit.Test

class CopilotParserTest {
    @Test fun bengaliDigitsBecomeAscii() {
        assertEquals("500", CopilotParser.normalize("৫০০"))
    }
    @Test fun amountNeedsToBeClear() {
        assertEquals(50000L, CopilotParser.extractAmount("আজকের Facebook Ads-এর খরচ ৫০০ টাকা যোগ করো"))
        assertNull(CopilotParser.extractAmount("খরচ যোগ করো"))
        assertEquals(5000L, CopilotParser.extractAmount("২ টা প্যাকেট ৫০ টাকা"))   // the number next to taka
        assertNull(CopilotParser.extractAmount("আজ ৫ তারিখ ৩০০"))                    // two numbers, unclear -> ask
        assertEquals(12550L, CopilotParser.extractAmount("courier 125.5 tk"))
    }
    @Test fun periods() {
        assertEquals("WEEK", CopilotParser.detectPeriod("গত ৭ দিনের মোট লাভ দেখাও"))
        assertEquals("MONTH", CopilotParser.detectPeriod("এই মাসের লাভ"))
        assertEquals("TODAY", CopilotParser.detectPeriod("আজকের লাভ"))
        assertEquals("ALL", CopilotParser.detectPeriod("সব সময়ের লাভ"))
    }
    @Test fun categories() {
        assertEquals("FACEBOOK_ADS", CopilotParser.detectCategory("আজ Facebook Ads খরচ"))
        assertEquals("COURIER", CopilotParser.detectCategory("কুরিয়ার ৮০"))
        assertNull(CopilotParser.detectCategory("কিছু একটা"))
    }
    @Test fun intents() {
        assertEquals(CopilotIntent.AddExpense("FACEBOOK_ADS", 50000L),
            CopilotParser.parse("আজকে Facebook Ads-এর খরচ ৫০০ টাকা যোগ করো"))
        assertEquals(CopilotIntent.ShowProfit("WEEK"), CopilotParser.parse("গত ৭ দিনের মোট লাভ দেখাও"))
        assertEquals(CopilotIntent.LowStock, CopilotParser.parse("কম স্টক"))
        assertEquals(CopilotIntent.InactiveCustomers, CopilotParser.parse("যে কাস্টমাররা গত ৩০ দিনে অর্ডার করেনি তাদের তালিকা দাও"))
        assertEquals(CopilotIntent.ShowProfit("TODAY"), CopilotParser.parse("আজকের খরচ কত"))
        assertEquals(CopilotIntent.Unknown, CopilotParser.parse("আজ ৫টা সরা দই বিক্রি হয়েছে"))   // not supported yet, never guessed
        assertEquals(CopilotIntent.Unknown, CopilotParser.parse(""))
    }
}
