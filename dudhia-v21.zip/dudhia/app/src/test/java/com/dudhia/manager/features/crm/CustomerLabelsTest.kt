package com.dudhia.manager.features.crm

import com.dudhia.manager.database.*
import org.junit.Assert.*
import org.junit.Test

class CustomerLabelsTest {
    private val day = CustomerLabels.DAY_MS
    private val now = 100 * day
    private fun customer(createdDaysAgo: Long) = CustomerEntity(name = "a", phone = "1", createdAt = now - createdDaysAgo * day, updatedAt = 0)
    private fun order(id: Long, status: String, total: Long, paid: String, date: Long) = OrderEntity(
        id = id, customerId = 1, orderDate = date, status = status, subtotalPaisa = total, discountPaisa = 0,
        deliveryChargePaisa = 0, totalPaisa = total, paymentMethod = "CASH", paymentStatus = paid, createdAt = 0, updatedAt = 0)

    @Test fun statsCountOnlyWhatShouldCount() {
        val orders = listOf(
            order(1, "DELIVERED", 40000, "PAID", 10), order(2, "DELIVERED", 20000, "UNPAID", 30),
            order(3, "CANCELLED", 99999, "UNPAID", 99), order(4, "NEW", 10000, "UNPAID", 20))
        val st = CustomerLabels.stats(orders)
        assertEquals(3, st.orderCount)              // cancelled one is ignored
        assertEquals(2, st.deliveredCount)
        assertEquals(60000L, st.lifetimePaisa)
        assertEquals(20000L, st.outstandingPaisa)
        assertEquals(30L, st.lastOrderAt)
    }
    @Test fun brandNewCustomerIsNewNotInactive() {
        assertEquals(listOf("NEW"), CustomerLabels.compute(customer(10), CustomerStats.EMPTY, now, 1_000_000, 30))
    }
    @Test fun longSilentCustomerIsInactive() {
        val st = CustomerStats(1, 1, 50_000, 0, now - 35 * day)
        assertEquals(listOf("INACTIVE"), CustomerLabels.compute(customer(100), st, now, 1_000_000, 30))
    }
    @Test fun fiveDeliveriesMakeRegularAndVip() {
        val st = CustomerStats(5, 5, 500_000, 0, now - day)
        assertEquals(listOf("REGULAR", "VIP"), CustomerLabels.compute(customer(100), st, now, 1_000_000, 30))
    }
    @Test fun amountRuleMakesVipAndCanBeSwitchedOff() {
        val st = CustomerStats(1, 1, 1_000_000, 0, now - day)
        assertEquals(listOf("VIP"), CustomerLabels.compute(customer(100), st, now, 1_000_000, 30))
        assertEquals(emptyList<String>(), CustomerLabels.compute(customer(100), st, now, 0, 30))
    }
}
