package com.dudhia.manager.features.marketing

import com.dudhia.manager.database.*
import org.junit.Assert.*
import org.junit.Test

class MarketingTest {
    private fun campaign(id: Long = 1, spend: Long = 10000, leads: Long = 5) = CampaignEntity(
        id = id, name = "c", platform = "FACEBOOK", startDate = 0, spendPaisa = spend, leads = leads, createdAt = 0)
    private fun order(id: Long, campaignId: Long?, status: String = "DELIVERED") = OrderEntity(
        id = id, customerId = 1, orderDate = 0, status = status, subtotalPaisa = 30000, discountPaisa = 0,
        deliveryChargePaisa = 10000, totalPaisa = 40000, paymentMethod = "CASH", paymentStatus = "PAID",
        deliveredAt = 1, createdAt = 0, updatedAt = 0, campaignId = campaignId)
    private fun item(orderId: Long) = OrderItemEntity(
        orderId = orderId, productId = 1, productName = "x", quantityMilli = 1000,
        unitPricePaisa = 30000, unitCostPaisa = 15000, lineTotalPaisa = 30000)

    @Test fun metricsForOneDeliveredOrder() {
        val m = Marketing.compute(campaign(), listOf(order(1, 1)), listOf(item(1)))
        assertEquals(1, m.orders)
        assertEquals(30000L, m.revenuePaisa)          // delivery charge is not campaign revenue
        assertEquals(15000L, m.grossProfitPaisa)
        assertEquals(300L, m.roasX100)                // 30000 / 10000 = 3.00
        assertEquals(10000L, m.costPerOrderPaisa)
        assertEquals(2000L, m.costPerLeadPaisa)       // 10000 / 5 leads
        assertEquals(5000L, m.profitPaisa)            // 15000 - 10000
    }
    @Test fun ignoresOtherCampaignsAndUndeliveredOrders() {
        val orders = listOf(order(1, 2), order(2, 1, "NEW"), order(3, 1, "CANCELLED"), order(4, null))
        val m = Marketing.compute(campaign(), orders, listOf(item(1), item(2), item(3), item(4)))
        assertEquals(0, m.orders)
        assertEquals(0L, m.revenuePaisa)
        assertNull(m.costPerOrderPaisa)
        assertEquals(-10000L, m.profitPaisa)
    }
    @Test fun noSpendMeansNoRoas() {
        val m = Marketing.compute(campaign(spend = 0, leads = 0), listOf(order(1, 1)), listOf(item(1)))
        assertNull(m.roasX100)
        assertNull(m.costPerLeadPaisa)
    }
    @Test fun roundingAndFormatting() {
        assertEquals(3333L, Marketing.divRound(10000, 3))
        assertEquals(3L, Marketing.divRound(5, 2))
        assertNull(Marketing.divRound(5, 0))
        assertEquals("2.50", Marketing.formatX100(250))
        assertEquals("0.05", Marketing.formatX100(5))
        assertEquals("FACEBOOK_ADS", Marketing.expenseCategory("FACEBOOK"))
        assertEquals("GOOGLE_ADS", Marketing.expenseCategory("YOUTUBE"))
        assertEquals("OTHER", Marketing.expenseCategory("ORGANIC"))
    }
}
