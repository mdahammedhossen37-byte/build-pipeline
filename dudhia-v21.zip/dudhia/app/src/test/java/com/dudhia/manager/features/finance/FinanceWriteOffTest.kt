package com.dudhia.manager.features.finance

import com.dudhia.manager.database.StockMovementEntity
import org.junit.Assert.*
import org.junit.Test

class FinanceWriteOffTest {
    private fun move(delta: Long, reason: String, at: Long = 500, cost: Long? = 15000) = StockMovementEntity(
        productId = 1, deltaMilli = delta, reason = reason, createdAt = at, unitCostPaisa = cost)

    @Test fun damagedGoodsAreALossAtCost() {
        // 2 units lost at 150.00 each = 300.00, no sales and no expenses
        val r = Finance.compute(emptyList(), emptyList(), emptyList(), 0, 1000,
            writeOffMovements = listOf(move(-2000, "DAMAGED")))
        assertEquals(30000L, r.writeOffs)
        assertEquals(-30000L, r.netProfit)
    }
    @Test fun onlyRealWriteOffsInThePeriodCount() {
        val moves = listOf(
            move(-1000, "EXPIRED"),                 // counts: 150.00
            move(-1000, "LOST", at = 5000),         // outside the period
            move(-1000, "CORRECTION"),              // not a write-off
            move(1000, "DAMAGED"))                  // stock added back, not a loss
        val r = Finance.compute(emptyList(), emptyList(), emptyList(), 0, 1000, writeOffMovements = moves)
        assertEquals(15000L, r.writeOffs)
    }
    @Test fun unknownCostCountsAsZeroNotACrash() {
        val r = Finance.compute(emptyList(), emptyList(), emptyList(), 0, 1000,
            writeOffMovements = listOf(move(-1000, "LOST", cost = null)))
        assertEquals(0L, r.writeOffs)
    }
}
