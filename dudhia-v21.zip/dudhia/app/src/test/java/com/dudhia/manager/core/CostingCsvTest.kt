package com.dudhia.manager.core

import org.junit.Assert.*
import org.junit.Test

class CostingCsvTest {
    @Test fun landedCostIncludesExtraCosts() {
        // 10 units x 100.00 + 50.00 transport = 1050.00 -> 105.00 per unit
        assertEquals(10500L, Costing.landedUnitPaisa(10000, 10000, 5000))
        assertEquals(10000L, Costing.landedUnitPaisa(10000, 10000, 0))
    }
    @Test fun weightedAverage() {
        assertEquals(12750L, Costing.weightedAvgCost(10000, 15000, 10000, 10500))
        assertEquals(10500L, Costing.weightedAvgCost(0, 15000, 10000, 10500))
    }
    @Test fun csvEscaping() {
        assertEquals("a", Csv.escape("a"))
        assertEquals("\"a,b\"", Csv.escape("a,b"))
        assertEquals("\"say \"\"hi\"\"\"", Csv.escape("say \"hi\""))
        assertEquals("x,y\r\n1,\"2,3\"\r\n", Csv.build(listOf("x", "y"), listOf(listOf("1", "2,3"))))
    }
}
