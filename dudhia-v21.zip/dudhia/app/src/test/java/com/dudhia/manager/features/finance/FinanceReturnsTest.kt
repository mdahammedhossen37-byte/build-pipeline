package com.dudhia.manager.features.finance

import com.dudhia.manager.database.*
import org.junit.Assert.*
import org.junit.Test

class FinanceReturnsTest {
    // One delivered order: product 300.00 + delivery 100.00, cost 150.00 (qty 1)
    private fun order(status: String = "DELIVERED") = OrderEntity(
        id = 1, customerId = 1, orderDate = 0, status = status, subtotalPaisa = 30000, discountPaisa = 0,
        deliveryChargePaisa = 10000, totalPaisa = 40000, paymentMethod = "CASH", paymentStatus = "PAID",
        deliveredAt = 100, createdAt = 0, updatedAt = 0)
    private val item = OrderItemEntity(
        id = 1, orderId = 1, productId = 1, productName = "x", quantityMilli = 1000,
        unitPricePaisa = 30000, unitCostPaisa = 15000, lineTotalPaisa = 30000)
    private fun ret(refund: Long, at: Long = 500) = ReturnEntity(id = 1, orderId = 1, createdAt = at, refundPaisa = refund, refundMethod = "CASH")
    private fun retItem(qty: Long, condition: String) = ReturnItemEntity(
        id = 1, returnId = 1, orderItemId = 1, productId = 1, productName = "x", quantityMilli = qty,
        itemCondition = condition, unitCostPaisa = 15000)

    @Test fun fullSellableReturnKeepsOnlyDeliveryCharge() {
        val r = Finance.compute(listOf(order("RETURNED")), listOf(item), emptyList(), 0, 1000,
            listOf(ret(30000)), listOf(retItem(1000, "SELLABLE")))
        assertEquals(40000L, r.revenue)
        assertEquals(30000L, r.refunds)
        assertEquals(10000L, r.netRevenue)
        assertEquals(0L, r.cogs)                 // 15000 - 15000 back in stock
        assertEquals(10000L, r.grossProfit)
        assertEquals(10000L, r.netProfit)
    }
    @Test fun damagedReturnKeepsTheCostAsLoss() {
        val r = Finance.compute(listOf(order("RETURNED")), listOf(item), emptyList(), 0, 1000,
            listOf(ret(30000)), listOf(retItem(1000, "DAMAGED")))
        assertEquals(15000L, r.cogs)
        assertEquals(-5000L, r.grossProfit)      // 10000 net revenue - 15000 cost
    }
    @Test fun partialReturn() {
        val r = Finance.compute(listOf(order()), listOf(item), emptyList(), 0, 1000,
            listOf(ret(15000)), listOf(retItem(500, "SELLABLE")))
        assertEquals(25000L, r.netRevenue)       // 40000 - 15000
        assertEquals(7500L, r.cogs)              // 15000 - 7500 (half back)
        assertEquals(17500L, r.grossProfit)
    }
    @Test fun returnOutsideThePeriodIsIgnored() {
        val r = Finance.compute(listOf(order()), listOf(item), emptyList(), 0, 1000,
            listOf(ret(30000, at = 5000)), listOf(retItem(1000, "SELLABLE")))
        assertEquals(0L, r.refunds)
        assertEquals(25000L, r.grossProfit)      // 40000 - 15000
    }
}
