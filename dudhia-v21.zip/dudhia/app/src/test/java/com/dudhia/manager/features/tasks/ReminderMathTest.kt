package com.dudhia.manager.features.tasks

import com.dudhia.manager.core.ReminderMath
import org.junit.Assert.*
import org.junit.Test

class ReminderMathTest {
    @Test fun triggerIsBeforeDueTime() {
        assertEquals(9_400_000L, ReminderMath.triggerAt(10_000_000L, 10))      // 10 minutes = 600,000 ms
        assertEquals(10_000_000L, ReminderMath.triggerAt(10_000_000L, 0))
        assertEquals(10_000_000L - 86_400_000L, ReminderMath.triggerAt(10_000_000L, 1440)) // 1 day before
    }
    @Test fun delayIsNeverNegative() {
        assertEquals(4_400_000L, ReminderMath.delayMillis(10_000_000L, 10, 5_000_000L))
        assertEquals(0L, ReminderMath.delayMillis(10_000_000L, 10, 9_999_999L))
    }
    @Test fun oldReminderIsSkipped() {
        assertTrue(ReminderMath.isTooOld(10_000_000L, 10, 9_500_000L))          // trigger 9,400,000 < 9,440,000
        assertFalse(ReminderMath.isTooOld(10_000_000L, 10, 9_410_000L))         // trigger 9,400,000 < 9,350,000 is false
    }
}
