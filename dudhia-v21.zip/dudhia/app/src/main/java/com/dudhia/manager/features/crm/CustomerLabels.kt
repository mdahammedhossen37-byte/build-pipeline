package com.dudhia.manager.features.crm

import com.dudhia.manager.database.CustomerEntity
import com.dudhia.manager.database.OrderEntity

data class CustomerStats(
    val orderCount: Int,          // orders that are not cancelled
    val deliveredCount: Int,
    val lifetimePaisa: Long,      // total of delivered orders
    val outstandingPaisa: Long,   // delivered but unpaid
    val lastOrderAt: Long?
) {
    companion object { val EMPTY = CustomerStats(0, 0, 0L, 0L, null) }
}

object CustomerLabels {
    const val DAY_MS = 86_400_000L

    fun stats(orders: List<OrderEntity>): CustomerStats {
        val active = orders.filter { it.status != "CANCELLED" && it.deletedAt == null }
        val delivered = active.filter { it.status == "DELIVERED" }
        return CustomerStats(
            orderCount = active.size,
            deliveredCount = delivered.size,
            lifetimePaisa = delivered.sumOf { it.totalPaisa },
            outstandingPaisa = delivered.filter { it.paymentStatus == "UNPAID" }.sumOf { it.totalPaisa },
            lastOrderAt = active.maxOfOrNull { it.orderDate }
        )
    }

    /**
     * Labels are computed from data, never typed by hand.
     * NEW: customer created in the last [newDays] days. REGULAR: 2+ delivered orders.
     * VIP: 5+ delivered orders, or lifetime purchases at or above [vipAmountPaisa] (rule off when it is 0).
     * INACTIVE: no order for more than [inactiveDays] days (counted from creation when there is no order).
     */
    fun compute(
        c: CustomerEntity, st: CustomerStats, now: Long, vipAmountPaisa: Long, inactiveDays: Int, newDays: Int = 30
    ): List<String> {
        val labels = mutableListOf<String>()
        if (now - c.createdAt <= newDays * DAY_MS) labels.add("NEW")
        if (st.deliveredCount >= 2) labels.add("REGULAR")
        if (st.deliveredCount >= 5 || (vipAmountPaisa > 0 && st.lifetimePaisa >= vipAmountPaisa)) labels.add("VIP")
        val last = st.lastOrderAt ?: c.createdAt
        if (now - last > inactiveDays * DAY_MS) labels.add("INACTIVE")
        return labels
    }
}
