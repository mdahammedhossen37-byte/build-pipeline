package com.dudhia.manager.core

import java.math.BigDecimal
import java.math.RoundingMode

object Costing {
    /** (quantity x unit cost + extra costs) per unit, in paisa, rounded half-up. Landed cost. */
    fun landedUnitPaisa(unitCostPaisa: Long, qtyMilli: Long, extraPaisa: Long): Long {
        require(qtyMilli > 0) { "quantity must be positive" }
        val total = BigDecimal.valueOf(lineTotalPaisa(unitCostPaisa, qtyMilli) + extraPaisa)
        return total.multiply(BigDecimal.valueOf(1000))
            .divide(BigDecimal.valueOf(qtyMilli), 0, RoundingMode.HALF_UP).longValueExact()
    }

    /** Weighted-average unit cost after adding stock. If nothing is in stock, the new cost is used as is. */
    fun weightedAvgCost(oldStockMilli: Long, oldCostPaisa: Long, addQtyMilli: Long, addUnitPaisa: Long): Long {
        if (oldStockMilli <= 0) return addUnitPaisa
        val num = BigDecimal.valueOf(oldStockMilli).multiply(BigDecimal.valueOf(oldCostPaisa))
            .add(BigDecimal.valueOf(addQtyMilli).multiply(BigDecimal.valueOf(addUnitPaisa)))
        return num.divide(BigDecimal.valueOf(oldStockMilli + addQtyMilli), 0, RoundingMode.HALF_UP).longValueExact()
    }
}
