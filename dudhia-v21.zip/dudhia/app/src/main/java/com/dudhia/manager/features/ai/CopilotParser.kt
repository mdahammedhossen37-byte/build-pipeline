package com.dudhia.manager.features.ai

import com.dudhia.manager.core.Money

sealed class CopilotIntent {
    data class AddExpense(val category: String?, val amountPaisa: Long?) : CopilotIntent()
    data class ShowProfit(val period: String) : CopilotIntent()      // TODAY, WEEK, MONTH, ALL
    object LowStock : CopilotIntent()
    object InactiveCustomers : CopilotIntent()
    object Unknown : CopilotIntent()
}

/** Offline, rule-based understanding of short Bengali/English instructions. It never guesses missing values. */
object CopilotParser {
    fun normalize(text: String): String =
        text.map { if (it in '০'..'৯') '0' + (it - '০') else it }.joinToString("").lowercase().trim()

    private val NUMBER = Regex("""\d+(?:[.,]\d+)?""")
    private val MONEY_WORDS = listOf("টাকা", "taka", "tk", "৳", "bdt")

    /** Amount in paisa. Null when there is no number, or when it is unclear which number is the amount. */
    fun extractAmount(text: String): Long? {
        val t = normalize(text)
        val matches = NUMBER.findAll(t).toList()
        if (matches.isEmpty()) return null
        val candidate = if (matches.size == 1) {
            matches[0]
        } else {
            matches.firstOrNull { m ->
                val after = t.substring(m.range.last + 1).trimStart()
                val before = t.substring(0, m.range.first).trimEnd()
                MONEY_WORDS.any { w -> after.startsWith(w) || before.endsWith(w) }
            } ?: return null
        }
        return Money.parse(candidate.value)?.paisa?.takeIf { it > 0 }
    }

    fun detectPeriod(text: String): String {
        val t = normalize(text)
        return when {
            listOf("সব সময়", "শুরু থেকে", "all time", "alltime").any { it in t } -> "ALL"
            listOf("7 দিন", "7দিন", "7 days", "সপ্তাহ", "week").any { it in t } -> "WEEK"
            listOf("30 দিন", "30দিন", "30 days", "মাস", "month").any { it in t } -> "MONTH"
            else -> "TODAY"
        }
    }

    private val CATEGORY_WORDS = listOf(
        "FACEBOOK_ADS" to listOf("facebook", "ফেসবুক"),
        "INSTAGRAM_ADS" to listOf("instagram", "ইনস্টাগ্রাম"),
        "GOOGLE_ADS" to listOf("google", "গুগল"),
        "TIKTOK_ADS" to listOf("tiktok", "টিকটক"),
        "COURIER" to listOf("courier", "কুরিয়ার"),
        "PACKAGING" to listOf("packaging", "প্যাকেজিং"),
        "TRANSPORT" to listOf("transport", "পরিবহন", "ভাড়া"),
        "SALARY" to listOf("salary", "বেতন"),
        "INTERNET" to listOf("internet", "ইন্টারনেট"),
        "ELECTRICITY" to listOf("electricity", "বিদ্যুৎ", "বিদ্যুত"),
        "TRAVEL" to listOf("travel", "যাতায়াত"),
        "STORAGE" to listOf("storage", "গুদাম"),
        "SOFTWARE" to listOf("software", "সফটওয়্যার")
    )

    fun detectCategory(text: String): String? {
        val t = normalize(text)
        return CATEGORY_WORDS.firstOrNull { (_, words) -> words.any { it in t } }?.first
    }

    fun parse(text: String): CopilotIntent {
        val t = normalize(text)
        if (t.isEmpty()) return CopilotIntent.Unknown
        val asksToShow = listOf("কত", "দেখাও", "দেখান", "show", "how much").any { it in t }
        if (listOf("কম স্টক", "স্টক কম", "low stock", "স্টক শেষ").any { it in t }) return CopilotIntent.LowStock
        if (listOf("অর্ডার করেনি", "অর্ডার করে নি", "নিষ্ক্রিয়", "inactive").any { it in t }) return CopilotIntent.InactiveCustomers
        if (listOf("লাভ", "মুনাফা", "profit").any { it in t }) return CopilotIntent.ShowProfit(detectPeriod(t))
        if (listOf("বিক্রি", "sales").any { it in t } && asksToShow) return CopilotIntent.ShowProfit(detectPeriod(t))
        if (listOf("খরচ", "expense", "cost").any { it in t }) {
            val amount = extractAmount(t)
            if (asksToShow && amount == null) return CopilotIntent.ShowProfit(detectPeriod(t))
            return CopilotIntent.AddExpense(detectCategory(t), amount)
        }
        return CopilotIntent.Unknown
    }
}
