package com.dudhia.manager.core

/** Pure helpers for reminder timing (epoch millis, minutes). */
object ReminderMath {
    fun triggerAt(dueAt: Long, remindMinutesBefore: Long): Long = dueAt - remindMinutesBefore * 60_000L

    /** Delay from now until the reminder; never negative. */
    fun delayMillis(dueAt: Long, remindMinutesBefore: Long, now: Long): Long =
        maxOf(0L, triggerAt(dueAt, remindMinutesBefore) - now)

    /** A reminder whose time passed more than one minute ago is not fired late. */
    fun isTooOld(dueAt: Long, remindMinutesBefore: Long, now: Long): Boolean =
        triggerAt(dueAt, remindMinutesBefore) < now - 60_000L
}
