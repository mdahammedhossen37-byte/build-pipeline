package com.dudhia.manager.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.dudhia.manager.core.*
import com.dudhia.manager.database.*
import com.dudhia.manager.features.marketing.CampaignMetrics
import com.dudhia.manager.features.marketing.Marketing
import com.dudhia.manager.features.marketing.PLATFORMS
import com.dudhia.manager.ui.theme.DudhiaColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun digitsToAscii(t: String): String = t.map { if (it in '০'..'৯') '0' + (it - '০') else it }.joinToString("")

private fun fmtDate(ms: Long): String = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(ms))

private fun parseDate(text: String): Long? = try {
    val f = SimpleDateFormat("dd/MM/yyyy", Locale.US)
    f.isLenient = false
    f.parse(digitsToAscii(text).trim())?.time
} catch (e: Exception) { null }

private fun parseCount(text: String): Long? =
    if (text.isBlank()) 0L else digitsToAscii(text).trim().toLongOrNull()?.takeIf { it >= 0 }

private fun countText(v: Long): String = if (v == 0L) "" else v.toString()

@Composable
private fun CampaignFormDialog(
    s: Strings, initial: CampaignEntity?, serverError: String?,
    onDismiss: () -> Unit, onSubmit: (CampaignEntity) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var platform by remember { mutableStateOf(initial?.platform ?: "FACEBOOK") }
    var start by remember { mutableStateOf(fmtDate(initial?.startDate ?: System.currentTimeMillis())) }
    var end by remember { mutableStateOf(initial?.endDate?.let { fmtDate(it) } ?: "") }
    var budget by remember { mutableStateOf(initial?.let { if (it.budgetPaisa == 0L) "" else Money(it.budgetPaisa).plain() } ?: "") }
    var spend by remember { mutableStateOf(initial?.let { if (it.spendPaisa == 0L) "" else Money(it.spendPaisa).plain() } ?: "") }
    var impressions by remember { mutableStateOf(countText(initial?.impressions ?: 0L)) }
    var reach by remember { mutableStateOf(countText(initial?.reach ?: 0L)) }
    var clicks by remember { mutableStateOf(countText(initial?.clicks ?: 0L)) }
    var messages by remember { mutableStateOf(countText(initial?.messages ?: 0L)) }
    var leads by remember { mutableStateOf(countText(initial?.leads ?: 0L)) }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    val locked = initial?.expenseId != null

    FormScaffold(
        title = if (initial == null) s.newCampaign else s.editCampaign,
        confirmText = s.save, cancelText = s.cancel, onDismiss = onDismiss,
        onConfirm = {
            val st = parseDate(start)
            val en = if (end.isBlank()) null else parseDate(end)
            val b = if (budget.isBlank()) Money.ZERO else Money.parse(digitsToAscii(budget))
            val sp = if (locked) Money(initial?.spendPaisa ?: 0L)
                else if (spend.isBlank()) Money.ZERO else Money.parse(digitsToAscii(spend))
            val imp = parseCount(impressions); val rch = parseCount(reach); val clk = parseCount(clicks)
            val msg = parseCount(messages); val ld = parseCount(leads)
            if (name.isBlank()) {
                error = s.campaignNameRequired
            } else if (st == null || (end.isNotBlank() && en == null) || (en != null && en < st)) {
                error = s.invalidDate
            } else if (b == null || sp == null || b.paisa < 0 || sp.paisa < 0 ||
                imp == null || rch == null || clk == null || msg == null || ld == null) {
                error = s.invalidNumber
            } else {
                error = null
                val now = System.currentTimeMillis()
                val base = initial ?: CampaignEntity(name = "", platform = platform, startDate = st, createdAt = now)
                onSubmit(base.copy(
                    name = name.trim(), platform = platform, startDate = st, endDate = en,
                    budgetPaisa = b.paisa, spendPaisa = sp.paisa, impressions = imp, reach = rch, clicks = clk,
                    messages = msg, leads = ld, notes = notes.trim().ifBlank { null }))
            }
        }
    ) {
        Field(s.campaignName, name, { name = it })
        Picker(s.platformTitle, PLATFORMS.map { Opt(it, s.platformLabel(it)) }, platform) { platform = it }
        Field(s.startDate, start, { start = it })
        Field(s.endDate, end, { end = it })
        Field(s.budget, budget, { budget = it }, KeyboardType.Decimal)
        if (locked) {
            Text("${s.spendLabel}: ${Money(initial?.spendPaisa ?: 0L).format()}", style = MaterialTheme.typography.titleSmall)
            Text(s.spendLocked, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            Field(s.spendLabel, spend, { spend = it }, KeyboardType.Decimal)
        }
        Field(s.impressions, impressions, { impressions = it }, KeyboardType.Number)
        Field(s.reach, reach, { reach = it }, KeyboardType.Number)
        Field(s.clicks, clicks, { clicks = it }, KeyboardType.Number)
        Field(s.messagesCount, messages, { messages = it }, KeyboardType.Number)
        Field(s.leads, leads, { leads = it }, KeyboardType.Number)
        Field(s.notes, notes, { notes = it }, single = false)
        val shown = error ?: if (serverError != null) s.saveFailed else null
        shown?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
fun MarketingScreen(
    s: Strings,
    campaigns: List<CampaignEntity>,
    orders: List<OrderEntity>,
    items: List<OrderItemEntity>,
    onSave: (CampaignEntity, (String?) -> Unit) -> Unit,
    onAddSpend: (Long, (String?) -> Unit) -> Unit
) {
    var showForm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<CampaignEntity?>(null) }
    var formError by remember { mutableStateOf<String?>(null) }
    var confirmId by remember { mutableStateOf<Long?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    val metrics: Map<Long, CampaignMetrics> = remember(campaigns, orders, items) {
        campaigns.associate { it.id to Marketing.compute(it, orders, items) }
    }
    val totalSpend = metrics.values.sumOf { it.spendPaisa }
    val totalRevenue = metrics.values.sumOf { it.revenuePaisa }
    val totalOrders = metrics.values.sumOf { it.orders }
    val totalProfit = metrics.values.sumOf { it.profitPaisa }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(top = 16.dp, bottom = 88.dp)
        ) {
            item { Text(s.moreMarketing, style = MaterialTheme.typography.titleLarge) }
            item { Text(s.marketingNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(s.allCampaigns, style = MaterialTheme.typography.titleSmall)
                        Text("${s.spendLabel}: ${Money(totalSpend).format()}")
                        Text("${s.attributedOrders}: $totalOrders · ${s.attributedRevenue}: ${Money(totalRevenue).format()}")
                        Text("${s.roas}: ${Marketing.ratioX100(totalRevenue, totalSpend)?.let { Marketing.formatX100(it) } ?: "-"} · " +
                            "${s.costPerOrder}: ${Marketing.divRound(totalSpend, totalOrders.toLong())?.let { Money(it).format() } ?: "-"}")
                        Text("${s.campaignProfit}: ${Money(totalProfit).format()}", style = MaterialTheme.typography.titleSmall,
                            color = if (totalProfit >= 0) DudhiaColors.Success else DudhiaColors.Error)
                    }
                }
            }
            if (campaigns.isEmpty()) item { Text(s.noCampaigns, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(campaigns, key = { "c${it.id}" }) { c ->
                val m = metrics[c.id]
                Card(Modifier.fillMaxWidth().clickable { editing = c; formError = null; showForm = true }) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("${c.name} · ${s.platformLabel(c.platform)}", style = MaterialTheme.typography.titleSmall)
                        Text("${fmtDate(c.startDate)}" + (c.endDate?.let { " - ${fmtDate(it)}" } ?: ""),
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${s.spendLabel}: ${Money(c.spendPaisa).format()} / ${s.budget}: ${Money(c.budgetPaisa).format()}")
                        if (m != null) {
                            Text("${s.attributedOrders}: ${m.orders} · ${s.attributedRevenue}: ${Money(m.revenuePaisa).format()}")
                            Text("${s.roas}: ${m.roasX100?.let { Marketing.formatX100(it) } ?: "-"} · " +
                                "${s.costPerOrder}: ${m.costPerOrderPaisa?.let { Money(it).format() } ?: "-"}")
                            Text("${s.costPerLead}: ${m.costPerLeadPaisa?.let { Money(it).format() } ?: "-"}")
                            Text("${s.campaignProfit}: ${Money(m.profitPaisa).format()}", style = MaterialTheme.typography.titleSmall,
                                color = if (m.profitPaisa >= 0) DudhiaColors.Success else DudhiaColors.Error)
                        }
                        if (c.expenseId != null) {
                            Text(s.spendAdded, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else if (c.spendPaisa > 0) {
                            OutlinedButton(onClick = { confirmId = c.id }) { Text(s.addSpendToExpenses) }
                        }
                    }
                }
            }
            message?.let { m -> item { Text(m, color = DudhiaColors.Warning) } }
        }
        FloatingActionButton(
            onClick = { editing = null; formError = null; showForm = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = s.newCampaign) }

        if (showForm) key(editing?.id ?: 0L) {
            CampaignFormDialog(s, editing, formError, onDismiss = { showForm = false },
                onSubmit = { c -> onSave(c) { err -> if (err == null) showForm = false else formError = err } })
        }
    }

    confirmId?.let { id ->
        AlertDialog(
            onDismissRequest = { confirmId = null },
            title = { Text(s.confirmTitle) },
            text = { Text(s.confirmAddSpend) },
            confirmButton = {
                TextButton(onClick = {
                    confirmId = null
                    onAddSpend(id) { err ->
                        message = when (err) { null -> null; "already" -> s.alreadyAdded; else -> s.saveFailed }
                    }
                }) { Text(s.yes) }
            },
            dismissButton = { TextButton(onClick = { confirmId = null }) { Text(s.cancel) } }
        )
    }
}
