package com.dudhia.manager.features.orders

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.dudhia.manager.core.Money
import com.dudhia.manager.core.Qty
import com.dudhia.manager.core.Strings
import com.dudhia.manager.database.CustomerEntity
import com.dudhia.manager.database.OrderEntity
import com.dudhia.manager.database.OrderItemEntity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Simple A4 invoice drawn with android.graphics.pdf.PdfDocument (no extra libraries, works offline). */
object InvoicePdf {
    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val MARGIN = 40f
    private const val QTY_X = 360f
    private const val RATE_X = 450f
    private const val AMOUNT_X = 555f

    private fun fit(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        var t = text
        while (t.isNotEmpty() && paint.measureText("$t…") > maxWidth) t = t.dropLast(1)
        return "$t…"
    }

    fun build(ctx: Context, s: Strings, order: OrderEntity, items: List<OrderItemEntity>, customer: CustomerEntity?): File {
        val dark = 0xFF403629.toInt()
        val grey = 0xFF817565.toInt()
        val title = Paint().apply { textSize = 24f; isFakeBoldText = true; color = dark }
        val normal = Paint().apply { textSize = 12f; color = dark }
        val muted = Paint().apply { textSize = 11f; color = grey }
        val bold = Paint(normal).apply { isFakeBoldText = true }
        val rightNormal = Paint(normal).apply { textAlign = Paint.Align.RIGHT }
        val rightBold = Paint(bold).apply { textAlign = Paint.Align.RIGHT }
        val line = Paint().apply { color = grey; strokeWidth = 0.8f }

        val doc = PdfDocument()
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
        var canvas = page.canvas
        var y = MARGIN + 24f

        fun ensureSpace(extra: Float) {
            if (y + extra > PAGE_H - MARGIN) {
                doc.finishPage(page)
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
                canvas = page.canvas
                y = MARGIN + 12f
            }
        }

        canvas.drawText("Dudhia | দুধিয়া", MARGIN, y, title); y += 22f
        canvas.drawText(s.invoiceTitle + " #" + order.id, MARGIN, y, bold)
        canvas.drawText(s.invoiceDate + ": " + SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(order.orderDate)),
            AMOUNT_X, y, rightNormal)
        y += 22f
        if (customer != null) {
            canvas.drawText(customer.name, MARGIN, y, bold); y += 16f
            canvas.drawText(customer.phone, MARGIN, y, normal); y += 16f
            val addr = listOfNotNull(customer.address, customer.area, customer.district).joinToString(", ")
            if (addr.isNotBlank()) { canvas.drawText(fit(addr, normal, 500f), MARGIN, y, muted); y += 16f }
        }
        y += 8f
        canvas.drawLine(MARGIN, y, AMOUNT_X, y, line); y += 16f
        canvas.drawText(s.invoiceItem, MARGIN, y, bold)
        canvas.drawText(s.invoiceQty, QTY_X, y, rightBold)
        canvas.drawText(s.invoiceRate, RATE_X, y, rightBold)
        canvas.drawText(s.invoiceAmount, AMOUNT_X, y, rightBold)
        y += 8f
        canvas.drawLine(MARGIN, y, AMOUNT_X, y, line); y += 16f

        for (li in items) {
            ensureSpace(24f)
            canvas.drawText(fit(li.productName, normal, 270f), MARGIN, y, normal)
            canvas.drawText(Qty.format(li.quantityMilli), QTY_X, y, rightNormal)
            canvas.drawText(Money(li.unitPricePaisa).format(), RATE_X, y, rightNormal)
            canvas.drawText(Money(li.lineTotalPaisa).format(), AMOUNT_X, y, rightNormal)
            y += 18f
        }
        ensureSpace(130f)
        canvas.drawLine(MARGIN, y, AMOUNT_X, y, line); y += 18f
        fun totalRow(label: String, value: String, p: Paint, lp: Paint) {
            canvas.drawText(label, QTY_X - 60f, y, lp)
            canvas.drawText(value, AMOUNT_X, y, p)
            y += 18f
        }
        totalRow(s.subtotal, Money(order.subtotalPaisa).format(), rightNormal, normal)
        if (order.discountPaisa > 0) totalRow(s.invoiceDiscount, "-" + Money(order.discountPaisa).format(), rightNormal, normal)
        if (order.deliveryChargePaisa > 0) totalRow(s.invoiceDelivery, Money(order.deliveryChargePaisa).format(), rightNormal, normal)
        totalRow(s.invoiceGrandTotal, Money(order.totalPaisa).format(), rightBold, bold)
        totalRow(s.invoicePayment, s.paymentLabel(order.paymentMethod) + " · " + (if (order.paymentStatus == "PAID") s.paid else s.unpaid),
            rightNormal, normal)
        order.notes?.let { y += 6f; canvas.drawText(fit(it, muted, 500f), MARGIN, y, muted); y += 16f }
        y += 14f
        canvas.drawText(s.invoiceThanks, MARGIN, y, muted)
        doc.finishPage(page)

        val dir = File(ctx.cacheDir, "invoices").apply { mkdirs() }
        val file = File(dir, "invoice-${order.id}.pdf")
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        return file
    }

    /** Builds the PDF and opens the Android share sheet (WhatsApp, Messenger, email, Drive...). */
    fun share(ctx: Context, s: Strings, order: OrderEntity, items: List<OrderItemEntity>, customer: CustomerEntity?) {
        val file = build(ctx, s, order, items, customer)
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, s.shareInvoice))
    }
}
