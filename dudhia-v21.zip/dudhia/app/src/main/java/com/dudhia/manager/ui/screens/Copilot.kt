package com.dudhia.manager.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.dudhia.manager.core.*
import com.dudhia.manager.database.*
import com.dudhia.manager.features.ai.CopilotIntent
import com.dudhia.manager.features.ai.CopilotParser
import com.dudhia.manager.features.crm.CustomerLabels
import com.dudhia.manager.features.crm.CustomerStats
import com.dudhia.manager.features.finance.Finance

private sealed class Chat {
    class User(val text: String) : Chat()
    class Bot(val lines: List<String>) : Chat()
    class Draft(val id: Long, val text: String, val category: String?, val amount: Long?) : Chat()
}

/** A proposed expense. Nothing is saved until the user presses the confirm button. */
@Composable
private fun DraftCard(s: Strings, d: Chat.Draft, onConfirm: (ExpenseEntity) -> Unit, onCancel: () -> Unit) {
    var category by remember { mutableStateOf(d.category ?: "OTHER") }
    var amount by remember { mutableStateOf(d.amount?.let { Money(it).plain() } ?: "") }
    var payment by remember { mutableStateOf("CASH") }
    var error by remember { mutableStateOf<String?>(null) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(s.copilotExpenseDraft, style = MaterialTheme.typography.titleSmall)
            if (d.category == null) Text(s.copilotCategoryMissing, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Picker(s.category, EXPENSE_CATEGORIES.map { Opt(it, s.categoryLabel(it)) }, category) { category = it }
            Field(s.amount, amount, { amount = it }, KeyboardType.Decimal)
            Picker(s.payment, PAYMENT_METHODS.map { Opt(it, s.paymentLabel(it)) }, payment) { payment = it }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val m = Money.parse(CopilotParser.normalize(amount))
                    if (m == null || m.paisa <= 0) {
                        error = s.copilotAmountMissing
                    } else {
                        val now = System.currentTimeMillis()
                        onConfirm(ExpenseEntity(
                            expenseDate = now, category = category, amountPaisa = m.paisa, paymentMethod = payment,
                            description = "AI: " + d.text, createdAt = now))
                    }
                }) { Text(s.copilotConfirm) }
                TextButton(onClick = onCancel) { Text(s.cancel) }
            }
        }
    }
}

@Composable
fun CopilotScreen(
    s: Strings,
    orders: List<OrderEntity>,
    items: List<OrderItemEntity>,
    expenses: List<ExpenseEntity>,
    returns: List<ReturnEntity>,
    returnItems: List<ReturnItemEntity>,
    writeOffs: List<StockMovementEntity>,
    products: List<ProductEntity>,
    customers: List<CustomerEntity>,
    vipAmountPaisa: Long,
    inactiveDays: Int,
    onAddExpense: (ExpenseEntity) -> Unit
) {
    val chat = remember { mutableStateListOf<Chat>() }
    var input by remember { mutableStateOf("") }
    var nextId by remember { mutableStateOf(1L) }
    val listState = rememberLazyListState()
    LaunchedEffect(chat.size) { if (chat.isNotEmpty()) listState.animateScrollToItem(chat.size - 1) }

    // ---- read-only answers, worked out from the data on the phone (no internet, no database writes)
    fun profitLines(period: String): List<String> {
        val range = periodRange(period)
        val p = Finance.compute(orders, items, expenses, range.first, range.second, returns, returnItems, writeOffs)
        val out = mutableListOf(s.copilotPeriodLabel(period))
        out.add("${s.productSales}: ${Money(p.productSales).format()}")
        out.add("${s.deliveryCollected}: ${Money(p.deliveryCollected).format()}")
        out.add("${s.revenue}: ${Money(p.revenue).format()}")
        if (p.refunds > 0) out.add("− ${s.refundsLine}: ${Money(p.refunds).format()}")
        out.add("− ${s.cogs}: ${Money(p.cogs).format()}")
        out.add("${s.grossProfit}: ${Money(p.grossProfit).format()}")
        out.add("− ${s.expensesTotal}: ${Money(p.expenses).format()}")
        if (p.writeOffs > 0) out.add("− ${s.writeOffLine}: ${Money(p.writeOffs).format()}")
        out.add("${s.netProfit}: ${Money(p.netProfit).format()}")
        if (p.missingCostLines > 0) out.add(s.missingCost)
        return out
    }
    fun lowStockLines(): List<String> {
        val low = products.filter { it.minStockMilli > 0 && it.stockMilli <= it.minStockMilli }
        if (low.isEmpty()) return listOf(s.copilotNoLowStock)
        return low.map { "${if (s.bn) it.nameBn else it.nameEn}: ${Qty.format(it.stockMilli)} / ${Qty.format(it.minStockMilli)}" }
    }
    fun inactiveLines(): List<String> {
        val byCustomer = orders.groupBy { it.customerId }
        val now = System.currentTimeMillis()
        val list = customers.filter { c ->
            val st = byCustomer[c.id]?.let { CustomerLabels.stats(it) } ?: CustomerStats.EMPTY
            CustomerLabels.compute(c, st, now, vipAmountPaisa, inactiveDays).contains("INACTIVE")
        }
        if (list.isEmpty()) return listOf(s.copilotNoInactive)
        val lines = list.take(20).map { "${it.name} · ${it.phone}" }
        return if (list.size > 20) lines + "…" else lines
    }

    fun send(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        chat.add(Chat.User(q))
        input = ""
        when (val intent = CopilotParser.parse(q)) {
            is CopilotIntent.ShowProfit -> chat.add(Chat.Bot(profitLines(intent.period)))
            is CopilotIntent.AddExpense -> {
                chat.add(Chat.Draft(nextId, q, intent.category, intent.amountPaisa))
                nextId += 1
            }
            CopilotIntent.LowStock -> chat.add(Chat.Bot(lowStockLines()))
            CopilotIntent.InactiveCustomers -> chat.add(Chat.Bot(inactiveLines()))
            CopilotIntent.Unknown -> chat.add(Chat.Bot(listOf(s.copilotUnknown)))
        }
    }

    // ---- voice: the phone's own speech recognizer (it may need internet, depending on the phone)
    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (res.resultCode == Activity.RESULT_OK && spoken != null) input = spoken
    }
    fun startVoice() {
        try {
            voice.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_PROMPT, s.copilotMic)
            })
        } catch (e: Exception) {
            chat.add(Chat.Bot(listOf(s.copilotVoiceMissing)))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(s.copilotTitle, style = MaterialTheme.typography.titleLarge)
        Text(s.copilotNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(s.copilotChipProfit, s.copilotChipLow, s.copilotChipInactive).forEach { label ->
                FilterChip(selected = false, onClick = { send(label) }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (chat.isEmpty()) item { Text(s.copilotIntro, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            itemsIndexed(chat) { _, c ->
                when (c) {
                    is Chat.User -> Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                        Text(c.text, Modifier.padding(12.dp))
                    }
                    is Chat.Bot -> Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            c.lines.forEach { Text(it) }
                        }
                    }
                    is Chat.Draft -> DraftCard(
                        s, c,
                        onConfirm = { e ->
                            onAddExpense(e)
                            val idx = chat.indexOfFirst { it is Chat.Draft && it.id == c.id }
                            if (idx >= 0) {
                                chat[idx] = Chat.Bot(listOf(s.copilotAdded + s.categoryLabel(e.category) + " · " + Money(e.amountPaisa).format()))
                            }
                        },
                        onCancel = {
                            val idx = chat.indexOfFirst { it is Chat.Draft && it.id == c.id }
                            if (idx >= 0) chat[idx] = Chat.Bot(listOf(s.copilotCancelledMsg))
                        }
                    )
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            OutlinedTextField(input, { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text(s.copilotPlaceholder) }, singleLine = true)
            IconButton(onClick = { startVoice() }) { Icon(Icons.Default.Mic, contentDescription = s.copilotMic) }
            Button(onClick = { send(input) }) { Text(s.copilotSend) }
        }
    }
}
