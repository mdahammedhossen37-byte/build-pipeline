package com.dudhia.manager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.dudhia.manager.core.*
import com.dudhia.manager.database.*

/** Full-screen form: choose what comes back, its condition, and the refund. */
@Composable
internal fun ReturnFormDialog(
    s: Strings, order: OrderEntity, items: List<OrderItemEntity>,
    returns: List<ReturnEntity>, returnItemsAll: List<ReturnItemEntity>, serverError: String?,
    onDismiss: () -> Unit, onSubmit: (ReturnEntity, List<ReturnItemEntity>) -> Unit
) {
    val myReturnIds = remember(returns, order.id) { returns.filter { it.orderId == order.id }.map { it.id }.toSet() }
    val alreadyRefunded = remember(returns, order.id) { returns.filter { it.orderId == order.id }.sumOf { it.refundPaisa } }
    val returnedQty = remember(returnItemsAll, myReturnIds) {
        returnItemsAll.filter { it.returnId in myReturnIds }
            .groupBy { it.orderItemId }.mapValues { e -> e.value.sumOf { x -> x.quantityMilli } }
    }
    val remaining = remember(items, returnedQty) { items.associate { it.id to (it.quantityMilli - (returnedQty[it.id] ?: 0L)) } }
    val qtyText = remember { mutableStateMapOf<Long, String>() }
    val cond = remember { mutableStateMapOf<Long, String>() }
    var refund by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("CASH") }
    var reason by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val suggested: Long = items.sumOf { li ->
        val q = Qty.parseMilli(qtyText[li.id] ?: "")
        if (q != null && q > 0) lineTotalPaisa(li.unitPricePaisa, q) else 0L
    }

    FormScaffold(
        title = s.returnTitle, confirmText = s.save, cancelText = s.cancel, onDismiss = onDismiss,
        onConfirm = {
            val lines = mutableListOf<ReturnItemEntity>()
            var bad: String? = null
            for (li in items) {
                val txt = qtyText[li.id] ?: ""
                if (txt.isBlank()) continue
                val q = Qty.parseMilli(txt)
                val rem = remaining[li.id] ?: 0L
                if (q == null || q <= 0) { bad = s.invalidNumber; break }
                if (q > rem) { bad = s.returnTooMuch; break }
                lines.add(ReturnItemEntity(
                    returnId = 0, orderItemId = li.id, productId = li.productId, productName = li.productName,
                    quantityMilli = q, itemCondition = cond[li.id] ?: "SELLABLE", unitCostPaisa = li.unitCostPaisa))
            }
            val refundM = if (refund.isBlank()) Money(suggested) else Money.parse(refund)
            if (bad != null) {
                error = bad
            } else if (lines.isEmpty()) {
                error = s.returnNothing
            } else if (refundM == null || refundM.paisa < 0) {
                error = s.invalidNumber
            } else if (refundM.paisa > order.totalPaisa - alreadyRefunded) {
                error = s.refundTooMuch
            } else {
                error = null
                onSubmit(ReturnEntity(
                    orderId = order.id, createdAt = System.currentTimeMillis(), reason = reason.trim().ifBlank { null },
                    refundPaisa = refundM.paisa, refundMethod = method), lines)
            }
        }
    ) {
        Text("#${order.id} · ${Money(order.totalPaisa).format()}", style = MaterialTheme.typography.titleMedium)
        items.forEach { li ->
            val rem = remaining[li.id] ?: 0L
            if (rem > 0) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(li.productName, style = MaterialTheme.typography.titleSmall)
                        Text("${s.remainingReturnable}: ${Qty.format(rem)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Field(s.returnQty, qtyText[li.id] ?: "", { qtyText[li.id] = it }, KeyboardType.Decimal)
                        Picker(s.conditionTitle,
                            listOf(Opt("SELLABLE", s.conditionLabel("SELLABLE")), Opt("DAMAGED", s.conditionLabel("DAMAGED"))),
                            cond[li.id] ?: "SELLABLE") { cond[li.id] = it }
                    }
                }
            }
        }
        Text("${s.suggestedRefund}: ${Money(suggested).format()}", style = MaterialTheme.typography.titleSmall)
        Field(s.refundAmount, refund, { refund = it }, KeyboardType.Decimal)
        Picker(s.refundMethodTitle, PAYMENT_METHODS.map { Opt(it, s.paymentLabel(it)) }, method) { method = it }
        Field(s.reasonLabel, reason, { reason = it }, single = false)
        Text(s.returnNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        val shown = error ?: if (serverError != null) s.saveFailed else null
        shown?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}
