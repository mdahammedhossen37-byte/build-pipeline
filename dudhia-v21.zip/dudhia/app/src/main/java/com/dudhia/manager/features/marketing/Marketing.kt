package com.dudhia.manager.features.marketing

import com.dudhia.manager.core.lineTotalPaisa
import com.dudhia.manager.database.*
import java.math.BigDecimal
import java.math.RoundingMode

val PLATFORMS = listOf("FACEBOOK", "INSTAGRAM", "GOOGLE", "TIKTOK", "YOUTUBE", "WHATSAPP", "ORGANIC", "REFERRAL", "OTHER")

/** Expense categories that count as advertising spend. */
val AD_CATEGORIES = setOf("FACEBOOK_ADS", "INSTAGRAM_ADS", "GOOGLE_ADS", "TIKTOK_ADS")

data class CampaignMetrics(
    val orders: Int,                 // delivered orders attributed to the campaign
    val revenuePaisa: Long,          // product sales after discount (delivery charge not included)
    val grossProfitPaisa: Long,      // revenue minus the cost saved on the order lines
    val spendPaisa: Long,
    val roasX100: Long?,             // ROAS x 100 (250 = 2.50), null when spend is 0
    val costPerOrderPaisa: Long?,    // null when there are no orders
    val costPerLeadPaisa: Long?,     // null when there are no leads
    val profitPaisa: Long            // gross profit minus spend
)

object Marketing {
    fun expenseCategory(platform: String): String = when (platform) {
        "FACEBOOK" -> "FACEBOOK_ADS"
        "INSTAGRAM" -> "INSTAGRAM_ADS"
        "GOOGLE", "YOUTUBE" -> "GOOGLE_ADS"
        "TIKTOK" -> "TIKTOK_ADS"
        else -> "OTHER"
    }

    /** num / den rounded half-up, null when den <= 0. No floating point. */
    fun divRound(num: Long, den: Long): Long? =
        if (den <= 0) null
        else BigDecimal.valueOf(num).divide(BigDecimal.valueOf(den), 0, RoundingMode.HALF_UP).longValueExact()

    /** (num / den) x 100 rounded half-up, null when den <= 0. */
    fun ratioX100(num: Long, den: Long): Long? =
        if (den <= 0) null
        else BigDecimal.valueOf(num).multiply(BigDecimal.valueOf(100))
            .divide(BigDecimal.valueOf(den), 0, RoundingMode.HALF_UP).longValueExact()

    fun formatX100(v: Long): String {
        val a = Math.abs(v)
        return (if (v < 0) "-" else "") + (a / 100) + "." + (a % 100).toString().padStart(2, '0')
    }

    fun compute(c: CampaignEntity, orders: List<OrderEntity>, items: List<OrderItemEntity>): CampaignMetrics {
        val mine = orders.filter { it.campaignId == c.id && it.status == "DELIVERED" && it.deletedAt == null }
        val ids = mine.map { it.id }.toSet()
        val revenue = mine.sumOf { it.subtotalPaisa - it.discountPaisa }
        val cogs = items.filter { it.orderId in ids }.sumOf { lineTotalPaisa(it.unitCostPaisa, it.quantityMilli) }
        val gross = revenue - cogs
        return CampaignMetrics(
            orders = mine.size, revenuePaisa = revenue, grossProfitPaisa = gross, spendPaisa = c.spendPaisa,
            roasX100 = ratioX100(revenue, c.spendPaisa),
            costPerOrderPaisa = divRound(c.spendPaisa, mine.size.toLong()),
            costPerLeadPaisa = divRound(c.spendPaisa, c.leads),
            profitPaisa = gross - c.spendPaisa
        )
    }
}
