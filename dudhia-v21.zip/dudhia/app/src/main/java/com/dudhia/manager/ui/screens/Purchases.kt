package com.dudhia.manager.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.dudhia.manager.core.*
import com.dudhia.manager.database.*
import com.dudhia.manager.ui.theme.DudhiaColors
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
private fun SupplierFormDialog(s: Strings, onDismiss: () -> Unit, onSubmit: (String, String?) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    FormScaffold(
        title = s.newSupplier, confirmText = s.save, cancelText = s.cancel, onDismiss = onDismiss,
        onConfirm = {
            if (name.isBlank()) error = s.supplierNameRequired
            else onSubmit(name.trim(), Phone.normalize(phone).ifBlank { null })
        }
    ) {
        Field(s.name, name, { name = it })
        Field(s.phone, phone, { phone = it }, KeyboardType.Phone)
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
private fun PurchaseFormDialog(
    s: Strings, suppliers: List<SupplierEntity>, products: List<ProductEntity>, serverError: String?,
    onDismiss: () -> Unit, onSubmit: (PurchaseEntity) -> Unit
) {
    var supplierId by remember { mutableStateOf(0L) }          // 0 = no supplier
    var productId by remember { mutableStateOf<Long?>(null) }
    var qty by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("") }
    var extra by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("") }
    var payment by remember { mutableStateOf("CASH") }
    var error by remember { mutableStateOf<String?>(null) }
    val byId = remember(products) { products.associateBy { it.id } }

    val q = Qty.parseMilli(qty)
    val u = Money.parse(unit)
    val ex = if (extra.isBlank()) Money.ZERO else Money.parse(extra)
    val calc: Triple<Long, Long, Long?>? =
        if (q != null && q > 0 && u != null && u.paisa > 0 && ex != null && ex.paisa >= 0) {
            val total = lineTotalPaisa(u.paisa, q) + ex.paisa
            val landed = Costing.landedUnitPaisa(u.paisa, q, ex.paisa)
            val prod = productId?.let { byId[it] }
            Triple(total, landed, prod?.let { Costing.weightedAvgCost(it.stockMilli, it.costPaisa, q, landed) })
        } else null

    FormScaffold(
        title = s.newPurchase, confirmText = s.save, cancelText = s.cancel, onDismiss = onDismiss,
        onConfirm = {
            val pid = productId
            val prod = pid?.let { byId[it] }
            if (prod == null) {
                error = s.chooseProduct
            } else if (calc == null || q == null || u == null || ex == null) {
                error = s.invalidNumber
            } else {
                val total = calc.first
                val paidM = if (paid.isBlank()) Money(total) else Money.parse(paid)
                if (paidM == null || paidM.paisa < 0) {
                    error = s.invalidNumber
                } else if (paidM.paisa > total) {
                    error = s.paidTooMuch
                } else {
                    error = null
                    val now = System.currentTimeMillis()
                    onSubmit(PurchaseEntity(
                        supplierId = if (supplierId == 0L) null else supplierId, productId = prod.id,
                        productName = prod.nameBn.ifBlank { prod.nameEn }, purchaseDate = now,
                        quantityMilli = q, unitCostPaisa = u.paisa, extraCostPaisa = ex.paisa,
                        totalPaisa = total, paidPaisa = paidM.paisa, paymentMethod = payment,
                        landedUnitCostPaisa = calc.second, createdAt = now))
                }
            }
        }
    ) {
        Picker(s.supplierLabel, listOf(Opt(0L, s.noSupplier)) + suppliers.map { Opt(it.id, it.name, it.phone) }, supplierId) { supplierId = it }
        Picker(s.product, products.map { Opt(it.id, if (s.bn) it.nameBn else it.nameEn,
            "${s.unitLabel(it.unit)} · ${s.stock}: ${Qty.format(it.stockMilli)}") }, productId) { productId = it }
        Field(s.quantity, qty, { qty = it }, KeyboardType.Decimal)
        Field(s.unitCost, unit, { unit = it }, KeyboardType.Decimal)
        Field(s.extraCost, extra, { extra = it }, KeyboardType.Decimal)
        Field(s.paidNow, paid, { paid = it }, KeyboardType.Decimal)
        Picker(s.payment, PAYMENT_METHODS.map { Opt(it, s.paymentLabel(it)) }, payment) { payment = it }
        if (calc != null) {
            Text("${s.total}: ${Money(calc.first).format()}", style = MaterialTheme.typography.titleMedium)
            Text("${s.landedCost}: ${Money(calc.second).format()}")
            calc.third?.let { Text("${s.newAvgCost}: ${Money(it).format()}") }
        }
        val shown = error ?: when (serverError) { null -> null; "invalid" -> s.invalidNumber; else -> s.saveFailed }
        shown?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
private fun PayFormDialog(
    s: Strings, purchase: PurchaseEntity, serverError: String?, onDismiss: () -> Unit, onSubmit: (Long) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val due = purchase.totalPaisa - purchase.paidPaisa
    FormScaffold(
        title = s.payDue, confirmText = s.save, cancelText = s.cancel, onDismiss = onDismiss,
        onConfirm = {
            val m = Money.parse(amount)
            if (m == null || m.paisa <= 0) error = s.amountRequired
            else if (m.paisa > due) error = s.payTooMuch
            else { error = null; onSubmit(m.paisa) }
        }
    ) {
        Text("${purchase.productName} × ${Qty.format(purchase.quantityMilli)}", style = MaterialTheme.typography.titleMedium)
        Text("${s.total}: ${Money(purchase.totalPaisa).format()}")
        Text("${s.paidLabel}: ${Money(purchase.paidPaisa).format()}")
        Text("${s.due}: ${Money(due).format()}", style = MaterialTheme.typography.titleMedium)
        Field(s.payAmount, amount, { amount = it }, KeyboardType.Decimal)
        val shown = error ?: if (serverError != null) s.saveFailed else null
        shown?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
fun PurchasesScreen(
    s: Strings,
    purchases: List<PurchaseEntity>,
    suppliers: List<SupplierEntity>,
    products: List<ProductEntity>,
    onAddSupplier: (String, String?) -> Unit,
    onPurchase: (PurchaseEntity, (String?) -> Unit) -> Unit,
    onPay: (Long, Long, (String?) -> Unit) -> Unit
) {
    var showPurchase by remember { mutableStateOf(false) }
    var showSupplier by remember { mutableStateOf(false) }
    var formError by remember { mutableStateOf<String?>(null) }
    var payId by remember { mutableStateOf<Long?>(null) }
    val names = remember(suppliers) { suppliers.associate { it.id to it.name } }
    val dueBy = remember(purchases) {
        purchases.filter { it.supplierId != null }.groupBy { it.supplierId ?: 0L }
            .mapValues { e -> e.value.sumOf { p -> p.totalPaisa - p.paidPaisa } }
    }
    val totalDue = remember(purchases) { purchases.sumOf { it.totalPaisa - it.paidPaisa } }
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy", Locale.US) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(top = 16.dp, bottom = 88.dp)
        ) {
            item { Text(s.morePurchases, style = MaterialTheme.typography.titleLarge) }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(s.supplierDueCard, style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(Money(totalDue).format(), style = MaterialTheme.typography.headlineSmall)
                    }
                }
            }
            item { Text(s.purchaseNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            item { OutlinedButton(onClick = { showSupplier = true }) { Text(s.addSupplier) } }
            item { Text(s.supplier, style = MaterialTheme.typography.titleMedium) }
            if (suppliers.isEmpty()) item { Text(s.noSuppliers, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(suppliers, key = { "s${it.id}" }) { sp ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(sp.name, style = MaterialTheme.typography.titleSmall)
                        sp.phone?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        Text("${s.due}: ${Money(dueBy[sp.id] ?: 0L).format()}")
                    }
                }
            }
            item { Text(s.morePurchases, style = MaterialTheme.typography.titleMedium) }
            if (purchases.isEmpty()) item { Text(s.noPurchases, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(purchases, key = { "p${it.id}" }) { p ->
                val due = p.totalPaisa - p.paidPaisa
                Card(Modifier.fillMaxWidth().clickable(enabled = due > 0) { formError = null; payId = p.id }) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${p.productName} × ${Qty.format(p.quantityMilli)}", style = MaterialTheme.typography.titleSmall)
                        Text("${fmt.format(java.util.Date(p.purchaseDate))} · ${p.supplierId?.let { names[it] } ?: s.noSupplier}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${s.total}: ${Money(p.totalPaisa).format()} · ${s.paidLabel}: ${Money(p.paidPaisa).format()}")
                        if (due > 0) Text("${s.due}: ${Money(due).format()}", color = DudhiaColors.Warning)
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { formError = null; showPurchase = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = s.newPurchase) }

        if (showPurchase) {
            PurchaseFormDialog(s, suppliers, products, formError, onDismiss = { showPurchase = false },
                onSubmit = { p -> onPurchase(p) { err -> if (err == null) showPurchase = false else formError = err } })
        }
        if (showSupplier) {
            SupplierFormDialog(s, onDismiss = { showSupplier = false },
                onSubmit = { n, ph -> onAddSupplier(n, ph); showSupplier = false })
        }
        val pay = payId?.let { id -> purchases.firstOrNull { it.id == id } }
        if (pay != null) {
            PayFormDialog(s, pay, formError, onDismiss = { payId = null },
                onSubmit = { amt -> onPay(pay.id, amt) { err -> if (err == null) payId = null else formError = err } })
        }
    }
}
