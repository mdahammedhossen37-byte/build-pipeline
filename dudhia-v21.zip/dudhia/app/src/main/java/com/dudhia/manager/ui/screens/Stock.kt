package com.dudhia.manager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.dudhia.manager.core.*
import com.dudhia.manager.database.ProductEntity
import com.dudhia.manager.database.StockMovementEntity
import com.dudhia.manager.ui.theme.DudhiaColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Full-screen form: reduce stock for damaged/expired/lost goods, or correct a wrong count. */
@Composable
internal fun StockAdjustDialog(
    s: Strings, product: ProductEntity, serverError: String?,
    onDismiss: () -> Unit, onSubmit: (Long, String) -> Unit
) {
    var reason by remember { mutableStateOf("DAMAGED") }
    var direction by remember { mutableStateOf("OUT") }
    var qty by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    FormScaffold(
        title = s.adjustStock, confirmText = s.save, cancelText = s.cancel, onDismiss = onDismiss,
        onConfirm = {
            val q = Qty.parseMilli(qty)
            if (q == null || q <= 0) {
                error = s.invalidNumber
            } else {
                val delta = if (reason == "CORRECTION" && direction == "IN") q else -q
                if (product.stockMilli + delta < 0) {
                    error = s.adjustNotEnough
                } else {
                    error = null
                    onSubmit(delta, reason)
                }
            }
        }
    ) {
        Text(if (s.bn) product.nameBn else product.nameEn, style = MaterialTheme.typography.titleMedium)
        Text("${s.stock}: ${Qty.format(product.stockMilli)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Picker(s.adjustReason, listOf("DAMAGED", "EXPIRED", "LOST", "CORRECTION").map { Opt(it, s.movementLabel(it)) }, reason) { reason = it }
        if (reason == "CORRECTION") {
            Picker(s.adjustDirection, listOf(Opt("IN", s.stockInChoice), Opt("OUT", s.stockOutChoice)), direction) { direction = it }
        }
        Field(s.quantity, qty, { qty = it }, KeyboardType.Decimal)
        Text(s.adjustNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        val shown = error ?: if (serverError != null) s.saveFailed else null
        shown?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
fun StockHistoryScreen(s: Strings, movements: List<StockMovementEntity>, products: List<ProductEntity>) {
    val names = remember(products) { products.associate { it.id to (if (s.bn) it.nameBn else it.nameEn) } }
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US) }
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
    ) {
        item { Text(s.moreStock, style = MaterialTheme.typography.titleLarge) }
        if (movements.isEmpty()) item { Text(s.noMovements, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(movements, key = { "m${it.id}" }) { m ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("${names[m.productId] ?: "#${m.productId}"} · ${s.movementLabel(m.reason)}", style = MaterialTheme.typography.titleSmall)
                    val sign = if (m.deltaMilli > 0) "+" else ""
                    Text("$sign${Qty.format(m.deltaMilli)}",
                        color = if (m.deltaMilli < 0) DudhiaColors.Error else if (m.deltaMilli > 0) DudhiaColors.Success else MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(fmt.format(Date(m.createdAt)), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
