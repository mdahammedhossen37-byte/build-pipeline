package com.dudhia.manager.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.dudhia.manager.core.*
import com.dudhia.manager.database.*
import com.dudhia.manager.ui.theme.DudhiaColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val TASK_CATEGORIES = listOf(
    "CUSTOMER_FOLLOWUP", "SUPPLIER_FOLLOWUP", "PAYMENT_COLLECTION", "PRODUCT_SOURCING",
    "STOCK_REPLENISHMENT", "EXPIRY", "MARKETING", "ADMIN"
)
private val PRIORITIES = listOf("HIGH", "NORMAL", "LOW")
private val REMIND_CHOICES = listOf(-1L, 0L, 10L, 60L, 1440L)

private fun toAscii(t: String): String = t.map { if (it in '০'..'৯') '0' + (it - '০') else it }.joinToString("")
private fun fmtDateTime(ms: Long): String = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US).format(Date(ms))
private fun fmtDateOnly(ms: Long): String = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(ms))
private fun fmtTimeOnly(ms: Long): String = SimpleDateFormat("HH:mm", Locale.US).format(Date(ms))

/** "dd/MM/yyyy" + optional "HH:mm" (default 09:00). Null when invalid. */
private fun parseDateTime(date: String, time: String): Long? = try {
    val f = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)
    f.isLenient = false
    f.parse(toAscii(date).trim() + " " + (if (time.isBlank()) "09:00" else toAscii(time).trim()))?.time
} catch (e: Exception) { null }

@Composable
private fun TaskFormDialog(
    s: Strings, initial: TaskEntity?, customers: List<CustomerEntity>, orders: List<OrderEntity>,
    serverError: String?, onDismiss: () -> Unit, onSubmit: (TaskEntity) -> Unit
) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var description by remember { mutableStateOf(initial?.description ?: "") }
    var date by remember { mutableStateOf(initial?.dueAt?.let { fmtDateOnly(it) } ?: "") }
    var time by remember { mutableStateOf(initial?.dueAt?.let { fmtTimeOnly(it) } ?: "") }
    var priority by remember { mutableStateOf(initial?.priority ?: "NORMAL") }
    var category by remember { mutableStateOf(initial?.category ?: "ADMIN") }
    var remind by remember { mutableStateOf(initial?.remindMinutesBefore ?: -1L) }
    var customerId by remember { mutableStateOf(if (initial?.relatedType == "CUSTOMER") initial.relatedId ?: 0L else 0L) }
    var orderId by remember { mutableStateOf(if (initial?.relatedType == "ORDER") initial.relatedId ?: 0L else 0L) }
    var error by remember { mutableStateOf<String?>(null) }
    val customerNames = remember(customers) { customers.associate { it.id to it.name } }

    FormScaffold(
        title = if (initial == null) s.newTask else s.editTask,
        confirmText = s.save, cancelText = s.cancel, onDismiss = onDismiss,
        onConfirm = {
            val due = if (date.isBlank()) null else parseDateTime(date, time)
            if (title.isBlank()) {
                error = s.taskTitleRequired
            } else if (date.isNotBlank() && due == null) {
                error = s.invalidDueTime
            } else if (remind >= 0 && due == null) {
                error = s.needDueForReminder
            } else {
                error = null
                val now = System.currentTimeMillis()
                val base = initial ?: TaskEntity(title = "", priority = priority, category = category, createdAt = now)
                onSubmit(base.copy(
                    title = title.trim(), description = description.trim().ifBlank { null }, dueAt = due,
                    priority = priority, category = category,
                    relatedType = if (orderId != 0L) "ORDER" else if (customerId != 0L) "CUSTOMER" else null,
                    relatedId = if (orderId != 0L) orderId else if (customerId != 0L) customerId else null,
                    remindMinutesBefore = if (remind >= 0) remind else null))
            }
        }
    ) {
        Field(s.taskTitle, title, { title = it })
        Field(s.notes, description, { description = it }, single = false)
        Field(s.dueDate, date, { date = it })
        Field(s.dueTime, time, { time = it })
        Picker(s.remindTitle, REMIND_CHOICES.map { Opt(it, s.remindLabel(it)) }, remind) { remind = it }
        Picker(s.priorityTitle, PRIORITIES.map { Opt(it, s.priorityLabel(it)) }, priority) { priority = it }
        Picker(s.taskTypeTitle, TASK_CATEGORIES.map { Opt(it, s.taskCategoryLabel(it)) }, category) { category = it }
        Picker(s.relatedCustomer, listOf(Opt(0L, s.noneChoice)) + customers.map { Opt(it.id, it.name, it.phone) }, customerId) { customerId = it }
        Picker(s.relatedOrder, listOf(Opt(0L, s.noneChoice)) + orders.map { Opt(it.id, "#${it.id}", customerNames[it.customerId]) }, orderId) { orderId = it }
        Text(s.reminderNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        val shown = error ?: if (serverError != null) s.saveFailed else null
        shown?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
fun TasksScreen(
    s: Strings,
    tasks: List<TaskEntity>,
    customers: List<CustomerEntity>,
    orders: List<OrderEntity>,
    onSave: (TaskEntity, (String?) -> Unit) -> Unit,
    onStatus: (Long, String) -> Unit
) {
    val ctx = LocalContext.current
    var filter by remember { mutableStateOf("TODAY") }
    var showForm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<TaskEntity?>(null) }
    var formError by remember { mutableStateOf<String?>(null) }
    var actionId by remember { mutableStateOf<Long?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    val customerNames = remember(customers) { customers.associate { it.id to it.name } }
    val today = remember { periodRange("TODAY") }

    // Android 13+ asks for notification permission once, when a reminder is first saved.
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        message = if (granted) null else s.notifDenied
    }
    fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val shown = remember(tasks, filter) {
        val n = System.currentTimeMillis()
        when (filter) {
            "TODAY" -> tasks.filter { it.status == "OPEN" && (it.dueAt ?: -1L) >= today.first && (it.dueAt ?: -1L) < today.second }
            "OVERDUE" -> tasks.filter { it.status == "OPEN" && (it.dueAt ?: Long.MAX_VALUE) < n }
            "UPCOMING" -> tasks.filter { it.status == "OPEN" && (it.dueAt ?: Long.MAX_VALUE) >= today.second }
            "DONE" -> tasks.filter { it.status == "DONE" }
            else -> tasks
        }
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(top = 16.dp, bottom = 88.dp)
        ) {
            item { Text(s.moreTasks, style = MaterialTheme.typography.titleLarge) }
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("TODAY" to s.periodToday, "OVERDUE" to s.filterOverdue, "UPCOMING" to s.filterUpcoming,
                        "DONE" to s.filterDone, "ALL" to s.all).forEach { (code, label) ->
                        FilterChip(selected = filter == code, onClick = { filter = code }, label = { Text(label) })
                    }
                }
            }
            message?.let { m -> item { Text(m, color = DudhiaColors.Warning) } }
            if (shown.isEmpty()) item { Text(s.noTasks, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(shown, key = { "t${it.id}" }) { t ->
                val overdue = t.status == "OPEN" && (t.dueAt ?: Long.MAX_VALUE) < System.currentTimeMillis()
                Card(Modifier.fillMaxWidth().clickable { actionId = t.id }) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(t.title, style = MaterialTheme.typography.titleSmall)
                        Text(t.dueAt?.let { fmtDateTime(it) } ?: s.noDueDate,
                            color = if (overdue) DudhiaColors.Error else MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${s.taskCategoryLabel(t.category)} · ${s.priorityLabel(t.priority)}",
                            color = if (t.priority == "HIGH") DudhiaColors.Warning else MaterialTheme.colorScheme.onSurfaceVariant)
                        when (t.relatedType) {
                            "CUSTOMER" -> customerNames[t.relatedId]?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            "ORDER" -> Text("#${t.relatedId}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            else -> {}
                        }
                        if (t.status == "DONE") Text(s.filterDone, color = DudhiaColors.Success)
                        if (t.status == "CANCELLED") Text(s.cancelTaskAction, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { editing = null; formError = null; showForm = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = s.newTask) }

        if (showForm) key(editing?.id ?: 0L) {
            TaskFormDialog(s, editing, customers, orders, formError, onDismiss = { showForm = false },
                onSubmit = { task ->
                    if (task.remindMinutesBefore != null) askNotificationPermission()
                    onSave(task) { err -> if (err == null) showForm = false else formError = err }
                })
        }
    }

    val actionTask = actionId?.let { id -> tasks.firstOrNull { it.id == id } }
    if (actionTask != null) {
        AlertDialog(
            onDismissRequest = { actionId = null },
            title = { Text(actionTask.title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    actionTask.description?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    if (actionTask.status == "OPEN") {
                        Button(onClick = { onStatus(actionTask.id, "DONE"); actionId = null }, modifier = Modifier.fillMaxWidth()) {
                            Text(s.markDone)
                        }
                        OutlinedButton(onClick = { editing = actionTask; formError = null; showForm = true; actionId = null },
                            modifier = Modifier.fillMaxWidth()) { Text(s.editAction) }
                        OutlinedButton(onClick = { onStatus(actionTask.id, "CANCELLED"); actionId = null },
                            modifier = Modifier.fillMaxWidth()) { Text(s.cancelTaskAction) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { actionId = null }) { Text(s.close) } }
        )
    }
}
