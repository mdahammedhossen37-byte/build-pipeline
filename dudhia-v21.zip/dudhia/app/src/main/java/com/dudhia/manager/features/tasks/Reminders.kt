package com.dudhia.manager.features.tasks

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.dudhia.manager.DudhiaApp
import com.dudhia.manager.MainActivity
import com.dudhia.manager.core.ReminderMath
import com.dudhia.manager.database.TaskEntity
import java.util.concurrent.TimeUnit

object ReminderScheduler {
    const val CHANNEL_ID = "dudhia_reminders"

    private fun workName(id: Long) = "task-$id"

    fun cancel(ctx: Context, taskId: Long) {
        WorkManager.getInstance(ctx).cancelUniqueWork(workName(taskId))
    }

    /** (Re)schedules the reminder of a task. Only OPEN tasks with a due time and a reminder get one. */
    fun schedule(ctx: Context, task: TaskEntity) {
        val due = task.dueAt
        val remind = task.remindMinutesBefore
        if (task.status != "OPEN" || due == null || remind == null) { cancel(ctx, task.id); return }
        val now = System.currentTimeMillis()
        if (ReminderMath.isTooOld(due, remind, now)) { cancel(ctx, task.id); return }
        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(ReminderMath.delayMillis(due, remind, now), TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("taskId" to task.id))
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(workName(task.id), ExistingWorkPolicy.REPLACE, request)
    }

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Reminders", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    fun showNotification(ctx: Context, task: TaskEntity) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        ensureChannel(ctx)
        val intent = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            ctx, task.id.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(task.title)
            .setContentText(task.description ?: "")
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        NotificationManagerCompat.from(ctx).notify(task.id.toInt(), notification)
    }
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getLong("taskId", -1L)
        if (id < 0) return Result.success()
        val db = (applicationContext as DudhiaApp).db
        val task = db.tasks().get(id) ?: return Result.success()
        if (task.status != "OPEN") return Result.success()      // finished or cancelled meanwhile
        ReminderScheduler.showNotification(applicationContext, task)
        return Result.success()
    }
}
