package com.dudhia.manager.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.dudhia.manager.core.*
import com.dudhia.manager.database.*
import com.dudhia.manager.features.finance.Finance
import com.dudhia.manager.ui.theme.DudhiaColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
private fun SumRow(label: String, value: String, bold: Boolean = false, color: androidx.compose.ui.graphics.Color? = null) {
    val style = if (bold) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyLarge
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = style, modifier = Modifier.weight(1f))
        Text(value, style = style, color = color ?: MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun ExpenseFormDialog(s: Strings, onDismiss: () -> Unit, onSubmit: (ExpenseEntity) -> Unit) {
    var category by remember { mutableStateOf(EXPENSE_CATEGORIES.first()) }
    var amount by remember { mutableStateOf("") }
    var payment by remember { mutableStateOf("CASH") }
    var desc by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    FormScaffold(
        title = s.newExpense, confirmText = s.save, cancelText = s.cancel, onDismiss = onDismiss,
        onConfirm = {
            val m = Money.parse(amount)
            if (m == null || m.paisa <= 0) {
                error = s.amountRequired
            } else {
                val now = System.currentTimeMillis()
                onSubmit(ExpenseEntity(
                    expenseDate = now, category = category, amountPaisa = m.paisa, paymentMethod = payment,
                    description = desc.trim().ifBlank { null }, createdAt = now))
            }
        }
    ) {
        Picker(s.category, EXPENSE_CATEGORIES.map { Opt(it, s.categoryLabel(it)) }, category) { category = it }
        Field(s.amount, amount, { amount = it }, KeyboardType.Decimal)
        Picker(s.payment, PAYMENT_METHODS.map { Opt(it, s.paymentLabel(it)) }, payment) { payment = it }
        Field(s.description, desc, { desc = it }, single = false)
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
fun FinanceScreen(
    s: Strings,
    orders: List<OrderEntity>,
    items: List<OrderItemEntity>,
    expenses: List<ExpenseEntity>,
    returns: List<ReturnEntity>,
    returnItems: List<ReturnItemEntity>,
    writeOffs: List<StockMovementEntity>,
    onAdd: (ExpenseEntity) -> Unit,
    onVoid: (Long) -> Unit
) {
    var period by remember { mutableStateOf("TODAY") }
    var showForm by remember { mutableStateOf(false) }
    var voidId by remember { mutableStateOf<Long?>(null) }
    val range = remember(period) { periodRange(period) }
    val pnl = remember(orders, items, expenses, returns, returnItems, writeOffs, range) {
        Finance.compute(orders, items, expenses, range.first, range.second, returns, returnItems, writeOffs)
    }
    val shownExp = remember(expenses, range) { expenses.filter { it.expenseDate >= range.first && it.expenseDate < range.second } }
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy", Locale.US) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(top = 16.dp, bottom = 88.dp)
        ) {
            item { Text(s.finance, style = MaterialTheme.typography.titleLarge) }
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("TODAY" to s.periodToday, "WEEK" to s.periodWeek, "MONTH" to s.periodMonth, "ALL" to s.periodAll)
                        .forEach { (code, label) ->
                            FilterChip(selected = period == code, onClick = { period = code }, label = { Text(label) })
                        }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SumRow(s.productSales, Money(pnl.productSales).format())
                        SumRow(s.deliveryCollected, Money(pnl.deliveryCollected).format())
                        SumRow(s.revenue, Money(pnl.revenue).format(), bold = true)
                        if (pnl.refunds > 0) {
                            SumRow("− ${s.refundsLine}", Money(pnl.refunds).format())
                            SumRow(s.netRevenueLabel, Money(pnl.netRevenue).format(), bold = true)
                        }
                        SumRow("− ${s.cogs}", Money(pnl.cogs).format())
                        SumRow(s.grossProfit, Money(pnl.grossProfit).format(), bold = true)
                        SumRow("− ${s.expensesTotal}", Money(pnl.expenses).format())
                        if (pnl.writeOffs > 0) SumRow("− ${s.writeOffLine}", Money(pnl.writeOffs).format())
                        SumRow(s.netProfit, Money(pnl.netProfit).format(), bold = true,
                            color = if (pnl.netProfit >= 0) DudhiaColors.Success else DudhiaColors.Error)
                    }
                }
            }
            if (pnl.missingCostLines > 0) item { Text(s.missingCost, color = DudhiaColors.Warning) }
            item { Text(s.basisNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            item { Text(s.expenseList, style = MaterialTheme.typography.titleMedium) }
            if (shownExp.isEmpty()) item { Text(s.noExpenses, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(shownExp, key = { it.id }) { e ->
                Card(Modifier.fillMaxWidth().clickable { voidId = e.id }) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${s.categoryLabel(e.category)} · ${Money(e.amountPaisa).format()}", style = MaterialTheme.typography.titleSmall)
                        Text("${fmt.format(Date(e.expenseDate))} · ${s.paymentLabel(e.paymentMethod)}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        e.description?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { showForm = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = s.newExpense) }

        if (showForm) {
            ExpenseFormDialog(s, onDismiss = { showForm = false }, onSubmit = { onAdd(it); showForm = false })
        }
    }

    voidId?.let { id ->
        AlertDialog(
            onDismissRequest = { voidId = null },
            title = { Text(s.voidTitle) },
            confirmButton = { TextButton(onClick = { onVoid(id); voidId = null }) { Text(s.voidYes) } },
            dismissButton = { TextButton(onClick = { voidId = null }) { Text(s.cancel) } }
        )
    }
}
