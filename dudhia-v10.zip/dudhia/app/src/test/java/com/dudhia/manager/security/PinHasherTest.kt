package com.dudhia.manager.security

import org.junit.Assert.*
import org.junit.Test

class PinHasherTest {
    @Test fun verifyAcceptsCorrectAndRejectsWrongPin() {
        val salt = PinHasher.newSalt()
        val h = PinHasher.hash("1234", salt)
        assertTrue(PinHasher.verify("1234", salt, h))
        assertFalse(PinHasher.verify("1235", salt, h))
    }
    @Test fun hashIsNotThePin_andSaltChangesIt() {
        val h1 = PinHasher.hash("1234", PinHasher.newSalt())
        val h2 = PinHasher.hash("1234", PinHasher.newSalt())
        assertNotEquals("1234", h1)
        assertNotEquals(h1, h2)
    }
}
