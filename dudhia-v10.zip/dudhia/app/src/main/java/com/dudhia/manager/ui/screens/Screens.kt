package com.dudhia.manager.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.dudhia.manager.core.*
import com.dudhia.manager.database.CustomerEntity
import com.dudhia.manager.database.ProductEntity
import kotlinx.coroutines.launch

@Composable
fun Onboarding(s: Strings, onStart: () -> Unit) = Column(
    Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
    horizontalAlignment = Alignment.CenterHorizontally
) {
    Text(s.welcomeTitle, style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(12.dp))
    Text(s.welcomeBody, style = MaterialTheme.typography.bodyLarge)
    Spacer(Modifier.height(24.dp))
    Button(onClick = onStart) { Text(s.start) }
}

@Composable
private fun StatCard(label: String, value: String, mod: Modifier = Modifier) =
    Card(mod, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.headlineSmall)
        }
    }

@Composable
fun DashboardScreen(
    s: Strings, customers: Int, products: Int, lowStock: Int,
    todaySales: Long, todayExpenses: Long, todayNet: Long, pending: Int, delivered: Int, cancelled: Int
) = Column(
    Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
) {
    Text(s.dashboard, style = MaterialTheme.typography.titleLarge)
    StatCard(s.todaySales, Money(todaySales).format(), Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCard(s.todayExpenses, Money(todayExpenses).format(), Modifier.weight(1f))
        StatCard(s.todayNet, Money(todayNet).format(), Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCard(s.pendingOrders, pending.toString(), Modifier.weight(1f))
        StatCard(s.deliveredOrders, delivered.toString(), Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCard(s.cancelledOrders, cancelled.toString(), Modifier.weight(1f))
        StatCard(s.lowStock, lowStock.toString(), Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCard(s.customers, customers.toString(), Modifier.weight(1f))
        StatCard(s.products, products.toString(), Modifier.weight(1f))
    }
}

@Composable
fun MoreScreen(
    s: Strings, onFinance: () -> Unit, onBackup: () -> Unit, onSecurity: () -> Unit, onSettings: () -> Unit
) = Column(
    Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
) {
    Text(s.more, style = MaterialTheme.typography.titleLarge)
    Card(Modifier.fillMaxWidth().clickable { onFinance() }) {
        Text(s.moreFinance, Modifier.padding(16.dp), style = MaterialTheme.typography.titleMedium)
    }
    Card(Modifier.fillMaxWidth().clickable { onBackup() }) {
        Text(s.moreBackup, Modifier.padding(16.dp), style = MaterialTheme.typography.titleMedium)
    }
    Card(Modifier.fillMaxWidth().clickable { onSecurity() }) {
        Text(s.moreSecurity, Modifier.padding(16.dp), style = MaterialTheme.typography.titleMedium)
    }
    Card(Modifier.fillMaxWidth().clickable { onSettings() }) {
        Text(s.settings, Modifier.padding(16.dp), style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun CrmScreen(
    s: Strings,
    customers: List<CustomerEntity>,
    findByPhone: suspend (String) -> List<CustomerEntity>,
    onSave: (CustomerEntity) -> Unit
) {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var showForm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<CustomerEntity?>(null) }
    var pending by remember { mutableStateOf<CustomerEntity?>(null) }
    var dups by remember { mutableStateOf<List<CustomerEntity>>(emptyList()) }

    val shown = remember(customers, query) {
        val q = query.trim()
        if (q.isEmpty()) customers else customers.filter {
            it.name.contains(q, ignoreCase = true) || it.phone.contains(Phone.normalize(q).ifEmpty { q })
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text(s.crm, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(query, { query = it }, label = { Text(s.search) },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            if (customers.isEmpty()) Text(s.noCustomers, color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                items(shown, key = { it.id }) { c ->
                    Card(Modifier.fillMaxWidth().clickable { editing = c; showForm = true }) {
                        Column(Modifier.padding(12.dp)) {
                            Text(c.name, style = MaterialTheme.typography.titleMedium)
                            Text(c.phone, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            val place = listOfNotNull(c.area, c.district).joinToString(", ")
                            if (place.isNotEmpty()) Text(place, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { editing = null; showForm = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = s.newCustomer) }

        if (showForm) key(editing?.id ?: 0L) {
            CustomerFormDialog(s, editing, onDismiss = { showForm = false }, onSubmit = { c ->
                scope.launch {
                    val found = findByPhone(c.phone).filter { it.id != c.id }
                    if (found.isEmpty()) { onSave(c); showForm = false }
                    else { pending = c; dups = found }
                }
            })
        }
    }
    pending?.let { p ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text(s.dupTitle) },
            text = { Text(dups.joinToString("\n") { "${it.name}\n${it.phone}" }) },
            confirmButton = {
                TextButton(onClick = { editing = dups.first(); pending = null; showForm = true }) { Text(s.openExisting) }
            },
            dismissButton = {
                TextButton(onClick = { onSave(p); pending = null; showForm = false }) { Text(s.saveAnyway) }
            }
        )
    }
}

@Composable
fun InventoryScreen(s: Strings, products: List<ProductEntity>, onSave: (ProductEntity, (String?) -> Unit) -> Unit) {
    var showForm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<ProductEntity?>(null) }
    var serverError by remember { mutableStateOf<String?>(null) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text(s.inventory, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            if (products.isEmpty()) Text(s.noProducts)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                items(products, key = { it.id }) { p ->
                    val low = p.minStockMilli > 0 && p.stockMilli <= p.minStockMilli
                    Card(Modifier.fillMaxWidth().clickable { editing = p; serverError = null; showForm = true }) {
                        Column(Modifier.padding(12.dp)) {
                            Text(if (s.bn) p.nameBn else p.nameEn, style = MaterialTheme.typography.titleMedium)
                            Text("${p.sku} · ${s.unitLabel(p.unit)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${Money(p.pricePaisa).format()} / ${Money(p.costPaisa).format()}",
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${s.stock}: ${Qty.format(p.stockMilli)}",
                                color = if (low) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { editing = null; serverError = null; showForm = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = s.newProduct) }

        if (showForm) key(editing?.id ?: 0L) {
            ProductFormDialog(s, editing, serverError, onDismiss = { showForm = false }, onSubmit = { p ->
                onSave(p) { err -> if (err == null) showForm = false else serverError = err }
            })
        }
    }
}

@Composable
fun PlaceholderScreen(title: String, s: Strings) = Column(
    Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
    horizontalAlignment = Alignment.CenterHorizontally
) {
    Text(title, style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    Text(s.comingSoon, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun SettingsScreen(s: Strings, onLanguage: (Boolean) -> Unit) = Column(Modifier.fillMaxSize().padding(16.dp)) {
    Text(s.settings, style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(16.dp))
    Text(s.language, style = MaterialTheme.typography.titleMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = s.bn, onClick = { onLanguage(true) }, label = { Text(s.bengali) })
        FilterChip(selected = !s.bn, onClick = { onLanguage(false) }, label = { Text(s.english) })
    }
    Spacer(Modifier.height(24.dp))
    val ctx = LocalContext.current
    val ver = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { "?" } }
    Text("Version: $ver", color = MaterialTheme.colorScheme.onSurfaceVariant)
}
