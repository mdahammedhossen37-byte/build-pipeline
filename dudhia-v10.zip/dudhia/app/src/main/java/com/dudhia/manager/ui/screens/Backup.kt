package com.dudhia.manager.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.dudhia.manager.DudhiaApp
import com.dudhia.manager.backup.BackupManager
import com.dudhia.manager.core.Strings
import com.dudhia.manager.ui.theme.DudhiaColors
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BackupScreen(s: Strings, lastBackup: Long?, onBackedUp: (Long, Long) -> Unit) {
    val ctx = LocalContext.current
    val db = remember { (ctx.applicationContext as DudhiaApp).db }
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var candidate by remember { mutableStateOf<BackupManager.BackupInfo?>(null) }
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val r = BackupManager.export(ctx, db, uri)
            busy = false
            val size = r.getOrNull()
            if (size != null) {
                onBackedUp(System.currentTimeMillis(), size)
                isError = false
                message = s.backupDone + " (" + (size / 1024) + " KB)"
            } else {
                isError = true
                message = s.backupFailed
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val r = BackupManager.inspect(ctx, uri)
            busy = false
            val info = r.getOrNull()
            if (info != null) {
                candidate = info; message = null
            } else {
                isError = true; message = s.backupInvalid
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(s.moreBackup, style = MaterialTheme.typography.titleLarge)
        Text(
            if (lastBackup == null) s.neverBacked else "${s.lastBackupLabel}: ${fmt.format(Date(lastBackup))}",
            style = MaterialTheme.typography.titleMedium
        )
        Text(s.backupHint, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(enabled = !busy, modifier = Modifier.fillMaxWidth(), onClick = {
            val name = "dudhia-backup-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date()) + ".db"
            exportLauncher.launch(name)
        }) { Text(s.backupNow) }
        OutlinedButton(enabled = !busy, modifier = Modifier.fillMaxWidth(), onClick = {
            importLauncher.launch(arrayOf("*/*"))
        }) { Text(s.restoreBtn) }
        if (busy) Text(s.working)
        message?.let { Text(it, color = if (isError) DudhiaColors.Error else DudhiaColors.Success) }
    }

    candidate?.let { c ->
        AlertDialog(
            onDismissRequest = { candidate = null },
            title = { Text(s.restoreTitle) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${s.customers}: ${c.customers}")
                    Text("${s.products}: ${c.products}")
                    Text("${s.orders}: ${c.orders}")
                    Text("${c.sizeBytes / 1024} KB")
                    Spacer(Modifier.height(4.dp))
                    Text(s.restoreWarning, color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    candidate = null
                    scope.launch {
                        busy = true
                        BackupManager.restore(ctx, db, c)   // on failure the old data is rolled back
                        BackupManager.restartApp(ctx)
                    }
                }) { Text(s.restoreYes) }
            },
            dismissButton = { TextButton(onClick = { candidate = null }) { Text(s.cancel) } }
        )
    }
}
