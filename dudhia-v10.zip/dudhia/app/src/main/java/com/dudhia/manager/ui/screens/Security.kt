package com.dudhia.manager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.dudhia.manager.core.Phone
import com.dudhia.manager.core.Strings
import com.dudhia.manager.security.Biometric
import com.dudhia.manager.ui.theme.DudhiaColors
import kotlinx.coroutines.launch

/** Digits only (Bengali digits are converted), max 6. */
@Composable
internal fun PinField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { v -> onChange(Phone.normalize(v).filter { c -> c in '0'..'9' }.take(6)) },
        label = { Text(label) }, singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun LockScreen(
    s: Strings,
    verify: suspend (String) -> Boolean,
    lockedUntil: () -> Long,
    onBiometric: (() -> Unit)?
) {
    val scope = rememberCoroutineScope()
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(s.welcomeTitle, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(16.dp))
            PinField(s.enterPin, pin) { pin = it }
            error?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                scope.launch {
                    if (System.currentTimeMillis() < lockedUntil()) {
                        error = s.tooManyTries
                    } else if (verify(pin)) {
                        pin = ""; error = null
                    } else {
                        error = if (System.currentTimeMillis() < lockedUntil()) s.tooManyTries else s.wrongPin
                        pin = ""
                    }
                }
            }) { Text(s.unlock) }
            if (onBiometric != null) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onBiometric) { Text(s.useFingerprint) }
            }
        }
    }
}

@Composable
fun SecurityScreen(
    s: Strings,
    pinEnabled: Boolean,
    bioEnabled: Boolean,
    onSetPin: (String) -> Unit,
    onDisablePin: suspend (String) -> Boolean,
    onBio: (Boolean) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pin1 by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var current by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    val bioAvailable = remember { Biometric.available(ctx) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(s.security, style = MaterialTheme.typography.titleLarge)
        Text(s.pinNote, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (!pinEnabled) {
            PinField(s.newPin, pin1) { pin1 = it }
            PinField(s.confirmPin, pin2) { pin2 = it }
            Button(onClick = {
                if (pin1.length < 4) {
                    msg = s.pinTooShort
                } else if (pin1 != pin2) {
                    msg = s.pinMismatch
                } else {
                    onSetPin(pin1); pin1 = ""; pin2 = ""; msg = s.pinEnabledMsg
                }
            }) { Text(s.enablePin) }
        } else {
            Text(s.pinIsOn, color = DudhiaColors.Success, style = MaterialTheme.typography.titleMedium)
            if (bioAvailable) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(s.useFingerprint, Modifier.weight(1f))
                    Switch(checked = bioEnabled, onCheckedChange = { onBio(it) })
                }
            }
            PinField(s.currentPin, current) { current = it }
            OutlinedButton(onClick = {
                scope.launch {
                    if (onDisablePin(current)) { msg = s.pinDisabledMsg; current = "" } else { msg = s.wrongPin }
                }
            }) { Text(s.disablePin) }
        }
        msg?.let { Text(it) }
    }
}
