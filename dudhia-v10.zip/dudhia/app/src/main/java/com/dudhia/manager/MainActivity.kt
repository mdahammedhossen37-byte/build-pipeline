package com.dudhia.manager

import android.os.Bundle
import android.os.SystemClock
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.compose.*
import com.dudhia.manager.core.Strings
import com.dudhia.manager.core.periodRange
import com.dudhia.manager.features.finance.Finance
import com.dudhia.manager.features.settings.AppViewModel
import com.dudhia.manager.security.Biometric
import com.dudhia.manager.ui.screens.*
import com.dudhia.manager.ui.theme.DudhiaTheme

class MainActivity : FragmentActivity() {
    private val vm: AppViewModel by viewModels {
        viewModelFactory { initializer { AppViewModel((application as DudhiaApp).db) } }
    }
    private var backgroundedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DudhiaTheme {
                val bn by vm.languageBn.collectAsStateWithLifecycle()
                val pinEnabled by vm.pinEnabled.collectAsStateWithLifecycle()
                val unlocked by vm.unlocked.collectAsStateWithLifecycle()
                val bioOn by vm.bioEnabled.collectAsStateWithLifecycle()
                val s = remember(bn) { Strings(bn) }
                Box(Modifier.fillMaxSize()) {
                    AppRoot(vm)
                    // The lock screen sits on top of the app, so nothing the user was doing is lost.
                    when {
                        pinEnabled == null -> Surface(Modifier.fillMaxSize()) {}
                        pinEnabled == true && !unlocked -> {
                            val bioAction: (() -> Unit)? =
                                if (bioOn && Biometric.available(this@MainActivity)) {
                                    ({ Biometric.prompt(this@MainActivity, s.useFingerprint, s.cancel) { vm.unlock() } })
                                } else null
                            LockScreen(s, verify = { vm.verifyPin(it) }, lockedUntil = { vm.lockedUntil }, onBiometric = bioAction)
                        }
                        else -> {}
                    }
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        backgroundedAt = SystemClock.elapsedRealtime()
    }

    override fun onStart() {
        super.onStart()
        // Auto-lock: ask for the PIN again if the app was away for more than 30 seconds.
        if (backgroundedAt != 0L && SystemClock.elapsedRealtime() - backgroundedAt > 30_000L) vm.relock()
    }
}

private data class Tab(val route: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppRoot(vm: AppViewModel) {
    val bn by vm.languageBn.collectAsStateWithLifecycle()
    val onboarded by vm.onboarded.collectAsStateWithLifecycle()
    val customers by vm.customerCount.collectAsStateWithLifecycle()
    val products by vm.products.collectAsStateWithLifecycle()
    val customerList by vm.customers.collectAsStateWithLifecycle()
    val orders by vm.orders.collectAsStateWithLifecycle()
    val allItems by vm.orderItemsAll.collectAsStateWithLifecycle()
    val expenses by vm.expenses.collectAsStateWithLifecycle()
    val lastBackup by vm.lastBackup.collectAsStateWithLifecycle()
    val pinEnabled by vm.pinEnabled.collectAsStateWithLifecycle()
    val bioEnabled by vm.bioEnabled.collectAsStateWithLifecycle()
    val s = remember(bn) { Strings(bn) }

    when (onboarded) {
        null -> return
        false -> { Surface { Onboarding(s) { vm.finishOnboarding() } }; return }
        else -> {}
    }
    val nav = rememberNavController()
    val tabs = listOf(
        Tab("dashboard", Icons.Default.Home), Tab("crm", Icons.Default.People),
        Tab("orders", Icons.Default.ShoppingCart), Tab("inventory", Icons.Default.Inventory2),
        Tab("more", Icons.Default.Menu)
    )
    val moreRoutes = setOf("finance", "settings", "backup", "security")
    fun label(r: String) = when (r) {
        "dashboard" -> s.dashboard; "crm" -> s.crm; "orders" -> s.orders
        "inventory" -> s.inventory; else -> s.more
    }
    val current = nav.currentBackStackEntryAsState().value?.destination?.route
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEach { t ->
                NavigationBarItem(
                    selected = current == t.route || (t.route == "more" && current in moreRoutes),
                    label = { Text(label(t.route)) },
                    icon = { Icon(t.icon, null) },
                    onClick = { nav.navigate(t.route) { popUpTo("dashboard"); launchSingleTop = true; restoreState = true } }
                )
            }
        }
    }) { pad ->
        NavHost(nav, startDestination = "dashboard", modifier = Modifier.padding(pad)) {
            composable("dashboard") {
                val today = periodRange("TODAY")
                val pnl = Finance.compute(orders, allItems, expenses, today.first, today.second)
                DashboardScreen(
                    s, customers, products.size,
                    products.count { it.minStockMilli > 0 && it.stockMilli <= it.minStockMilli },
                    pnl.revenue, pnl.expenses, pnl.netProfit,
                    orders.count { it.status == "NEW" || it.status == "CONFIRMED" || it.status == "SHIPPED" },
                    orders.count { it.status == "DELIVERED" },
                    orders.count { it.status == "CANCELLED" })
            }
            composable("crm") { CrmScreen(s, customerList, { vm.findByPhone(it) }, { vm.saveCustomer(it) }) }
            composable("orders") {
                OrdersScreen(s, orders, customerList, products, { vm.orderItems(it) },
                    { o, its, done -> vm.createOrder(o, its, done) },
                    { id, st, done -> vm.changeStatus(id, st, done) },
                    { vm.markPaid(it) })
            }
            composable("inventory") { InventoryScreen(s, products) { p, done -> vm.saveProduct(p, done) } }
            composable("more") {
                MoreScreen(s,
                    { nav.navigate("finance") }, { nav.navigate("backup") },
                    { nav.navigate("security") }, { nav.navigate("settings") })
            }
            composable("settings") { SettingsScreen(s) { vm.setLanguage(it) } }
            composable("finance") {
                FinanceScreen(s, orders, allItems, expenses, { vm.addExpense(it) }, { vm.voidExpense(it) })
            }
            composable("backup") { BackupScreen(s, lastBackup) { t, size -> vm.recordBackup(t, size) } }
            composable("security") {
                SecurityScreen(s, pinEnabled == true, bioEnabled,
                    { vm.setPin(it) }, { vm.disablePin(it) }, { vm.setBiometric(it) })
            }
        }
    }
}
