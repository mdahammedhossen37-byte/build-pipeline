package com.dudhia.manager.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.dudhia.manager.core.*
import com.dudhia.manager.database.CustomerEntity
import com.dudhia.manager.features.crm.CustomerLabels
import com.dudhia.manager.features.crm.CustomerStats
import com.dudhia.manager.ui.theme.DudhiaColors
import com.dudhia.manager.database.OrderEntity
import com.dudhia.manager.database.ProductEntity
import kotlinx.coroutines.launch

@Composable
fun Onboarding(s: Strings, onStart: () -> Unit) = Column(
    Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
    horizontalAlignment = Alignment.CenterHorizontally
) {
    Text(s.welcomeTitle, style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(12.dp))
    Text(s.welcomeBody, style = MaterialTheme.typography.bodyLarge)
    Spacer(Modifier.height(24.dp))
    Button(onClick = onStart) { Text(s.start) }
}

@Composable
private fun StatCard(label: String, value: String, mod: Modifier = Modifier) =
    Card(mod, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.headlineSmall)
        }
    }

data class DashboardData(
    val customers: Int, val products: Int, val lowStock: Int,
    val todaySales: Long, val todayExpenses: Long, val todayNet: Long,
    val pending: Int, val delivered: Int, val cancelled: Int,
    val outstanding: Long, val supplierDue: Long, val bestSellers: List<Pair<String, Long>>,
    val adSpend: Long, val costPerOrder: Long?,
    val tasksToday: Int, val tasksOverdue: Int
)

@Composable
fun DashboardScreen(s: Strings, d: DashboardData) = Column(
    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
) {
    Text(s.dashboard, style = MaterialTheme.typography.titleLarge)
    StatCard(s.todaySales, Money(d.todaySales).format(), Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCard(s.todayExpenses, Money(d.todayExpenses).format(), Modifier.weight(1f))
        StatCard(s.todayNet, Money(d.todayNet).format(), Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCard(s.outstanding, Money(d.outstanding).format(), Modifier.weight(1f))
        StatCard(s.supplierDueCard, Money(d.supplierDue).format(), Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCard(s.adSpendMonth, Money(d.adSpend).format(), Modifier.weight(1f))
        StatCard(s.costPerOrderMonth, d.costPerOrder?.let { Money(it).format() } ?: "-", Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCard(s.tasksToday, d.tasksToday.toString(), Modifier.weight(1f))
        StatCard(s.tasksOverdue, d.tasksOverdue.toString(), Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCard(s.pendingOrders, d.pending.toString(), Modifier.weight(1f))
        StatCard(s.deliveredOrders, d.delivered.toString(), Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCard(s.cancelledOrders, d.cancelled.toString(), Modifier.weight(1f))
        StatCard(s.lowStock, d.lowStock.toString(), Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCard(s.customers, d.customers.toString(), Modifier.weight(1f))
        StatCard(s.products, d.products.toString(), Modifier.weight(1f))
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(s.bestSellers, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (d.bestSellers.isEmpty()) Text(s.noSalesYet)
            d.bestSellers.forEach { (name, qty) -> Text("$name — ${Qty.format(qty)}") }
        }
    }
}

@Composable
fun MoreScreen(s: Strings, entries: List<Pair<String, () -> Unit>>) = Column(
    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
) {
    Text(s.more, style = MaterialTheme.typography.titleLarge)
    entries.forEach { (label, action) ->
        Card(Modifier.fillMaxWidth().clickable { action() }) {
            Text(label, Modifier.padding(16.dp), style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
fun CrmScreen(
    s: Strings,
    customers: List<CustomerEntity>,
    archived: List<CustomerEntity>,
    orders: List<OrderEntity>,
    vipAmountPaisa: Long,
    inactiveDays: Int,
    findByPhone: suspend (String) -> List<CustomerEntity>,
    onSave: (CustomerEntity) -> Unit,
    onArchive: (Long) -> Unit,
    onRestore: (Long) -> Unit
) {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var areaFilter by remember { mutableStateOf<String?>(null) }
    var labelFilter by remember { mutableStateOf<String?>(null) }
    var showArchived by remember { mutableStateOf(false) }
    var showForm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<CustomerEntity?>(null) }
    var pending by remember { mutableStateOf<CustomerEntity?>(null) }
    var dups by remember { mutableStateOf<List<CustomerEntity>>(emptyList()) }
    var profileId by remember { mutableStateOf<Long?>(null) }
    var archiveId by remember { mutableStateOf<Long?>(null) }

    val byCustomer = remember(orders) { orders.groupBy { it.customerId } }
    val statsMap = remember(byCustomer) { byCustomer.mapValues { CustomerLabels.stats(it.value) } }
    val now = remember { System.currentTimeMillis() }
    val labelsMap = remember(customers, statsMap, vipAmountPaisa, inactiveDays) {
        customers.associate { c ->
            c.id to CustomerLabels.compute(c, statsMap[c.id] ?: CustomerStats.EMPTY, now, vipAmountPaisa, inactiveDays)
        }
    }
    val areas = remember(customers) { customers.mapNotNull { c -> c.area?.trim()?.takeIf { it.isNotEmpty() } }.distinct().sorted() }
    val shown = remember(customers, query, areaFilter, labelFilter, labelsMap) {
        val q = query.trim()
        val af = areaFilter
        val lf = labelFilter
        customers.filter { c ->
            (q.isEmpty() || c.name.contains(q, ignoreCase = true) ||
                c.phone.contains(Phone.normalize(q).ifEmpty { q }) || (c.tags ?: "").contains(q, ignoreCase = true)) &&
                (af == null || c.area?.trim() == af) &&
                (lf == null || (labelsMap[c.id] ?: emptyList()).contains(lf))
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text(s.crm, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !showArchived, onClick = { showArchived = false }, label = { Text(s.crm) })
                FilterChip(selected = showArchived, onClick = { showArchived = true }, label = { Text("${s.archivedView} (${archived.size})") })
            }
            Spacer(Modifier.height(8.dp))
            if (!showArchived) {
                OutlinedTextField(query, { query = it }, label = { Text(s.search) },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = labelFilter == null, onClick = { labelFilter = null }, label = { Text(s.all) })
                    listOf("NEW", "REGULAR", "VIP", "INACTIVE").forEach { code ->
                        FilterChip(selected = labelFilter == code, onClick = { labelFilter = code }, label = { Text(s.labelLabel(code)) })
                    }
                }
                if (areas.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = areaFilter == null, onClick = { areaFilter = null }, label = { Text("${s.area}: ${s.all}") })
                        areas.forEach { a ->
                            FilterChip(selected = areaFilter == a, onClick = { areaFilter = a }, label = { Text(a) })
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                if (customers.isEmpty()) Text(s.noCustomers, color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                    items(shown, key = { "c${it.id}" }) { c ->
                        val st = statsMap[c.id]
                        Card(Modifier.fillMaxWidth().clickable { profileId = c.id }) {
                            Column(Modifier.padding(12.dp)) {
                                Text(c.name, style = MaterialTheme.typography.titleMedium)
                                val labels = labelsMap[c.id].orEmpty()
                                if (labels.isNotEmpty()) {
                                    Text(labels.joinToString(" · ") { s.labelLabel(it) },
                                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                }
                                Text(c.phone, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                val place = listOfNotNull(c.area, c.district).joinToString(", ")
                                if (place.isNotEmpty()) Text(place, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                c.tags?.let { Text("#$it", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                                if (st != null && st.orderCount > 0) {
                                    Text("${s.orders}: ${st.orderCount} · ${s.totalBought}: ${Money(st.lifetimePaisa).format()}" +
                                        (if (st.outstandingPaisa > 0) " · ${s.dueShort}: ${Money(st.outstandingPaisa).format()}" else ""),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                c.followUpAt?.let { fu ->
                                    Text("${s.followUpOn}: ${formatDateOnly(fu)}",
                                        color = if (fu < now) DudhiaColors.Error else MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            } else {
                if (archived.isEmpty()) Text(s.archivedEmpty, color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                    items(archived, key = { "a${it.id}" }) { c ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(c.name, style = MaterialTheme.typography.titleMedium)
                                Text(c.phone, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                OutlinedButton(onClick = { onRestore(c.id) }) { Text(s.restoreAction) }
                            }
                        }
                    }
                }
            }
        }
        if (!showArchived) {
            FloatingActionButton(
                onClick = { editing = null; showForm = true },
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
            ) { Icon(Icons.Default.Add, contentDescription = s.newCustomer) }
        }

        if (showForm) key(editing?.id ?: 0L) {
            CustomerFormDialog(s, editing, onDismiss = { showForm = false }, onSubmit = { c ->
                scope.launch {
                    val found = findByPhone(c.phone).filter { it.id != c.id }
                    if (found.isEmpty()) { onSave(c); showForm = false }
                    else { pending = c; dups = found }
                }
            })
        }
    }

    val profile = profileId?.let { id -> customers.firstOrNull { it.id == id } }
    if (profile != null) {
        val st = statsMap[profile.id] ?: CustomerStats.EMPTY
        val recent = (byCustomer[profile.id] ?: emptyList()).sortedByDescending { it.orderDate }.take(10)
        AlertDialog(
            onDismissRequest = { profileId = null },
            title = { Text(profile.name) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(profile.phone)
                    profile.altPhone?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    val addr = listOfNotNull(profile.address, profile.area, profile.district).joinToString(", ")
                    if (addr.isNotEmpty()) Text(addr, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val labels = labelsMap[profile.id].orEmpty()
                    if (labels.isNotEmpty()) Text(labels.joinToString(" · ") { s.labelLabel(it) }, color = MaterialTheme.colorScheme.primary)
                    profile.tags?.let { Text("#$it", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    profile.followUpAt?.let { Text("${s.followUpOn}: ${formatDateOnly(it)}") }
                    Spacer(Modifier.height(4.dp))
                    Text("${s.totalOrdersLabel}: ${st.orderCount}")
                    Text("${s.lifetimeValue}: ${Money(st.lifetimePaisa).format()}")
                    Text("${s.outstandingLabel}: ${Money(st.outstandingPaisa).format()}")
                    Text("${s.lastOrderLabel}: ${st.lastOrderAt?.let { formatDateOnly(it) } ?: "-"}")
                    profile.notes?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Spacer(Modifier.height(4.dp))
                    Text(s.recentOrders, style = MaterialTheme.typography.titleSmall)
                    if (recent.isEmpty()) {
                        Text(s.noOrdersYet, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        recent.forEach { o ->
                            Text("#${o.id} · ${s.statusLabel(o.status)} · ${Money(o.totalPaisa).format()} · ${formatDateOnly(o.orderDate)}")
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Button(onClick = { editing = profile; showForm = true; profileId = null }, modifier = Modifier.fillMaxWidth()) {
                        Text(s.editAction)
                    }
                    OutlinedButton(onClick = { archiveId = profile.id; profileId = null }, modifier = Modifier.fillMaxWidth()) {
                        Text(s.archiveAction)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { profileId = null }) { Text(s.close) } }
        )
    }
    archiveId?.let { id ->
        AlertDialog(
            onDismissRequest = { archiveId = null },
            title = { Text(s.confirmTitle) },
            text = { Text(s.confirmArchive) },
            confirmButton = { TextButton(onClick = { onArchive(id); archiveId = null }) { Text(s.yes) } },
            dismissButton = { TextButton(onClick = { archiveId = null }) { Text(s.cancel) } }
        )
    }
    pending?.let { p ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text(s.dupTitle) },
            text = { Text(dups.joinToString("\n") { "${it.name}\n${it.phone}" }) },
            confirmButton = {
                TextButton(onClick = { editing = dups.first(); pending = null; showForm = true }) { Text(s.openExisting) }
            },
            dismissButton = {
                TextButton(onClick = { onSave(p); pending = null; showForm = false }) { Text(s.saveAnyway) }
            }
        )
    }
}

@Composable
fun InventoryScreen(
    s: Strings,
    products: List<ProductEntity>,
    archived: List<ProductEntity>,
    onSave: (ProductEntity, (String?) -> Unit) -> Unit,
    onArchive: (Long) -> Unit,
    onRestore: (Long) -> Unit
) {
    var showForm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<ProductEntity?>(null) }
    var serverError by remember { mutableStateOf<String?>(null) }
    var showArchived by remember { mutableStateOf(false) }
    var archiveId by remember { mutableStateOf<Long?>(null) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text(s.inventory, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !showArchived, onClick = { showArchived = false }, label = { Text(s.inventory) })
                FilterChip(selected = showArchived, onClick = { showArchived = true }, label = { Text("${s.archivedView} (${archived.size})") })
            }
            Spacer(Modifier.height(8.dp))
            if (!showArchived) {
                if (products.isEmpty()) Text(s.noProducts)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                    items(products, key = { "p${it.id}" }) { p ->
                        val low = p.minStockMilli > 0 && p.stockMilli <= p.minStockMilli
                        Card(Modifier.fillMaxWidth().clickable { editing = p; serverError = null; showForm = true }) {
                            Column(Modifier.padding(12.dp)) {
                                Text(if (s.bn) p.nameBn else p.nameEn, style = MaterialTheme.typography.titleMedium)
                                Text("${p.sku} · ${s.unitLabel(p.unit)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${Money(p.pricePaisa).format()} / ${Money(p.costPaisa).format()}",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${s.stock}: ${Qty.format(p.stockMilli)}",
                                    color = if (low) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            } else {
                if (archived.isEmpty()) Text(s.archivedEmpty, color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                    items(archived, key = { "a${it.id}" }) { p ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(if (s.bn) p.nameBn else p.nameEn, style = MaterialTheme.typography.titleMedium)
                                Text("${p.sku} · ${s.unitLabel(p.unit)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                OutlinedButton(onClick = { onRestore(p.id) }) { Text(s.restoreAction) }
                            }
                        }
                    }
                }
            }
        }
        if (!showArchived) {
            FloatingActionButton(
                onClick = { editing = null; serverError = null; showForm = true },
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
            ) { Icon(Icons.Default.Add, contentDescription = s.newProduct) }
        }

        if (showForm) key(editing?.id ?: 0L) {
            val ed = editing
            ProductFormDialog(s, ed, serverError, onDismiss = { showForm = false }, onSubmit = { p ->
                onSave(p) { err -> if (err == null) showForm = false else serverError = err }
            }, onArchive = if (ed != null) ({ archiveId = ed.id; showForm = false }) else null)
        }
    }
    archiveId?.let { id ->
        AlertDialog(
            onDismissRequest = { archiveId = null },
            title = { Text(s.confirmTitle) },
            text = { Text(s.confirmArchive) },
            confirmButton = { TextButton(onClick = { onArchive(id); archiveId = null }) { Text(s.yes) } },
            dismissButton = { TextButton(onClick = { archiveId = null }) { Text(s.cancel) } }
        )
    }
}

@Composable
fun PlaceholderScreen(title: String, s: Strings) = Column(
    Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
    horizontalAlignment = Alignment.CenterHorizontally
) {
    Text(title, style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    Text(s.comingSoon, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun SettingsScreen(
    s: Strings,
    vipAmountPaisa: Long,
    inactiveDays: Int,
    onLanguage: (Boolean) -> Unit,
    onSaveLabels: (Long, Int) -> Unit
) {
    val ctx = LocalContext.current
    var vip by remember(vipAmountPaisa) { mutableStateOf(Money(vipAmountPaisa).plain()) }
    var days by remember(inactiveDays) { mutableStateOf(inactiveDays.toString()) }
    var msg by remember { mutableStateOf<String?>(null) }
    val ver = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { "?" } }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(s.settings, style = MaterialTheme.typography.titleLarge)
        Text(s.language, style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = s.bn, onClick = { onLanguage(true) }, label = { Text(s.bengali) })
            FilterChip(selected = !s.bn, onClick = { onLanguage(false) }, label = { Text(s.english) })
        }
        Spacer(Modifier.height(8.dp))
        Text(s.labelSettings, style = MaterialTheme.typography.titleMedium)
        Field(s.vipAmountField, vip, { vip = it }, KeyboardType.Decimal)
        Field(s.inactiveDaysField, days, { days = it }, KeyboardType.Number)
        Button(onClick = {
            val v = Money.parse(vip)
            val d = days.trim().toIntOrNull()
            if (v == null || v.paisa < 0 || d == null || d < 1) {
                msg = s.invalidNumber
            } else {
                onSaveLabels(v.paisa, d); msg = s.settingsSaved
            }
        }) { Text(s.save) }
        msg?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        Spacer(Modifier.height(16.dp))
        Text("Version: $ver", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
